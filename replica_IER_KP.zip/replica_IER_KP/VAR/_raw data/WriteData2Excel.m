clear
close all
clc

datastruct=load("data.mat");


data        = [datastruct.VIX24,datastruct.VIX1,datastruct.UR,datastruct.INFL,100*datastruct.IR2];
data(:,1:2) = 100*log(data(:,1:2));

data_raw    = [datastruct.VIX24,datastruct.VIX1,datastruct.UR,datastruct.INFL,datastruct.IR2];

data_vix    = [datastruct.VIX1,datastruct.VIX3,datastruct.VIX6,datastruct.VIX12,datastruct.VIX24];

dates       = datastruct.dt;
dates_str   = num2str(month(dates))+"/"+num2str(year(dates));

varnames    = {'dates','VIX2Y','VIX1M','UNRATE','INFL','WXSR'};
vixnames    = {'dates','VIX1M','VIX3M','VIX6M','VIX1Y','VIX2Y'};


% Tables
tab     = table(dates_str,data(:,1),data(:,2),data(:,3),data(:,4),data(:,5),'VariableNames',varnames);
tab_raw = table(dates_str,data_raw(:,1),data_raw (:,2),data_raw (:,3),data_raw (:,4),data_raw (:,5),'VariableNames',varnames);
tab_vix = table(dates_str,data_vix(:,1),data_vix(:,2),data_vix(:,3),data_vix(:,4),data_vix(:,5),'VariableNames',vixnames);

% Write to excel
filename = 'VARdata.xlsx';
writetable(tab_raw,filename,'Sheet',"raw",'Range','A1')
writetable(tab,filename,'Sheet',"transformed",'Range','A1')
writetable(tab_vix,filename,'Sheet',"vix",'Range','A1')

