%% Written by Mathias Krogh, July 2023
clear variables
close all
clc

addpath('data');

%% Load data
data.vix     = load("../../VIXdata/VIX_data.mat");
data.fred    = load("data/FRED.mat");
data.wuxia   = load("data/WuXia.mat");

%% Prepare monthly dataset for VAR analysis
clearvars -except data simdata

% settings
startdate     = 1996.00;
enddate       = 2022.00+round(11/12,2);
dn            = round(startdate:(1/12):enddate,2)';
T             = length(dn);
dt            = datetime(floor(dn),round(12*(dn-floor(dn))+1,0),repmat(15,T,1));

% FRED data
data.fred.dt       = table2array(data.fred.FRED(:,1));
data.fred.dn       = round(year(data.fred.dt)+(month(data.fred.dt)-1)/12,2);
data.fred.idx      = 1:length(data.fred.dn);data.fred.idx=data.fred.idx(data.fred.dn>=startdate & data.fred.dn<=enddate);
data.fred.infl     = 100*(log(table2array(data.fred.FRED(data.fred.idx,"CPIAUCSL")))-log(table2array(data.fred.FRED(data.fred.idx-12,"CPIAUCSL"))));
data.fred.coreinfl = 100*(log(table2array(data.fred.FRED(data.fred.idx,"CPILFESL")))-log(table2array(data.fred.FRED(data.fred.idx-12,"CPILFESL"))));
data.fred.ipgrowth = 100*(log(table2array(data.fred.FRED(data.fred.idx,"INDPRO")))-log(table2array(data.fred.FRED(data.fred.idx-12,"INDPRO"))));
data.fred.unrate   = table2array(data.fred.FRED(data.fred.idx,"UNRATE"));
data.fred.payems   = log(table2array(data.fred.FRED(data.fred.idx,"PAYEMS")));
data.fred.ffr      = table2array(data.fred.FRED(data.fred.idx,"FEDFUNDS"));
data.fred.ip       = log(table2array(data.fred.FRED(data.fred.idx,"INDPRO")));
data.fred.dff      = table2array(data.fred.FRED(data.fred.idx,"DFF"));

% Wu-Xia shadow rate
data.wuxia.dt      = table2array(data.wuxia.WuXiaShadowRate(:,1));
data.wuxia.dn      = round(year(data.wuxia.dt)+(month(data.wuxia.dt)-1)/12,2);
data.wuxia.idx     = 1:length(data.wuxia.dn);data.wuxia.idx=data.wuxia.idx(data.wuxia.dn>=startdate & data.wuxia.dn<=enddate);
data.wuxia.ffr     = [table2array(data.wuxia.WuXiaShadowRate(data.wuxia.idx,2));data.fred.dff(end-9:end)];%nan(10,1)];
data.wuxia.wxsr    = [table2array(data.wuxia.WuXiaShadowRate(data.wuxia.idx,3));data.fred.dff(end-9:end)];%nan(10,1)];


% VIX data
data.vix.dn       = round(year(data.vix.dt)+(month(data.vix.dt)-1)/12,2);
data.vix.ntd      = nan(length(dn),1);
data.vix.mVIX1    = nan(length(dn),2);
data.vix.mVIX3    = nan(length(dn),2);
data.vix.mVIX12   = nan(length(dn),2);
data.vix.mVIX24   = nan(length(dn),2);
for t=1:length(dn)
    idx                  = (data.vix.dn==dn(t));
    ntd                  = sum(idx);
    vix                  = data.vix.VIX_data(idx,[2,4,7,end-2,end]);
    data.vix.ntd(t)      = ntd;
    data.vix.mVIX1(t,1)  = mean(vix(:,1),'omitnan'); % avg, full month
    data.vix.mVIX3(t,1)  = mean(vix(:,2),'omitnan');
    data.vix.mVIX6(t,1)  = mean(vix(:,3),'omitnan');
    data.vix.mVIX12(t,1) = mean(vix(:,4),'omitnan');
    data.vix.mVIX24(t,1) = mean(vix(:,5),'omitnan');

    data.vix.mVIX1(t,2)  = mean(vix(end-2:end,1),'omitnan'); % avg, last 3 days
    data.vix.mVIX3(t,2)  = mean(vix(end-2:end,2),'omitnan'); 
    data.vix.mVIX6(t,2)  = mean(vix(end-2:end,3),'omitnan'); 
    data.vix.mVIX12(t,2) = mean(vix(end-2:end,4),'omitnan'); 
    data.vix.mVIX24(t,2) = mean(vix(end-2:end,5),'omitnan');
end

clear t idx ntd ret vix

% Data
VIX1  = data.vix.mVIX1(:,1);
VIX3  = data.vix.mVIX3(:,1);
VIX6  = data.vix.mVIX6(:,1);
VIX12 = data.vix.mVIX12(:,1);
VIX24 = data.vix.mVIX24(:,1);
UR    = data.fred.unrate;
INFL  = data.fred.infl;
IR0   = data.fred.ffr;
IR1   = data.fred.dff;
IR2   = data.wuxia.wxsr;
IPGR  = data.fred.ipgrowth;

clear data ans y x X b eps idx nanidx

save("data.mat")

