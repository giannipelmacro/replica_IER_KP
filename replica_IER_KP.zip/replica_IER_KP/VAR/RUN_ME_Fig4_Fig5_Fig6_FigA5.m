%% estimate and identify the VAR

clear

cd('BASELINE_nonrobust')

sendfile

cd('../')

%% Plot impulse responses 

clear
close all
clc

addpath("auxFunctions")

model              = load("BASELINE_nonrobust/results baseline_nonrobust.mat");


colorcodes             = [[0.4660 0.6740 0.1880];... % green
                          [0.6350 0.0780 0.1840]];

ExPostAnalysis         = true;

set(groot,'defaultAxesTickLabelInterpreter','latex');

ni         = model.ni;
nj         = model.nj;
opt        = model.opt;
irfUnits   = model.irfUnits;
varnames   = model.varnames;varnames{5}='Policy Rate';
shocknames = model.shocknames;
dates      = model.dates;


% Two plots: One for vix response, one for macro response
varnames_short = ["VIX 1M","VIX 2Y","Unempl","Inflation","Policy Rate"];
shocknames_new = ["Short-term Shock","Long-term Shock","S3","S4","S5"];
ylimss         = [-05.00,15.00;...
                  -02.00,06.00;...
                  -00.20,00.35;...
                  -00.25,00.25;...
                  -37.50,15.00];

for xx = 3 %[1,2] change if making plots for slides / paper

    figure;

    if xx == 1
        tvars = [1,2];
    elseif xx == 2
        tvars = [3,4,5];
    elseif xx == 3
        tvars = [1,2,3,4,5];
    end

    for iix = 1:length(tvars)

        ii  = tvars(iix); 

        for jj = 1:nj

            subplot(length(tvars),2,(iix-1)*2+jj)

            h0 = plot(0:opt.H,zeros(1,1+opt.H),'-k','linewidth',1);
            grid on
            hold on
            ylim(ylimss(ii,:))
    
            h1 = plot(0:opt.H,model.rSinglePriorMean_IRF(:,ii,jj),'--','color',colorcodes(jj,:),'linewidth',2);
    
            if opt.PlotAlpha
    
                h2 = fill([0:opt.H,fliplr(0:opt.H)], [model.hpdlb_IRF(:,ii,jj)', fliplr(model.hpdub_IRF(:,ii,jj)')], colorcodes(jj,:),'facealpha',0.40,'edgealpha',0);
    
            end

                
            if opt.doRobust
    
                h6 = plot(0:opt.H,model.credlb_IRF(:,ii,jj),'-k','LineWidth',2);
                h7 = plot(0:opt.H,model.credub_IRF(:,ii,jj),'-k','LineWidth',2);
    
            end
            
            if iix == 1
                title(sprintf('%s',"\textbf{"+shocknames_new{jj}+"}"),'interpreter','latex','Fontsize',16);
            end
            xticks(0:12:opt.H);
            
            if jj == 1
                if irfUnits(opt.ivar(ii)) == 0
                    ylabel(varnames_short(ii)+" (\%)",'interpreter','latex','FontSize',14);
                elseif irfUnits(opt.ivar(ii)) == 1
                    ylabel(varnames_short(ii)+" (ppt)",'interpreter','latex','FontSize',14);
                elseif irfUnits(opt.ivar(ii)) == 2
                    ylabel(varnames_short(ii)+" (bps)",'interpreter','latex','FontSize',14);
                elseif irfUnits(opt.ivar(ii)) == 3
                    ylabel(varnames_short(ii)+" (lvl)",'interpreter','latex','FontSize',14)
                elseif irfUnits(opt.ivar(ii)) == 4
                    ylabel(varnames_short(ii)+" (stdd)",'interpreter','latex','FontSize',14)
                end
            end

        end

    end

end

if xx == 3
    set(gcf, 'Position', [309   138   559   659])
    set(gcf, 'PaperUnits','points', 'PaperPosition',[0 0 559 659], 'PaperSize',[559 659]) % same printed size on any OS
    print(sprintf("Fig4"),'-depsc');
    print(sprintf("Fig4"),'-dpdf');
end


%% Plot FEVD

for xx = 3 %[1,2] change if making plots for slides / paper

    figure;

    if xx == 1
        tvars = [1,2];
    elseif xx == 2
        tvars = [3,4,5];
    elseif xx == 3
        tvars = [1,2,3,4,5];
    end

    for iix = 1:length(tvars)

        ii  = tvars(iix); 

        for jj = 1:nj

            subplot(length(tvars),2,(iix-1)*2+jj)

            ylim([0,1])
    
            h1 = plot(0:opt.H,model.rSinglePriorMean_FEV(:,ii,jj),'--','color',colorcodes(jj,:),'linewidth',2);
            grid on
            hold on

            if opt.PlotAlpha
    
                h2 = plot(0:opt.H, model.hpdlb_FEV(:,ii,jj)',':','color',colorcodes(jj,:),'linewidth',2);
                h3 = plot(0:opt.H, model.hpdub_FEV(:,ii,jj)',':','color',colorcodes(jj,:),'linewidth',2);

            end

                
            if opt.doRobust
        
                h6 = plot(0:opt.H,model.credlb_FEV(:,ii,jj),'-k','LineWidth',2);
                h7 = plot(0:opt.H,model.credub_FEV(:,ii,jj),'-k','LineWidth',2);
        
            end
            
            if iix == 1
                title(sprintf('%s',"\textbf{"+shocknames_new{jj}+"}"),'interpreter','latex','Fontsize',16);
            end
            xticks(0:12:opt.H);

            ylim([0,1])


            if jj == 1
               ylabel(varnames_short(ii),'interpreter','latex','FontSize',14);
            end

        end

    end

end

if xx == 3
    set(gcf, 'Position', [882   138   559   659])
    set(gcf, 'PaperUnits','points', 'PaperPosition',[0 0 559 659], 'PaperSize',[559 659]) % same printed size on any OS
    print(sprintf("Fig5"),'-depsc');
    print(sprintf("Fig5"),'-dpdf');
end



%% Ex-post analysis of dates
if ExPostAnalysis
PosRate = squeeze(mean(model.rSinglePriorPost_EPS>0,1));
EpsSize = squeeze(mean(model.rSinglePriorPost_EPS,1));

HowMany = 6;

ExPost  = nan(HowMany,5,nj);

for jj = 1:2

    [EpsSizeSorted,idx] = sort(EpsSize(:,jj),'descend');
    PosRateSorted       = PosRate(idx,jj);
    PosRateDates        = dates(idx+opt.p);
    PosRateDatetime     = datetime(PosRateDates,'ConvertFrom','datenum');
    PosRateDatenumber   = 100*year(PosRateDatetime)+month(PosRateDatetime);
    
    ExPost(:,:,jj)      = [PosRateSorted(1:HowMany)*100,...
                           PosRateDatenumber(1:HowMany),...
                           EpsSizeSorted(1:HowMany),...
                           PosRateDates(1:HowMany),...
                           idx(1:HowMany)];

    fprintf(shocknames(jj)+": \n")
    [(num2str(ExPost(:,1,jj),'%4.2f')+"")'
     (num2str(ExPost(:,2,jj),'%4.2f')+"")'
     (num2str(ExPost(:,3,jj),'%4.2f')+"")']'
    

end


% Make Plot
monthString     = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]';
BinWidth = 0.3;
figure()
for jj = 1:nj
for i =1:3
    subplot(2,3,(jj-1)*3+i)
    histogram(model.rSinglePriorPost_EPS(:,ExPost(i,5,jj),1),'Normalization','pdf','FaceColor',colorcodes(1,:),'FaceAlpha',0.40,'EdgeColor',colorcodes(1,:),'EdgeAlpha',1,'BinWidth',BinWidth)
    hold on
    histogram(model.rSinglePriorPost_EPS(:,ExPost(i,5,jj),2),'Normalization','pdf','FaceColor',colorcodes(2,:),'FaceAlpha',0.40,'EdgeColor',colorcodes(2,:),'EdgeAlpha',1,'BinWidth',BinWidth)
    title(num2str(ExPost(i,2,jj)))
    h2   = line([0,0],[0,1],'Color','k','LineStyle','--','LineWidth',1);

    ylim([0,0.65])
    
    datestr = monthString(month(datetime(dates(opt.p+ExPost(i,5,jj)),'ConvertFrom','datenum')))+" "+num2str(year(datetime(dates(opt.p+ExPost(i,5,jj)),'ConvertFrom','datenum')));
   
    title("\textbf{"+sprintf('%s',datestr)+"}",'interpreter','latex','FontSize',14);
    if i == 1
        ylabel({"\textbf{Largest 3}";"\textbf{"+shocknames{jj}+"s}"},'interpreter','latex','FontSize',12)
    end

    if jj==1 && i==1
        legend(["ST","LT"],'location','nw','interpreter','latex')
    end

    set(gca,'ytick',[])
    set(gca,'yticklabel',[])

    
end
end
end

set(gcf,'position',[375   418   619   237])
set(gcf, 'PaperUnits','points', 'PaperPosition',[0 0 619 237], 'PaperSize',[619 237]) % same printed size on any OS
print(sprintf("FigA5"),'-depsc');
print(sprintf("FigA5"),'-dpdf');



%% Historical decomposition and plot for the Great Recession

dt                            = datetime(dates((opt.p+1):end),'ConvertFrom','datenum');
T0                            = find(dates((opt.p+1):end) == datenum(2008,09,15));
H                             = 18;
Y_tm1                         = model.YY(T0-1,:)';

HD                            = GetHD(model,T0,H);
TruePath                      = squeeze(mean(sum(HD,2),4))';

sum(diff(sum(HD,2),1,4).^2,'all') % all draws sum to the same TruePath

exlude_ST_first = false;
do_exptransform = true;

if do_exptransform

    HD_scales                     = [1/100,1/100,1,1,1/100];
    HD_exptransform               = [true,true,false,false,false];

else

    HD_scales                     = [1/100,1/100,1,1,1/100];
    HD_exptransform               = [false,false,false,false,false];

end


for ii=1:ni
    if HD_exptransform(ii)
        Y_tm1(ii)      = exp(HD_scales(ii)*Y_tm1(ii));
        HD(ii,:,:,:)   = exp(HD_scales(ii)*HD(ii,:,:,:));
        TruePath(:,ii) = exp(HD_scales(ii)*TruePath(:,ii));
    else
        Y_tm1(ii)      = HD_scales(ii)*Y_tm1(ii);
        HD(ii,:,:,:)   = HD_scales(ii)*HD(ii,:,:,:);
        TruePath(:,ii) = HD_scales(ii)*TruePath(:,ii);
    end
end

%%% 

CPath_ST        = nan(ni,H+1,model.nonEmptyDraw);
CPath_LT        = nan(ni,H+1,model.nonEmptyDraw);

if exlude_ST_first
    for ii = 1:ni
        if HD_exptransform(ii)
            CPath_ST(ii,:,:) = squeeze(prod(HD(ii,[2:6],:,:),2));
            CPath_LT(ii,:,:) = squeeze(prod(HD(ii,[3:6],:,:),2));
        else
            CPath_ST(ii,:,:) = squeeze(sum(HD(ii,[2:6],:,:),2));
            CPath_LT(ii,:,:) = squeeze(sum(HD(ii,[3:6],:,:),2));
        end
    end
else
    for ii = 1:ni
        if HD_exptransform(ii)
            CPath_ST(ii,:,:) = squeeze(prod(HD(ii,[3:6],:,:),2));
            CPath_LT(ii,:,:) = squeeze(prod(HD(ii,[1,3:6],:,:),2));
        else
            CPath_ST(ii,:,:) = squeeze(sum(HD(ii,[3:6],:,:),2));
            CPath_LT(ii,:,:) = squeeze(sum(HD(ii,[1,3:6],:,:),2));
        end
    end
end


CPath_ST_median = mean(CPath_ST,3);
CPath_ST_lbound = quantile(CPath_ST,(1-opt.aalpha)/2,3);
CPath_ST_ubound = quantile(CPath_ST,1-(1-opt.aalpha)/2,3);

CPath_LT_median = mean(CPath_LT,3);
CPath_LT_lbound = quantile(CPath_LT,(1-opt.aalpha)/2,3);
CPath_LT_ubound = quantile(CPath_LT,1-(1-opt.aalpha)/2,3);


monthString     = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]';
datestring      = monthString(month(dt))+" "+num2str(year(dt));



% One graph, no bands
VarsOfInterest = [1,2,3,5];
figure;
for jj = [2,1]

    if jj == 1
    HD_median=CPath_ST_median;
    HD_lbound=CPath_ST_lbound;
    HD_ubound=CPath_ST_ubound;
    elseif jj==2
    HD_median=CPath_LT_median;
    HD_lbound=CPath_LT_lbound;
    HD_ubound=CPath_LT_ubound;
    end

    for ii = 1:length(VarsOfInterest)
        
        subplot(2,2,ii)

        hold on
        
        if jj==1
        h1(ii) = plot(-1:H,[Y_tm1(VarsOfInterest(ii)),HD_median(VarsOfInterest(ii),:)],'-.','color',colorcodes(jj,:),'linewidth',2);
        elseif jj==2
        h2(ii) = plot(-1:H,[Y_tm1(VarsOfInterest(ii)),HD_median(VarsOfInterest(ii),:)],'--','color',colorcodes(jj,:),'linewidth',2);
        end

        if opt.PlotAlpha && jj==2

            h3(ii) = fill([-1:H,fliplr(-1:H)], [[Y_tm1(VarsOfInterest(ii)),HD_lbound(VarsOfInterest(ii),:)], fliplr([Y_tm1(VarsOfInterest(ii)),HD_ubound(VarsOfInterest(ii),:)])], colorcodes(jj,:),'facealpha',0.40,'edgealpha',0);

        end

        if jj==1
        hold on
        h4(ii) = plot(-1:H,[Y_tm1(VarsOfInterest(ii)),TruePath(:,VarsOfInterest(ii))'],'-k','linewidth',2);
        end

        if VarsOfInterest(ii)==5
        h5(ii) = plot(-1:H,zeros(1,H+2),':','color','k','linewidth',1.5);
        end

        grid on
        
        title(sprintf('%s',"\textbf{"+varnames{opt.ivar(VarsOfInterest(ii))})+"}",'interpreter','latex','FontSize',14);
        xlim([-1,H])
        xticks(0:3:(H+1))
        xticklabels(datestring(T0:3:T0+H));
        
    end

    if jj == 1
        subplot(2,2,1)
        if exlude_ST_first
            legend([h4(1),h1(1),h2(1)],["Realized path","Excl. ST Shocks","Excl. LT and ST"],'interpreter','latex','Fontsize',11,'location','ne')
        else
            legend([h4(1),h2(1),h1(1)],["Realized path","Excl. LT Shocks","Excl. LT and ST"],'interpreter','latex','Fontsize',11,'location','ne')
        end
    end

end
hold on

set(gcf, 'PaperUnits','points', 'PaperPosition',[0 0 560 420], 'PaperSize',[560 420]) % same printed size on any OS
print(sprintf("Fig6"),'-depsc');
print(sprintf("Fig6"),'-dpdf');





