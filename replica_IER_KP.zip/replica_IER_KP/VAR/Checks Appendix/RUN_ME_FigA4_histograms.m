
clear
close all
clc

addpath("../auxFunctions")

model              = load("../BASELINE_nonrobust/results baseline_nonrobust.mat");
model_nonarratives = load("nonarratives_nonrobust/results nonarratives_nonrobust.mat");


colorcodes             = [[0.4660 0.6740 0.1880];... % green
                          [0.6350 0.0780 0.1840]];

ExPostAnalysis         = true;

set(groot,'defaultAxesTickLabelInterpreter','latex');

ni         = model.ni;
nj         = model.nj;
opt        = model.opt;
irfUnits   = model.irfUnits;
varnames   = model.varnames;varnames{5}='Policy Rate';
shocknames = model.shocknames;
dates      = model.dates;

%% Narrative dates histograms
% date-specific shocks
datesOfInterest = [find(dates((opt.p+1):end) == datenum(2002,07,15));...
                   find(dates((opt.p+1):end) == datenum(2008,11,15));...
                   find(dates((opt.p+1):end) == datenum(2008,9,15));...
                   find(dates((opt.p+1):end) == datenum(2011,07,15));...
                   find(dates((opt.p+1):end) == datenum(2011,08,15))];

xlimss          = [-3.0,3.5;...
                   -4.5,4.5;...
                   -3.0,3.0;...
                   -3.0,3.0;...
                   -2.5,5.0];

monthString     = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]';
BinWidth        = 0.3;

figure;

for jj = 1:nj

    for ii = 1:length(datesOfInterest)
        
        subplot(2,5,(jj-1)*5+ii)

        h0 = histogram(model_nonarratives.rSinglePriorPost_EPS(:,datesOfInterest(ii),jj),'Normalization','pdf','FaceColor',[.7 .7 .7],'FaceAlpha',0.40,'EdgeColor',[.7 .7 .7],'EdgeAlpha',1,'BinWidth',BinWidth);
        hold on

        h1 = histogram(model.rSinglePriorPost_EPS(:,datesOfInterest(ii),jj),'Normalization','pdf','FaceColor',colorcodes(jj,:),'FaceAlpha',0.40,'EdgeColor',colorcodes(jj,:),'EdgeAlpha',1,'BinWidth',BinWidth);

        h2   = line([0,0],[0,1],'Color','k','LineStyle','--','LineWidth',1);

        ylim([0,0.8])
        datestr = monthString(month(datetime(dates(opt.p+datesOfInterest(ii)),'ConvertFrom','datenum')))+" "+num2str(year(datetime(dates(opt.p+datesOfInterest(ii)),'ConvertFrom','datenum')));
        if jj == 1
            title("\textbf{"+sprintf('%s',datestr)+"}",'interpreter','latex','FontSize',14);
        end
        if ii == 1
            ylabel("\textbf{"+shocknames{jj}+"s}",'interpreter','latex','FontSize',12)
        end

        if ii==1 && jj==1
            legend(["No NSR","Baseline"],'location','nw','interpreter','latex','Fontsize',8)
        end
        if ii==1 && jj==2
            legend(["No NSR","Baseline"],'location','nw','interpreter','latex','Fontsize',8)
        end

        xlim(xlimss(ii,:))
        set(gca,'ytick',[])
        set(gca,'yticklabel',[])
        
    end

end

set(gcf,'position',[375   418   619   237])
set(gcf,'PaperUnits','points','PaperPosition',[0 0 619 237],'PaperSize',[619 237]); % same printed size on any OS
print(sprintf("FigA4"),'-depsc'); print(sprintf("FigA4"),'-dpdf');



