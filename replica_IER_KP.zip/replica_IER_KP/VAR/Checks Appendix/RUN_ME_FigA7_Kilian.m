%% Plot impulse responses and fevds
clear
close all
clc

addpath("../auxFunctions")

model       = load("minnesota_nonrobust/results minnesota_nonrobust.mat"); 
model_prior = load("minnesotaprior_nonrobust/results minnesotaprior_nonrobust.mat"); 

colorcodes             = [[0.4660 0.6740 0.1880];... % green
                          [0.6350 0.0780 0.1840]];

set(groot,'defaultAxesTickLabelInterpreter','latex');

ni         = model.ni;
nj         = model.nj;
opt        = model.opt;
irfUnits   = model.irfUnits;
varnames   = model.varnames;varnames{5}='Policy Rate';
shocknames = model.shocknames;
dates      = model.dates;

% IMPULSE RESPONSE FUNCTIONS

% Two plots: One for vix response, one for macro response
varnames_short = ["VIX 1M","VIX 2Y","Unempl","Inflation","Policy Rate"];
shocknames_new = ["Short-term Shock","Long-term Shock","S3","S4","S5"];
ylimss         = [-05.00,15.00;...
                  -02.00,06.00;...
                  -00.20,00.35;...
                  -00.25,00.25;...
                  -37.50,15.00];

for xx = 3 %[1,2] change if making plots for slides / paper

    figure;

    if xx == 1
        tvars = [1,2];
    elseif xx == 2
        tvars = [3,4,5];
    elseif xx == 3
        tvars = [1,2,3,4,5];
    end

    for iix = 1:length(tvars)

        ii  = tvars(iix); 

        for jj = 1:nj

            subplot(length(tvars),2,(iix-1)*2+jj)

            h0 = plot(0:opt.H,zeros(1,1+opt.H),':k','linewidth',1.5);
            grid on
            hold on
            ylim(ylimss(ii,:))
    
            % Draws from Minnesota posterior
            h1 = plot(0:opt.H,model.rSinglePriorMean_IRF(:,ii,jj),'--','color',colorcodes(jj,:),'linewidth',2);
    
            if opt.PlotAlpha
    
                h2 = fill([0:opt.H,fliplr(0:opt.H)], [model.hpdlb_IRF(:,ii,jj)', fliplr(model.hpdub_IRF(:,ii,jj)')], colorcodes(jj,:),'facealpha',0.40,'edgealpha',0);
    
            end

            % Draws from Minnesota prior
            h3 = plot(0:opt.H,model_prior.rSinglePriorMean_IRF(:,ii,jj),'-.','color','k','linewidth',2);
    
            if opt.PlotAlpha
    
                h4 = fill([0:opt.H,fliplr(0:opt.H)], [model_prior.hpdlb_IRF(:,ii,jj)', fliplr(model_prior.hpdub_IRF(:,ii,jj)')], 'k','facealpha',0.20,'edgealpha',0);
                h5 = plot([0:opt.H,fliplr(0:opt.H)], [model_prior.hpdlb_IRF(:,ii,jj)', fliplr(model_prior.hpdub_IRF(:,ii,jj)')], '-k','LineWidth',1.2);

            end
            
            if iix == 1
                title(sprintf('%s',"\textbf{"+shocknames_new{jj}+"}"),'interpreter','latex','Fontsize',16);
                legend(["","Posterior Mean","","Prior Mean",""],'location','ne','interpreter','latex','FontSize',8)
            end

            xticks(0:12:opt.H);
            
            if jj == 1
                if irfUnits(opt.ivar(ii)) == 0
                    ylabel(varnames_short(ii)+" (\%)",'interpreter','latex','FontSize',14);
                elseif irfUnits(opt.ivar(ii)) == 1
                    ylabel(varnames_short(ii)+" (ppt)",'interpreter','latex','FontSize',14);
                elseif irfUnits(opt.ivar(ii)) == 2
                    ylabel(varnames_short(ii)+" (bps)",'interpreter','latex','FontSize',14);
                elseif irfUnits(opt.ivar(ii)) == 3
                    ylabel(varnames_short(ii)+" (lvl)",'interpreter','latex','FontSize',14)
                elseif irfUnits(opt.ivar(ii)) == 4
                    ylabel(varnames_short(ii)+" (stdd)",'interpreter','latex','FontSize',14)
                end
            end

        end

    end

end

if xx == 3
    set(gcf, 'Position', [309   138   559   659])
    set(gcf,'PaperUnits','points','PaperPosition',[0 0 559 659],'PaperSize',[559 659]); % same printed size on any OS
    print(sprintf("FigA7"),'-depsc'); print(sprintf("FigA7"),'-dpdf');
end




