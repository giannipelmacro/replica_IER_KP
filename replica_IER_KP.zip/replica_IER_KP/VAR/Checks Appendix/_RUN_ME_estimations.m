
% This file estimates all VARs associated to robustness checks and saves
% the results in mat file. This file has to be run before to plot any
% figure (hence before to run the files RUN_ME_FIG....m)

% This takes a lot of time


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   CHECKS   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% - baseline_robust:		    Baseline results with GKR robust bands
% - dec2022_nonrobust:		    Including Covid-19 data (Jeffreys Prior + Covid dummies)
% - dec2022PP_nonrobust:		Including Covid-19 data (Minnesota-based "Pandemic Prior")
% - minnesota_nonrobust:		Similar to baseline results, but with Minnesota prior.
% - minnesotaprior_nonrobust:	Same as above, but sampling from the prior, not the posterior.
% - nonarratives_nonrobust:   	Similar to baseline results, but without narrative restrictions.
% - nonarratives_robust:		Same as above, but with GKR robust bands.
% - IPgrowth_nonrobust:         Similar to baseline specification, but with IP growth replacing the unemployment rate
% - 1996_nonrobust :            Similar to baseline specification, but starting the sample in 1996m1
% - JLNfin_nonrobust:           Similar to baseline specification, but using LMN financial unc h1 & h12
% - JLNmacro_nonrobust:         Similar to baseline specification, but using LMN/JLN macro unc h1 & h12
% - VIX3M_nonrobust :           Similar to baseline specification, but with VIX3m rather than VIX1m (to get IRFs for DSGE comparison)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% No narrative SR, non robust

close all
clear

cd('nonarratives_nonrobust')

sendfile

cd('../')

%% GKR robust approach

close all
clear

cd('baseline_robust')

sendfile

cd('../')


%%  GKR robust approach, no narrative SR

close all
clear

cd('nonarratives_robust')

sendfile

cd('../')

%% Minnesota nonrobust

close all
clear

cd('minnesota_nonrobust')

sendfile

cd('../')

%% Up to Dec 2022, with Covid dummies

close all
clear

cd('dec2022_nonrobust')

sendfile

cd('../')

%% Up to Dec 2022, with CG's Pandemic Priors

close all
clear

cd('dec2022PP_nonrobust')

sendfile

cd('../')

%% Drawing from minnesota prior, Kilian, role of prior for results

close all
clear

cd('minnesotaprior_nonrobust')

sendfile

cd('../')

%% IP growth 

close all
clear

cd('IPgrowth_nonrobust')

sendfile

cd('../')

%% from 1996

close all
clear

cd('1996_nonrobust')

sendfile

cd('../')

%% LMN financial unc

close all
clear

cd('JLNfin_nonrobust')

sendfile

cd('../')

%% LMN/JLN macro unc

close all
clear

cd('JLNmacro_nonrobust')

sendfile

cd('../')


%% VIX3m

close all
clear

cd('VIX3M_nonrobust')

sendfile

cd('../')

