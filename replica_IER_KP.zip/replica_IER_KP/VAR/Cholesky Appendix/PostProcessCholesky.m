%% Plot impulse responses and fevds
clear
close all
clc

reverse_ordering = false;

if reverse_ordering
    nonrobust_cholesky     = load("results cholesky reverse.mat");
else
    nonrobust_cholesky     = load("results cholesky.mat");
end
nonrobust_LL               = load("results LL.mat");

set(groot,'defaultAxesTickLabelInterpreter','latex');

colorcodes             = [[0.6350 0.0780 0.1840];... % red
                          [0.4660 0.6740 0.1880]];   % green

ni         = nonrobust_cholesky.ni;
nj         = nonrobust_cholesky.nj;
opt        = nonrobust_cholesky.opt;
irfUnits   = nonrobust_cholesky.irfUnits;
varnames   = nonrobust_cholesky.varnames;
shocknames = nonrobust_cholesky.shocknames;
dates      = nonrobust_cholesky.dates;

% scaling factor for long-term uncertainty shock:
if reverse_ordering
    scale_ST   = 1
    scale_LT   = 1;
    scale_LL   = 1;
else
    scale_ST   = 10/nonrobust_cholesky.rSinglePriorMean_IRF(1,2,2);
    scale_LT   = 10/nonrobust_cholesky.rSinglePriorMean_IRF(1,2,1);
    scale_LL   = 10/nonrobust_LL.rSinglePriorMean_IRF(1,1);%/nonrobust_cholesky.rSinglePriorMean_IRF(1,2,1);
    fprintf("Unit stdd effects on short-term VIX [LT,ST,LL]:")
    [nonrobust_cholesky.rSinglePriorMean_IRF(1,2,1),nonrobust_cholesky.rSinglePriorMean_IRF(1,2,2),nonrobust_LL.rSinglePriorMean_IRF(1,1)]

end

% IMPULSE RESPONSE FUNCTIONS
%for jj = 1:nj

    figure;
    tiledlayout(3,2, 'TileSpacing', 'compact')

    for ii = 1:ni
        
        %subplot(ceil(ni/2),2,ii)
        nexttile
        h0 = plot(0:opt.H,zeros(1,1+opt.H),'-k','linewidth',1.2);
        hold on

        jj = 1;
        h1 = plot(0:opt.H,scale_LT*nonrobust_cholesky.rSinglePriorMean_IRF(:,ii,jj),'--','color',colorcodes(jj,:),'linewidth',2,'DisplayName',"Five Variables (1st Order)");
        h2 = fill([0:opt.H,fliplr(0:opt.H)], scale_LT*[nonrobust_cholesky.hpdlb_IRF(:,ii,jj)', fliplr(nonrobust_cholesky.hpdub_IRF(:,ii,jj)')], colorcodes(jj,:),'facealpha',0.40,'edgealpha',0);

        jj = 2;
        h3 = plot(0:opt.H,scale_ST*nonrobust_cholesky.rSinglePriorMean_IRF(:,ii,jj),'-.','color',colorcodes(jj,:),'linewidth',2,'DisplayName',"Five Variables (2nd Order)");
        h4 = fill([0:opt.H,fliplr(0:opt.H)], scale_ST*[nonrobust_cholesky.hpdlb_IRF(:,ii,jj)', fliplr(nonrobust_cholesky.hpdub_IRF(:,ii,jj)')], colorcodes(jj,:),'facealpha',0.40,'edgealpha',0);

        % Leduc and Liu
        if ii>1
        h5 = plot(0:opt.H,scale_LL*nonrobust_LL.rSinglePriorMean_IRF(:,ii-1,1),'-','color','black','linewidth',2,'DisplayName',"Four Variables (1st Order)");
        end
        if irfUnits(opt.ivar(ii)) == 0
            ylabel('\%','interpreter','latex');
        elseif irfUnits(opt.ivar(ii)) == 1
            ylabel('ppt','interpreter','latex');
        elseif irfUnits(opt.ivar(ii)) == 2
            ylabel('bps','interpreter','latex');
        elseif irfUnits(opt.ivar(ii)) == 3
            ylabel('lvl','interpreter','latex')
        elseif irfUnits(opt.ivar(ii)) == 4
            ylabel('std dev','interpreter','latex')
        end
        
        title(sprintf('%s',"\textbf{"+varnames{opt.ivar(ii)})+"}",'interpreter','latex');
        %xlabel('Horizon (months)');
        xticks(0:12:opt.H);
        
        Ax = gca;
        Ax.FontSize = 14;
        
    end
    nexttile
    set(gca,'XColor', 'none','YColor','none')
    lg = legend(nexttile(6), [h5,h1,h3],'interpreter','latex','location','w','fontsize',11);

    if reverse_ordering
        print(sprintf("ReverseCholeskyShocks"),'-depsc');
    else
        set(gcf,'PaperUnits','points','PaperPosition',[0 0 560 420],'PaperSize',[560 420]); % same printed size on any OS
        print(sprintf("FigA3"),'-depsc'); print(sprintf("FigA3"),'-dpdf');
    end
