tic

%% Construct data for estimating VAR for y_t.
YY = data(opt.p+1:end,:); % y_t 
XX = lagmatrix(data,1:opt.p); % Matrix of regressors in VAR for y_t
XX = XX(opt.p+1:end,:); % Drop initial missing observations
if opt.const == 1 % Add constant to matrix of regressors
    XX = [XX ones(size(XX,1),1)];
end

% Add covid dummies
[XX, covid_flag] = CovidDummies(XX,opt.covid_periods,dt(opt.p+1:end));
if covid_flag==0
opt.covid_periods = 0;
end

% Add exogenous variables to matrix of regressors
%XX = [XX exog(opt.p+1:end,:)]; 

n = size(YY,2); % Number of variables
ni = length(opt.ivar); % Number of variables of interest
nj = length(opt.jshock); % Number of shocks of interest
m = size(XX,2); % Number of parameters in each equation for y_t
nExog = opt.const+covid_flag*opt.covid_periods;% + size(exog,2); % Number of exogenous variables
T = length(YY); % Number of observations used in estimating VAR

% Adjust indices representing narrative restrictions to account for
% losing the first p observations. If the restrictions are imposed in the 
% first p periods of the original dataset, drop the restrictions.
if ~isempty(restr.shockSignRestr)
    restr.shockSignRestr(:,3) = restr.shockSignRestr(:,3) - opt.p;
    restr.shockSignRestr(restr.shockSignRestr(:,3) <= 0) = [];
end
if ~isempty(restr.hdSignRestr)
    restr.hdSignRestr(:,3) = restr.hdSignRestr(:,3) - opt.p;
    restr.hdSignRestr(restr.hdSignRestr(:,3) <= 0) = [];
end
if ~isempty(restr.hdJointSignRestr)
    restr.hdJointSignRestr(:,3) = restr.hdJointSignRestr(:,3) - opt.p;
    restr.hdJointSignRestr(restr.hdJointSignRestr(:,3) <= 0) = [];
end

%% Conduct posterior inference on impulse responses.
% j-th column of B gives MLE of coefficients in j-th reduced form VAR 
% equation for y_t. Last rows correspond to exogenous terms (if included).

if opt.PriorType == "Jeffreys" % Jeffreys / Flat Prior

    phiHat.B     = (XX'*XX)\XX'*YY;
    phiHat.S     = (YY - XX*phiHat.B)'*(YY-XX*phiHat.B);
    phiHat.Sigma = (1/T)*phiHat.S; % MLE of innovation covariance matrix
    phiHat.P     = (XX'*XX)\eye(m);
    phiHat.cholP = chol(phiHat.P,'lower');
    phiHat.NUM   = size(XX,1)-size(XX,2);

elseif opt.PriorType == "PP"   % Pandemic (or Minnesota) Prior

    opt.PPphi = getPhiOptPP(XX,YY,data,opt,covid_flag);


    [Xst, Yst, xd, yd] = pandemicpriors(XX,YY,data,opt.p,opt.const,opt.diff_or_lv,opt.lambda,opt.tau,opt.epsilon,opt.PPphi,opt.covid_periods);
    XXst               = xd'*xd + XX'*XX;
    invXXst            = (XXst)\eye(size(XXst,2)); % inv(XXst)
    XYst               = xd'*yd + XX'*YY;

    phiHat.B           = invXXst*XYst;
    phiHat.S           = (Yst - Xst*phiHat.B)'*(Yst - Xst*phiHat.B);
    phiHat.Sigma       = (1/size(Xst,1))*phiHat.S; % MLE of innovation covariance matrix
    phiHat.P           = invXXst;
    phiHat.cholP       = chol(phiHat.P,'lower');
    phiHat.NUM         = size(Xst,1)+2-size(Xst,2);
    
elseif opt.PriorType == "PriorSampling" % Sampling from the Minnesota Prior
    
    opt.PPphi = getPhiOptPP(XX,YY,data,opt,covid_flag);

    [Xst, Yst, xd, yd] = pandemicpriors(XX,YY,data,opt.p,opt.const,opt.diff_or_lv,opt.lambda,opt.tau,opt.epsilon,opt.PPphi,opt.covid_periods);
    XXd                = xd'*xd;
    invXXd             = (XXd)\eye(size(XXd,2)); % inv(XXst)
    XYd                = xd'*yd;

    phiHat.B           = invXXd*XYd;
    phiHat.S           = (yd - xd*phiHat.B)'*(yd - xd*phiHat.B);
    phiHat.Sigma       = (1/size(xd,1))*phiHat.S; % innovation covariance matrix
    phiHat.P           = invXXd;
    phiHat.cholP       = chol(phiHat.P,'lower');
    phiHat.NUM         = size(xd,1)-size(xd,2);

end


% Storage arrays.
rMinPost_IRF         = zeros(opt.phiDraws,opt.H+1,ni,nj);
rMaxPost_IRF         = zeros(opt.phiDraws,opt.H+1,ni,nj);

rMinPost_FEV         = zeros(opt.phiDraws,opt.H+1,ni,nj);
rMaxPost_FEV         = zeros(opt.phiDraws,opt.H+1,ni,nj);

rMinPost_EPS         = zeros(opt.phiDraws,T,nj);
rMaxPost_EPS         = zeros(opt.phiDraws,T,nj);

rSinglePriorPost_IRF = zeros(opt.phiDraws,opt.H+1,ni,nj);
rSinglePriorPost_FEV = zeros(opt.phiDraws,opt.H+1,ni,nj);
rSinglePriorPost_EPS = zeros(opt.phiDraws,T,nj);

B = zeros(n*m,opt.phiDraws);
Sigma = zeros(n,n,opt.phiDraws);
irf_tmp = zeros(ni,ni,opt.H+1);
fev_tmp = zeros(ni,ni,opt.H+1);
eps_tmp = zeros(T,ni);

phiDraw = 0; % Counter for no. of draws from posterior of phi
nonStableCount = 0; % Counter for no. of draws with nonstable VAR
nonEmptyDraw = 0; % Counter for no. of draws with non-empty IS

while nonEmptyDraw < opt.phiDraws

    % Posterior sampler
    phi.Sigma      = iwishrnd(phiHat.S,phiHat.NUM);
    phi.Sigmatr    = chol(phi.Sigma,'lower');
    phi.Sigmatrinv = phi.Sigmatr\eye(n);
    phi.B          = phiHat.B(:) + kron(phi.Sigmatr,phiHat.cholP)*randn(m*n,1);

    % Generate coefficients in orthogonal reduced-form VMA representation 
    % and check stability of VAR.
    [phi.vma,nonStable] = genVMA(phi,opt,nExog);
    nonStableCount = nonStableCount + nonStable;
    
    % If VAR is stable, proceed. Otherwise, redraw phi.
    
    if nonStable == 0
        
    phiDraw = phiDraw + 1;
    
    % Compute reduced-form VAR innovations.
    restr.U = (YY - XX*reshape(phi.B,m,n))';
        
    % Use Algorithm 1 (Step 2) to determine whether Q(phi|N,S) is nonempty
    % and draw Q satisfying restrictions.
    [Q0,restr.SS,restr.S,Qempty(phiDraw)] = drawQ(restr,phi,opt);
    
    Q0              = eye(n);
    Qempty(phiDraw) = 0;

    if Qempty(phiDraw) == 0 % If Q(phi|N,S) is non-empty
            
            % Store reduced-form parameters.
            nonEmptyDraw = nonEmptyDraw + 1;
            Sigma(:,:,nonEmptyDraw) = phi.Sigma;
            B(:,nonEmptyDraw) = phi.B;

            % Compute draw of the indivifual shocks given conditionally
            % uniform prior for Q|phi
            eps_tmp                                = Q0'*phi.Sigmatrinv*restr.U;
            rSinglePriorPost_EPS(nonEmptyDraw,:,:) = eps_tmp(opt.jshock,:)';

            % Compute draw from posterior of impulse responses given 
            % conditionally uniform prior for Q|phi.
            
            for hh = 1:opt.H+1 % For each horizon
    
                % Compute impulse response
                %rSinglePriorPost(nonEmptyDraw,hh,:,:) = ...
                %    phi.vma(opt.ivar,:,hh)*Q0(:,opt.jshock);

                % Compute impulse response.
                irf_tmp(:,:,hh)                           = phi.vma(opt.ivar,:,hh)*Q0;
                rSinglePriorPost_IRF(nonEmptyDraw,hh,:,:) = irf_tmp(:,opt.jshock,hh);

            end

            % Get also forecast error variance decompositions
            fev_tmp                                  = getFEVDs(irf_tmp);
            rSinglePriorPost_FEV(nonEmptyDraw,:,:,:) = permute(fev_tmp(:,opt.jshock,:),[3,1,2]);
            
            % Find upper and lower bounds of conditional identified set
            if opt.doRobust
                [rMinPost_IRF(nonEmptyDraw,:,:,:),rMaxPost_IRF(nonEmptyDraw,:,:,:),...
                 rMinPost_FEV(nonEmptyDraw,:,:,:),rMaxPost_FEV(nonEmptyDraw,:,:,:),...
                 rMinPost_EPS(nonEmptyDraw,:,:),rMaxPost_EPS(nonEmptyDraw,:,:)] = ...
                      approximateBounds_fevd(restr,phi,opt);
            end

            if mod(opt.phiDraws-nonEmptyDraw,opt.dispIter) == 0
              
                   fprintf('\n%d draws with non-empty identified set remaining...',...
                  opt.phiDraws-nonEmptyDraw);
               
            end

    end
    
    end
    
end

%%%
 
% Compute cumulative impulse response for draws under single prior where
% necessary (NOTE THAT FEVDs ARE NOT CUMULATIVE IN THIS CODE)
if ~isempty(opt.cumIR)
    rSinglePriorPost_IRF(:,:,opt.cumIR,:) = ...
        cumsum(rSinglePriorPost_IRF(:,:,opt.cumIR,:),2);
end

% Compute posterior mean under single prior.
rSinglePriorMean_IRF = permute(mean(rSinglePriorPost_IRF,1),[2 3 4 1]);
rSinglePriorMean_FEV = permute(mean(rSinglePriorPost_FEV,1),[2 3 4 1]);
rSinglePriorMean_EPS = permute(mean(rSinglePriorPost_EPS,1),[2 3 1]);

% Compute highest posterior density (HPD) interval under single prior.
[hpdlb_IRF,hpdub_IRF] = highestPosteriorDensity(rSinglePriorPost_IRF,opt);
[hpdlb_FEV,hpdub_FEV] = highestPosteriorDensity(rSinglePriorPost_FEV,opt);
[hpdlb_EPS,hpdub_EPS] = highestPosteriorDensity_eps(rSinglePriorPost_EPS,opt);

% Compute highest posterior density (HPD) interval under single prior, high alpha.
[hpdlbL_IRF,hpdubL_IRF] = highestPosteriorDensityL(rSinglePriorPost_IRF,opt);
[hpdlbL_FEV,hpdubL_FEV] = highestPosteriorDensityL(rSinglePriorPost_FEV,opt);
[hpdlbL_EPS,hpdubL_EPS] = highestPosteriorDensityL_eps(rSinglePriorPost_EPS,opt);

if opt.doRobust
    % Compute lower and upper bound of set of posterior means.
    meanlb_IRF = permute(mean(rMinPost_IRF,1),[2 3 4 1]);
    meanub_IRF = permute(mean(rMaxPost_IRF,1),[2 3 4 1]);
    
    meanlb_FEV = permute(mean(rMinPost_FEV,1),[2 3 4 1]);
    meanub_FEV = permute(mean(rMaxPost_FEV,1),[2 3 4 1]);
    
    meanlb_EPS = permute(mean(rMinPost_EPS,1),[2 3 1]);
    meanub_EPS = permute(mean(rMaxPost_EPS,1),[2 3 1]);
    
    % Compute robustified credible regions.
    [credlb_IRF,credub_IRF] = credibleRegion(rMinPost_IRF,rMaxPost_IRF,opt);
    [credlb_FEV,credub_FEV] = credibleRegion(rMinPost_FEV,rMaxPost_FEV,opt);
    [credlb_EPS,credub_EPS] = credibleRegion_eps(rMinPost_EPS,rMaxPost_EPS,opt);
    
    % Compute posterior plausibility of the identifying restrictions.
    postPlaus = (1 - sum(Qempty)/length(Qempty));
    fprintf('\nPosterior plausibility of identifying restrictions: %0.4g.\n',...
        postPlaus)
    
    postMeanBoundWidth_IRF = meanub_IRF - meanlb_IRF; % Width of posterior mean bounds.
    hpdWidth_IRF = hpdub_IRF - hpdlb_IRF; % Width of highest posterior density regions
    credWidth_IRF = credub_IRF - credlb_IRF; % Width of robustified credible region
    
    priorInformativeness_IRF = 1 - hpdWidth_IRF./credWidth_IRF; % Informativeness of prior
    
    postMeanBoundWidth_FEV = meanub_FEV - meanlb_FEV; % Width of posterior mean bounds.
    hpdWidth_FEV = hpdub_FEV - hpdlb_FEV; % Width of highest posterior density regions
    credWidth_FEV = credub_FEV - credlb_FEV; % Width of robustified credible region
    
    priorInformativeness_FEV = 1 - hpdWidth_FEV./credWidth_FEV; % Informativeness of prior
    
    postMeanBoundWidth_EPS = meanub_EPS - meanlb_EPS; % Width of posterior mean bounds.
    hpdWidth_EPS = hpdub_EPS - hpdlb_EPS; % Width of highest posterior density regions
    credWidth_EPS = credub_EPS - credlb_EPS; % Width of robustified credible region
    
    priorInformativeness_EPS = 1 - hpdWidth_EPS./credWidth_EPS; % Informativeness of prior
end

% Proportion of original draws where VAR is not stable.
nonStablePc = nonStableCount/(nonStableCount+phiDraw)*100;
fprintf('\nVAR representation unstable in %2.2f per cent of draws. \n',...
    nonStablePc);

runTime = toc