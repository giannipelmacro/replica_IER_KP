% Estimate the SVAR with short- and long-term uncertainty shocks via Bayesian
% methods. Consider both a uniform prior over Q|phi and the prior-robust approach.
% Codes are obtained from the replication files to Antolin-Diaz and
% Rubio-Ramirez (2018, AER), available on Juan Antolin-Diaz's website:
% https://sites.google.com/site/juanantolindiaz/

% written by Mathias Krogh

clear variables
close all
clc

addpath('../auxFunctions');

appndx = "baseline_nonrobust";

%% Restrictions applied
useTraditional = true;
useHL          = true;
useFEVD        = false;

useShockSign   = true;
useHD          = true;
useHDJ         = true;


%% Import data.
% Data are built by VAR/_raw data/getdata.m and stored in VAR/data.mat.
% The variables are:
% 1) Short-term VIX 2) Long-term VIX 3) Unemployment rate
% 4) YoY CPI inflation 5) Federal funds rate
datastruct  = load('../data.mat');
data        = [datastruct.VIX1,datastruct.VIX24,datastruct.UR,datastruct.INFL,100*datastruct.IR2];
data(:,1:2) = 100*log(data(:,1:2));
dates       = datenum(datastruct.dt);
dt          = datastruct.dt;
% cut data
idx   = 49:length(dates)-34; % starts in Jan 2000 (subtract 34 for feb 2020)

data  = data(idx,:);
dates = dates(idx);
dt    = dt(idx);



% Set variable names for plotting figures.
varnames = {'Short-term VIX','Long-term VIX','Unemployment Rate',...
            'YoY CPI Inflation','Federal Funds Rate'};
shocknames = {'ST shock','LT shock','S3','S4','S5'};
% Set units for impulse responses. 0 = %, 1 = ppt, 2 = bps, 3 = lvl., 4 =
% std dev
irfUnits = [0 0 1 1 2];

%% Options.
opt.p = 12;             % No. of lags in VAR
opt.const = 1;          % const = 1 if constant in VAR, = 0 otherwise
opt.ivar = [1 2 3 4 5]; % Indices of variables of interest
opt.cumIR = [];         % Indices of variables for which cumulative impulse response should be used
opt.jshock = [1 2];     % Indices of structural shocks of interest
opt.H = 60;             % Terminal horizon for impulse responses
opt.phiDraws = 5000;    % No. of draws from posterior of phi with non-empty identified set
opt.aalpha  = 0.68;     % Credibility level for credible intervals
opt.aalphaL = 0.90;     % Credibility level for credible intervals
opt.maxDraw = 100000;   % Max no. of draws from O(n) when checking empty identified set
opt.KTilde = 1000;        % No. of draws of Q used in Algorithm 1
opt.dispIter = 1;       % Print number of draws remaining every dispIter draws
opt.gridLength = 1000;  % Size of grid used when computing credible intervals
opt.doRobust   = false;  % Should the robust intervals be calculated?
opt.PlotAlpha  = true;  % Plot the low alpha single-prior interval?
opt.PlotAlphaL = false;  % Plot the high alpha single-prior interval?

% Helpers
opt.PriorType      = "Jeffreys";   % Jeffreys if uninformative, PP if Pandemic/Minnesota Prior, PriorSampling if sampling from Minnesota Prior instead of posterior.
opt.diff_or_lv     = 1;      % In case of Minnesota prior: 1 if in levels
opt.lambda         = 0.2;    % In case of Minnesota prior: Prior tightness
opt.tau            = 10*opt.lambda;
opt.epsilon        = 0.001;  % In case of Minnesota prior: Prior for constant
opt.PPphiOpt       = true;   % In case of Pandemic prior: choose optimal phi
opt.PPphi          = 999;    % In case of Pandemic prior: If PPphiOpt = false
opt.covid_periods  = 6;      % In case of Pandemic prior: Number of periods. Set to 0 if Minnesota Prior.d

rng(1264537); % Set seed for random number generator

%% Input identifying restrictions and narrative restrictions.

% Each row of shockSignRestr contains a vector (i,s,t) representing the
% shock-sign restriction that the ith shock in period t is >= 0 (s = 1) or
% <= 0 (s = -1). t is equal to the index of the observation.
if useShockSign
    restr.shockSignRestr = [1 1 find(dates == datenum(2002,07,15)); % ST shock in July 2002
                            2 1 find(dates == datenum(2008,11,15)); % LT shock in November 2008 
                            2 1 find(dates == datenum(2008,09,15));
                            1 1 find(dates == datenum(2008,09,15));
			    2 1 find(dates == datenum(2011,07,15));
                            1 1 find(dates == datenum(2011,07,15));
			    2 1 find(dates == datenum(2011,08,15));
                            1 1 find(dates == datenum(2011,08,15))];
    restr.andOrMatrix    = [1,0,0,0,0,0,0,0;
                            0,1,0,0,0,0,0,0;
                            0,0,1,1,0,0,0,0;
		            0,0,0,0,1,1,0,0;
		            0,0,0,0,0,0,1,1];
else
    restr.shockSignRestr = []; % No shock-sign restrictions
    restr.andOrMatrix    = eye(size(restr.shockSignRestr,1));
end



% Each row of hdSignRestr contains a vector (i,j,t,h,k,s) representing a
% narrative restriction on the historical decomposition. 
% k represents the class of restriction (Type A or Type B) and s represents
% the type of restriction within the class.
% k = 1: Type A restriction
%  - s = 1:  The jth shock is the 'most important contributor' to the 
%   change in the ith variable between periods t and  t+h.
%  - s = -1: The jth shock is the 'least important contributor' to the
%   change in the ith variable between periods t and t+h.
% k = 2: Type B restriction
%  - s = 1: The jth shock is the 'overwhelming contributor' to the change
%   in the ith variable between periods t and t+h.
% - s = -1: The jth shock is a 'negligible contributor' to the change in
%   the ith variable between periods t and t+h.
if useHD
    restr.hdSignRestr = [1 1 find(dates == datenum(2002,07,15)) 0 1 1;
                         2 2 find(dates == datenum(2008,11,15)) 0 1 1];
else
    restr.hdSignRestr = [];
end


% Each row of hdJointSignRestr contains a vector (i,j,t,h,k,s) 
% representing a narrative restriction on the historical decomposition. 
% s represents the type of restriction:
%  - s = 1:  The first j shocks are the 'overwhelming contributors' to the 
%    change in the ith variable between periods t and t+h.
%  - s = -1: The first j shocks are the 'negligible contributors' to the 
%    change in the ith variable between periods t and t+h.
if useHDJ
    restr.hdJointSignRestr = [1 2 find(dates == datenum(2008,09,15)) 0 1;
                              2 2 find(dates == datenum(2008,09,15)) 0 1];
else
    restr.hdJointSignRestr = [];
end



% Each row of signRestr contains a vector (i,j,h,s,t) representing a
% 'traditional' sign restriction, where t is the type of restriction:
% t = 1: the impulse response of the ith variable to the jth shock at the 
% hth horizon is nonnegative (s = 1) or nonpositive (s = -1).
% t = 2: the (ij)th element of A0 is nonnegative (s = 1) or nonpositive 
% (s = -1). 
if useTraditional
    restr.signRestr = [1 2 0  1 1;  % Response of VIX1M to LT shock is nonnegative
		       1 2 1  1 1
		       1 2 2  1 1
		       1 2 3  1 1
		       1 2 4  1 1
		       1 2 5  1 1
		       1 2 6  1 1
		       1 2 7  1 1
		       1 2 8  1 1
		       1 2 9  1 1
		       1 2 10 1 1
		       1 2 11 1 1
		       1 2 12 1 1
		       %%%%%%%%%%
		       2 2 0  1 1   % response of VIX2Y to LT shock is nonnegative
		       2 2 1  1 1
		       2 2 2  1 1
		       2 2 3  1 1
		       2 2 4  1 1
		       2 2 5  1 1
		       2 2 6  1 1
		       2 2 7  1 1
		       2 2 8  1 1
		       2 2 9  1 1
		       2 2 10 1 1
		       2 2 11 1 1
		       2 2 12 1 1
		       %%%%%%%%%%
		       2 1 0  1 1
		       2 1 1  1 1   % response of VIX2Y to ST shock is nonnegative
		       2 1 2  1 1
		       2 1 3  1 1
		       2 1 4  1 1
		       2 1 5  1 1
		       2 1 6  1 1
		       2 1 7  1 1
		       2 1 8  1 1
		       2 1 9  1 1
		       2 1 10 1 1
		       2 1 11 1 1
		       2 1 12 1 1
		       %%%%%%%%%%
		       1 1 0  1 1   % response of VIX1M to ST shock is nonnegative
		       1 1 1  1 1
		       1 1 2  1 1
		       1 1 3  1 1
		       1 1 4  1 1
		       1 1 5  1 1
		       1 1 6  1 1
		       1 1 7  1 1
		       1 1 8  1 1
		       1 1 9  1 1
		       1 1 10 1 1
		       1 1 11 1 1
		       1 1 12 1 1];
else
    restr.signRestr = []; % No sign restrictions on impulse responses
end

% Each row of hlSignRestr contains a vector (i,j,ii,jj) representing a
% half life restriction: the impulse response of the ith variable to the 
% jth shock has greater half life than the impulse response of the iith 
% variable to the jjth shock.
if useHL
    restr.hlSignRestr = [1 2 1 1;  % LT shock has more persistent effect on VIX1M than ST shock 
                         2 2 2 1]; % LT shock has more persistent effect on VIX2Y than ST shock

else
    restr.hlSignRestr = []; % No half life restrictions on impulse responses
end


% Each row of ratioSignRestr contains a vector (i,j,ii,jj,h) representing a
% ratio restriction: the h-horizon impulse response of the ith variable to
% the jth shock is greater than the h-horizon impulse response of the
% iith variable to the jjth shock.
restr.ratioSignRestr = []; % No half life restrictions on impulse responses


% Each row of corrSignRestr contains a vector (j,s) representing a shock
% correlation restriction: Shock j is positively correlated with stock
% returns if s=1 and negatively correlated if s =-1.
restr.corrSignRestr=[];
restr.ExternalVar    = [];%SPret(opt.p+1:end);

% Impose the FEVD restrictions or not
restr.fevdRestr = useFEVD;

%% Conduct (robust) posterior inference.
mainfile;


save("results " + appndx +".mat");

%% Plot impulse responses and fevds
close all
load("results " + appndx +".mat");

% IMPULSE RESPONSE FUNCTIONS
for jj = 1:nj

    figure;

    for ii = 1:ni
        
        subplot(ceil(ni/2),2,ii)
        
        h1 = plot(0:opt.H,rSinglePriorMean_IRF(:,ii,jj),'ko','MarkerFaceColor','k');
        hold on

        if opt.PlotAlpha
            h2S = plot(0:opt.H,hpdlb_IRF(:,ii,jj),'--k','LineWidth',2);
            h3S = plot(0:opt.H,hpdub_IRF(:,ii,jj),'--k','LineWidth',2);
        end

        if opt.PlotAlphaL
            h2L = plot(0:opt.H,hpdlbL_IRF(:,ii,jj),'--k','LineWidth',2);
            h3L = plot(0:opt.H,hpdubL_IRF(:,ii,jj),'--k','LineWidth',2);
        end

        if opt.doRobust

            h4 = plot(0:opt.H,meanub_IRF(:,ii,jj),'color','k','LineStyle','--');
            h5 = plot(0:opt.H,meanlb_IRF(:,ii,jj),'color','k','LineStyle','--');

            h6 = plot(0:opt.H,credlb_IRF(:,ii,jj),'-k','LineWidth',2);
            h7 = plot(0:opt.H,credub_IRF(:,ii,jj),'-k','LineWidth',2);

            for hh = 0:opt.H
                line([hh hh],[meanlb_IRF(hh+1,ii,jj) meanub_IRF(hh+1,ii,jj)],'color','k');
            end
    
            line([0 opt.H],[0 0],'color','black','LineStyle',':');

        end
        
        if irfUnits(opt.ivar(ii)) == 0
            ylabel('%');
        elseif irfUnits(opt.ivar(ii)) == 1
            ylabel('ppt');
        elseif irfUnits(opt.ivar(ii)) == 2
            ylabel('bps');
        elseif irfUnits(opt.ivar(ii)) == 3
            ylabel('lvl')
        elseif irfUnits(opt.ivar(ii)) == 4
            ylabel('std dev')
        end
        
        title(sprintf('%s',varnames{opt.ivar(ii)}));
        xticks(0:12:opt.H);
        
        Ax = gca;
        Ax.FontSize = 14;
        
    end

    sgtitle(sprintf("IRF: "+shocknames{jj}))

end


% FORECAST ERROR VARIANCE DECOMPOSITIONS
for jj = 1:nj

    figure;

    for ii = 1:ni
        
        subplot(ceil(ni/2),2,ii)

        h1 = plot(0:opt.H,rSinglePriorMean_FEV(:,ii,jj),'ko','MarkerFaceColor','k');
        hold on

        if opt.PlotAlpha
            h2S = plot(0:opt.H,hpdlb_FEV(:,ii,jj),'--k','LineWidth',2);
            h3S = plot(0:opt.H,hpdub_FEV(:,ii,jj),'--k','LineWidth',2);
        end

        if opt.PlotAlphaL
            h2L = plot(0:opt.H,hpdlbL_FEV(:,ii,jj),':k','LineWidth',2);
            h3L = plot(0:opt.H,hpdubL_FEV(:,ii,jj),':k','LineWidth',2);
        end

        if opt.doRobust

            h4 = plot(0:opt.H,meanub_FEV(:,ii,jj),'color','k','LineStyle','--');
            h5 = plot(0:opt.H,meanlb_FEV(:,ii,jj),'color','k','LineStyle','--');

            h6 = plot(0:opt.H,credlb_FEV(:,ii,jj),'-k','LineWidth',2);
            h7 = plot(0:opt.H,credub_FEV(:,ii,jj),'-k','LineWidth',2);

            for hh = 0:opt.H
                line([hh hh],[meanlb_FEV(hh+1,ii,jj) meanub_FEV(hh+1,ii,jj)],'color','k');
            end
    
            line([0 opt.H],[0 0],'color','black','LineStyle',':');

        end
        
        ylim([0,1])
        
        title(sprintf('%s',varnames{opt.ivar(ii)}));
        xticks(0:12:opt.H);
        
        Ax = gca;
        Ax.FontSize = 14;
        
    end

    sgtitle(sprintf("FEVD: "+shocknames{jj}))

end


% date-specific shocks
datesOfInterest = [find(dates((opt.p+1):end) == datenum(2002,07,15));...
                   find(dates((opt.p+1):end) == datenum(2008,11,15));...
                   find(dates((opt.p+1):end) == datenum(2008,10,15));...
                   find(dates((opt.p+1):end) == datenum(2008,9,15))];

monthString     = ["January","February","March","April","May","June","July","August","September","October","November","December"]';

for jj = 1:nj

    figure;

    for ii = 1:length(datesOfInterest)
        
        subplot(ceil(sqrt(length(datesOfInterest))),ceil(sqrt(length(datesOfInterest))),ii)

        h1 = histogram(rSinglePriorPost_EPS(:,datesOfInterest(ii),jj),'Normalization','pdf');
        if opt.doRobust
            hold on
            h2 = histogram(rMinPost_EPS(:,datesOfInterest(ii),jj),'Normalization','pdf');
            hold on
            h3 = histogram(rMaxPost_EPS(:,datesOfInterest(ii),jj),'Normalization','pdf');
        end
        
        datestr = monthString(month(datetime(dates(opt.p+datesOfInterest(ii)),'ConvertFrom','datenum')))+" "+num2str(year(datetime(dates(opt.p+datesOfInterest(ii)),'ConvertFrom','datenum')));
        title(sprintf('%s',datestr));

        Ax = gca;
        Ax.FontSize = 14;
        
    end

    sgtitle(sprintf("Shocks: "+shocknames{jj}))

end


