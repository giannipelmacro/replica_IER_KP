% Author: Mathias Krogh
% Date:   July 2023

% This function appends covid dummies to the X matrix
%
% Input:
% - X:              the starting point matrix
% - ncovid :        the amount of covid dummies
% - dt:             vector with date-time description of time-periods
%
% Output:
% - X_d:            the end point matrix
% - covid_flag:     1 if covid is in the sample, 0 else.

function [X_d,covid_flag] = CovidDummies(X,ncovid,dt)

    covid_ind  = datefind(datetime(2020,3,15),dt);
    covid_flag = not(isempty(covid_ind))*1;

    if ncovid > 0 && covid_flag==1
    
        X_d   = [X, zeros(size(X,1),ncovid)];
        
        X_d(covid_ind:covid_ind+ncovid-1,end-ncovid+1:end) = eye(ncovid);
    
    else
    
        X_d   = X;
    
    end

end