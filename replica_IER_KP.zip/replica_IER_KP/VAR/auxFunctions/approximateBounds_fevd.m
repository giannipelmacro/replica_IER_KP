function [rmin_irf,rmax_irf,rmin_fev,rmax_fev,rmin_eps,rmax_eps] = approximateBounds_fevd(restr,phi,opt)
% Approximate bounds of the conditional identified set via simulation.
% Inputs:
% - restr: structure containing information about restrictions
% - phi: structure containing reduced-form VAR parameters
% - opt: structure containing model information and options

H = opt.H;
ivar = opt.ivar;
jshock = opt.jshock;
KTilde = opt.KTilde;
vma = phi.vma;
cumIR = opt.cumIR;
T     = size(restr.U,2);

% Draw from space of orthonormal matrices satisfying the restrictions 
% KTilde times.
Q0 = drawQ0(restr,phi,opt);

% Compute impulse responses for each draw of Q.
etaDraw_irf = zeros(H+1,length(ivar),length(ivar),KTilde);
etaDraw_fev = zeros(H+1,length(ivar),length(ivar),KTilde);
etaDraw_eps = zeros(T,length(ivar),KTilde);

for hh = 1:H+1 % For each horizon

    % Extract required rows of horizon-h VMA coefficient matrix.
    Cphi = vma(ivar,:,hh);
    % Multiply by relevant columns of Q0 (for each draw of Q0) to obtain
    % impulse response.
    etaDraw_irf(hh,:,:,:) = pagemtimes(Cphi,Q0);

end

for i = 1:KTilde
    etaDraw_fev(:,:,:,i) = permute(getFEVDs(permute(etaDraw_irf(:,:,:,i),[2,3,1])),[3,1,2]);
    etaDraw_eps(:,:,i)   = (Q0(:,:,i)'*phi.Sigmatrinv*restr.U)';
end
 
etaDraw_irf = etaDraw_irf(:,:,jshock,:);
etaDraw_fev = etaDraw_fev(:,:,jshock,:);
etaDraw_eps = etaDraw_eps(:,jshock,:);

if ~isempty(cumIR)
    
    % Compute cumulative impulse responses for relevant variables.
    etaDraw_irf(:,cumIR,:,:) = cumsum(etaDraw_irf(:,cumIR,:,:),1);

end

% Compute minimum and maximum impulse response over draws of Q.
rmin_irf = min(etaDraw_irf,[],4);
rmax_irf = max(etaDraw_irf,[],4);

rmin_fev = min(etaDraw_fev,[],4);
rmax_fev = max(etaDraw_fev,[],4);

rmin_eps = min(etaDraw_eps,[],3);
rmax_eps = max(etaDraw_eps,[],3);

end

