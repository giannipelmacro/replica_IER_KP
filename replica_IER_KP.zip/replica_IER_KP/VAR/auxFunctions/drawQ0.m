function Q0 = drawQ0(restr,phi,opt)
% Function draws Q KTilde times from the space of orthonormal matrices 
% satisfying the traditional and narrative restrictions. 
% Inputs:
% - restr: structure containing information about restrictions
% - phi: structure containing reduced-form VAR parameters
% - opt: structure containing model information and options

hdSignRestr = restr.hdSignRestr;
hdJointSignRestr = restr.hdJointSignRestr;
hlSignRestr = restr.hlSignRestr;
ratioSignRestr = restr.ratioSignRestr;
SS = restr.SS;
S = restr.S;
andOrMatrix = restr.andOrMatrix;
corrSignRestr  = restr.corrSignRestr;
fevdRestr      = restr.fevdRestr;
ExternalVar    = restr.ExternalVar;
Sigmatrinv = phi.Sigmatrinv;
vma = phi.vma;
U = Sigmatrinv*restr.U; % Multiply by Sigmatrinv to avoid doing this repeatedly
Sigmatrinvp = Sigmatrinv'; % Transpose to avoid doing this repeatedly

n = size(Sigmatrinv,1); % Number of variables in VAR
mHD = size(hdSignRestr,1); % No. of restrictions on historical decomp
mHDJ = size(hdJointSignRestr,1); % No. of restrictions on joint historical decomp
mHL = size(hlSignRestr,1); % No. of half life sign restrictions 
mR  = size(ratioSignRestr,1); % No. of ratio sign restrictions

%% Draw KTilde values of Q satisfying sign restrictions.

Q0 = zeros(n,n,opt.KTilde); % Storage

parfor kk = 1:opt.KTilde % Change from parfor to for if Parallel Computing Toolbox not installed

    flag = 0;

    while flag == 0

        % Draw Q from space of orthonormal matrices.
        z = randn(n);
        [Qtilde,~] = qr(z);
        
        % Normalise diagonal elements of A0 to be positive. Note that Matlab 
        % is implicitly expanding arrays to be compatible with elementwise 
        % array operations.
        Q = ((sign(diag(Sigmatrinvp*Qtilde))').*Qtilde)./vecnorm(Qtilde);

        % Check whether proposed draw satisfies shock-sign restrictions.
        %shockSignRestrSat = all(SS*Q(:) >= 0);
        shockSignRestrSat = all(andOrMatrix*(SS*Q(:) >= 0)>0);

        if shockSignRestrSat == 0  
            % If shock-sign restrictions not satisfied, return to 
            % beginning of loop.
            continue;          
        end

        % Check whether proposed draw satisfies traditional sign restrictions.
        signRestrSat = all(S*Q(:) >= 0);

        if signRestrSat == 0  
            % If sign restrictions not satisfied, return to beginning of loop.
            continue;          
        end
        
        % Check whether proposed draw satisfies restrictions on historical
        % decomposition.
        hdCheck = zeros(mHD,1); 

        % Pre-compute q_j*q_j' for j=1,...,n.
        QQ = pagemtimes(reshape(Q,[n,1,n]),reshape(Q,[1,n,n]));

        for ii = 1:mHD % For each restriction

            % Extract row of hdSignRestr corresponding to ith restriction.
            hdRestr = hdSignRestr(ii,:);

            % Compute contribution of each shock.
            HH = zeros(1,1,n);    

            for hh = 1:hdSignRestr(ii,4)+1 % Sum contribution over horizons

                HH = HH + pagemtimes(pagemtimes(vma(hdRestr(1),:,hh),QQ),...
                    U(:,hdRestr(3)+hh-1));

            end

            if hdRestr(5) == 1 && hdRestr(6) == 1

                % Type A - most important contributor
                hdCheck(ii) = abs(HH(hdRestr(2))) == max(abs(HH));

            elseif hdRestr(5) == 1 && hdRestr(6) == -1

                % Type A - least important contributor
                hdCheck(ii) = abs(HH(hdRestr(2))) == min(abs(HH));

            elseif hdRestr(5) == 2 && hdRestr(6) == 1

                % Type B - overwhelming contributor
                hdCheck(ii) = abs(HH(hdRestr(2))) - ...
                    sum(abs(HH((1:n) ~= hdRestr(2)))) >= 0;                

            elseif hdRestr(5) == 2 && hdRestr(6) == -1

                % Type B - negligible contributor
                hdCheck(ii) = abs(HH(hdRestr(2))) - ...
                    sum(abs(HH((1:n) ~= hdRestr(2)))) <= 0;

            end
            
            if hdCheck(ii) == 0              
                % If ith restriction on historical decomposition not 
                % satisfied, exit loop (saves computing contributions 
                % relating to subsequent restrictions).
                continue;             
            end

        end

        hdSignRestrSat = all(hdCheck);%all(( andOrMatrix*( (SS*Q(:) >= 0) & hdCheck ) > 0));
        
        
        % Check whether proposed draw satisfies joint restrictions on 
        % historical decomposition.
        hdJointCheck = zeros(mHDJ,1); 
    
        for ii = 1:mHDJ % For each restriction  
        
            % Pre-compute q_j*q_j' for j=1,...,n.
            QQ = pagemtimes(reshape(Q,[n,1,n]),reshape(Q,[1,n,n]));
    
            % Extract row of hdSignRestr corresponding to ith restriction.
            hdJointRestr = hdJointSignRestr(ii,:);
    
            % Compute contribution of each shock.
            HH = zeros(1,1,n);    
    
            for hh = 1:hdJointSignRestr(ii,4)+1 % Sum contribution over horizons
    
                HH = HH + pagemtimes(pagemtimes(vma(hdJointRestr(1),:,hh),QQ),...
                    U(:,hdJointRestr(3)+hh-1));
    
            end
    
            if hdJointRestr(5) == 1
    
                % Type B - overwhelming contributor
                hdJointCheck(ii) = (abs( sum(HH(1:hdJointRestr(2))) ) - ...
                    sum(abs(HH((hdJointRestr(2)+1):n))) >= 0);                
    
            elseif hdJointRestr(5) == -1
    
                % Type B - negligible contributor
                hdJointCheck(ii) = (abs( sum(HH(1:hdJointRestr(2))) ) - ...
                    sum(abs(HH((hdJointRestr(2)+1):n))) <= 0);
    
            end
            
            if hdJointCheck(ii) == 0              
                % If ith restriction on historical decomposition not 
                % satisfied, exit loop (saves computing contributions 
                % relating to subsequent restrictions).
                continue;
            end
    
        end
    
        hdJointSignRestrSat = all(hdJointCheck);%all( andOrMatrix*( (SS*Q(:) >= 0) & hdCheck ) > 0);
        

        % Check whether proposed draw satisfies restrictions on half lifes
        hlCheck = zeros(mHL,1); 
    
        for ii = 1:mHL % For each restriction  
    
            HL1 = get_halflife(vma,Q,hlSignRestr(ii,1),hlSignRestr(ii,2));
            HL2 = get_halflife(vma,Q,hlSignRestr(ii,3),hlSignRestr(ii,4));
    
            hlCheck(ii) = HL1>HL2;
    
            if hlCheck(ii) == 0              
                % If ith restriction on half lifes is not 
                % satisfied, exit loop (saves computing contributions 
                % relating to subsequent restrictions).
                continue;
            end
    
        end
    
        hlSignRestrSat = all(hlCheck);
    
        % Check whether proposed draw satisfies restrictions on ratios
        ratioCheck = zeros(mR,1); 
    
        for ii = 1:mR % For each restriction  
        
            IR1 = squeeze(vma(ratioSignRestr(ii,1),:,ratioSignRestr(ii,5)+1))*Q(:,ratioSignRestr(ii,2));
            IR2 = squeeze(vma(ratioSignRestr(ii,3),:,ratioSignRestr(ii,5)+1))*Q(:,ratioSignRestr(ii,4));
    
            ratioCheck(ii) = IR1>IR2;
    
            if ratioCheck(ii) == 0              
                % If ith restriction on half lifes is not 
                % satisfied, exit loop (saves computing contributions 
                % relating to subsequent restrictions).
                continue;
            end
    
        end
    
        ratioSignRestrSat = all(ratioCheck);
    
        % FEVD restrictions (custom made, no statements in beginning)
        if fevdRestr
            Bsquared         = (vma(:,:,1)*Q).^2;
            fevdCheck        = [Bsquared(1,1)>sum(Bsquared(1,3:end));...
                                Bsquared(2,2)>sum(Bsquared(2,3:end))];
            fevdSignRestrSat = all(fevdCheck);
        else
            fevdSignRestrSat = true;
        end

        % External variable restrictions
        if ~isempty(corrSignRestr)
            eps_tmp            = (Q'*phi.Sigmatrinv*restr.U)';
            ExtSignRestrSat    = all(corr(eps_tmp(:,corrSignRestr(:,1)),ExternalVar).*corrSignRestr(:,2)>0);
        else
            ExtSignRestrSat    = true;
        end

        % If restrictions satisfied, save value of Q and terminate 
        % while loop.
        flag = shockSignRestrSat*hdSignRestrSat*hdJointSignRestrSat*signRestrSat*hlSignRestrSat*ratioSignRestrSat*fevdSignRestrSat*ExtSignRestrSat;
        
        if flag == 1
            
            Q0(:,:,kk) = Q;
            
        end
        
    end
    
end

end