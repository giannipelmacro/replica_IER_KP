function [credlb,credub] = credibleRegion_eps(rmin,rmax,opt)
% Compute robustified credible region with credibility level alpha.
% Inputs:
% - rmin: posterior draws of lower bound
% - rmax: posterior draws of upper bound
% - opt: structure containing options

aalpha = opt.aalpha; % Credibility level
gridLength = opt.gridLength; % Number of point on discrete grid

[K,T,nj] = size(rmin);

% Storage.
credlb = zeros(T,nj);
credub = credlb;

%for ii = 1:ni % For each variable
    
    for jj = 1:nj % For each shock
    
        Cent = zeros(T,1);
        Rad = zeros(T,1);

        for tt = 1:T % For each time period

            % Construct discrete grid.
            r = linspace(min(rmin(:,tt,jj)),max(rmax(:,tt,jj)),...
                gridLength);
            gridr = kron(r,ones(K,1));

            % d(r,phi) = max{|r-l(phi)|,|r-u(phi)|}.
            d = max(abs(gridr-kron(rmin(:,tt,jj),ones(1,gridLength))),...
                abs(gridr-kron(rmax(:,tt,jj),ones(1,gridLength))));
            zhat = quantile(d,aalpha,1);
            [Rad(tt),ind] = min(zhat,[],2);
            Cent(tt) = gridr(1,ind);

        end

        % Approximate robustified credible region is an interval centered at 
        % Cent with radius Rad.
        credlb(:,jj) = Cent - Rad;
        credub(:,jj) = Cent + Rad;
    
    end

%end
    
end
