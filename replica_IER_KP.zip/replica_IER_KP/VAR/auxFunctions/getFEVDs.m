function FEVDp = getFEVDs(IRFy)
% GET FEVDs FOR LINEAR VAR SPECIFIED IN STATE-SPACE FORM:
%
%        Y_{t} = MY*X_{t}
%        X_{t} = MX*X_{t-1} + ME*E_{t}
%
% INPUT PARAMETERS
%  - IRFy:  the impulse response function
%
% Author: Mathias Krogh, June 2022

[nY,nE,hmax] = size(IRFy);
hmax         = hmax-1;

FEVDy        = nan(nY,nE,hmax+1);
FEVDp        = nan(nY,nE,hmax+1);

% get absolute contributions
theta_h      = IRFy(:,:,1);
FEVDy(:,:,1) = theta_h.^2;

for h = 1:hmax
theta_h        = IRFy(:,:,1+h);
FEVDy(:,:,1+h) = squeeze(FEVDy(:,:,h))+theta_h.^2;
end

% get relative contributions
for j = 1:nE
FEVDp(:,j,:) = squeeze(FEVDy(:,j,:))./squeeze(sum(FEVDy,2));
end

end

