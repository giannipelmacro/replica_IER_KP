% Author: Mathias Krogh (Based on Danilo Cascaldi-Garcia's codes)
% Date:   July 2023

function OptPhiPP = getPhiOptPP(XX,YY,Yraw,opt,covid_flag)

    if covid_flag==1 && opt.PriorType=="PP" && opt.PPphiOpt
        
        phi_temp = [0.001, 0.01, 0.025, 0.050, 0.075,...
                    0.10, 0.15, 0.20, 0.25, 0.30, 0.35,...
                    0.40,0.45, 0.50, 0.75, 1, 2, 5];       % Grid for phi
        
        PhiTest  = zeros(length(phi_temp),1);
    
        for jj=1:length(phi_temp)
            PhiTest(jj)=OptimalPhi(XX,YY,Yraw,opt.p,opt.const,opt.diff_or_lv,opt.lambda,opt.tau,opt.epsilon,phi_temp(jj),opt.covid_periods);
            fprintf('Density(%.3f) = %g\n',phi_temp(jj),PhiTest(jj));
        end

        [~, GridPosition] = max(PhiTest);
        phi_use = phi_temp(GridPosition);
        fprintf('Optimal phi for the model is %g.\n',phi_use);

        OptPhiPP = phi_use;
    
    else
    
        OptPhiPP = opt.PPphi;
    
    end

end




