function ind = datefind(Subset,Superset)

T   = length(Superset);
N   = length(Subset);

ind = nan(N,1);
num = 1:T;

for i = 1:N

    tmp        = num(Subset(i) == Superset);

    if not(isempty(tmp))
        ind(i) = tmp(1);
    end

end

if all(isnan(ind))
    
    ind = [];

end

end