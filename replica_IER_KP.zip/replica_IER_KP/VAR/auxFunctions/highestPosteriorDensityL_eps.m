function [hpdlb,hpdub] = highestPosteriorDensityL_eps(rPost,opt)
% Compute highest posterior density interval with credibility level alpha.
% Inputs:
% - rPost: posterior draws
% - opt: structure containing options

aalpha = opt.aalphaL; % Credibility level
gridLength = opt.gridLength; % Number of point on discrete grid

[K,T,nj] = size(rPost);

hpdlb = zeros(T,nj);
hpdub = hpdlb;

%for ii = 1:ni % For each variable

    for jj = 1:nj % For each shock
    
        % Storage matrices
        Cent = zeros(T,1);
        Rad = zeros(T,1);

        for tt = 1:T % For each horizon

            % Construct grid over which to search for bounds.
            r = linspace(min(rPost(:,tt,jj)),max(rPost(:,tt,jj)),...
                gridLength);
            gridr = kron(r,ones(K,1));

            % d(r,phi) = |r-r(phi)|
            d = abs(gridr-kron(rPost(:,tt,jj),ones(1,gridLength)));
            zhat = quantile(d,aalpha,1);
            [Rad(tt),ind] = min(zhat,[],2);
            Cent(tt) = gridr(1,ind);

        end

        % Approximate highest posterior density region is an interval centered 
        % at Cent with radius Rad.
        hpdlb(:,jj) = Cent - Rad;
        hpdub(:,jj) = Cent + Rad;
    
    end

%end
