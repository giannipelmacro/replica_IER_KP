function HD = GetHD(model,T0,H)

M     = model.nonEmptyDraw;
opt   = model.opt;
nExog = model.nExog;

XX    = model.XX;
YY    = model.YY;

n     = model.n;
m     = size(XX,2);
p     = opt.p;
opt.H = H;

HD    = nan(n,n+1,H,M);

for draw = 1:M


    % Get phi
    phi.Sigma      = model.Sigma(:,:,draw);
    phi.Sigmatr    = chol(phi.Sigma,'lower');
    phi.Sigmatrinv = phi.Sigmatr\eye(n);
    phi.B          = model.B(:,draw);
    phi.Q          = model.Qsave(:,:,draw);
    
    % vector moving average representation
    vma            = genVMA(phi,opt,nExog);

    % Structural shocks
    U = phi.Sigmatrinv*(YY - XX*reshape(phi.B,m,n))';

    % Get companion form (including the constant)
    phi.B_mat = reshape(phi.B,size(phi.B,1)/n,n); % Reshape coefficients into matrix
    phi.const = phi.B_mat(end-nExog+1:end,:)';
    phi.B_mat = phi.B_mat(1:end-nExog,:)'; % Drop coefficients on exogenous variables

    c_c = [phi.const;zeros(n*(p-1),1)];
    B_c = zeros(n*p);
    B_c(1:n,:) = phi.B_mat;   
    B_c(n+1:end,1:end-n) = eye(n*p-n);

    % Historical decomposition
    QQ = pagemtimes(reshape(phi.Q,[n,1,n]),reshape(phi.Q,[1,n,n]));

    for Hor = 1:H+1

        HH = zeros(1,n,n);    
        DC = XX(T0,1:end-nExog)';

        for hh = 1:Hor % Sum contribution over horizons
    
            % cumulative contributions of each shock
            for ii = 1:n
                HH(1,ii,:) = HH(1,ii,:) + pagemtimes(pagemtimes(vma(ii,:,Hor+1-hh),QQ),...
                             U(:,T0+hh-1));
    
            end
            
            % contributions of the deterministic component
            DC                 = c_c+B_c*DC;
    
        end

        HD(:,1:n,Hor,draw)  = squeeze(HH);
        HD(:,n+1,Hor,draw)  = DC(1:n);

    end
    
end


end