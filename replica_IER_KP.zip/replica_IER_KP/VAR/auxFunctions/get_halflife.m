% Written by Mathias Krogh, June 2023

function HL = get_halflife(vma,Q,i,j)
% Computes the half life of impulse response of variable i to shock j:
%
% vma: Impulse responses / vector moving average representation of the
%      orthogonal reduced form (No. of responses x No. of shocks x H+1)
% Q:   Candidate draw for the Q matrix
% i:   Response variable of interest
% j:   Structural shock of interest

IR  = squeeze(vma(i,:,:))'*Q(:,j); % response of variable i to shock j

HL  = find( sign(IR(1))*(IR-IR(1)/2) < 0, 1, 'first');

if isempty(HL)
    HL = Inf;
end

end