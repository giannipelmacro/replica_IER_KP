MATLAB/DYNARE codes for "Real Activity and Uncertainty Shocks: The Long and
the Short of It" by Mathias Krogh and Giovanni Pellegrino, International
Economic Review, forthcoming.

The folders <VIXdata>, <VAR>, <LP> and <DSGE> contain the codes for the four
steps of the analysis, in this order: (1) construction of the VIX term
structure, (2) the SVAR and its identification of short- and long-term
uncertainty shocks, (3) Local Projections using the SVAR shocks as
instruments, and (4) the DSGE model, whose theoretical IRFs are compared
against the empirical LP IRFs from step (3).

--------------------------------------------------------------------------
<VIXdata>: construction of the VIX term structure (Section 3, Appendix A)
--------------------------------------------------------------------------
Please check out and run RUN_ME_Fig1.m, RUN_ME_Fig2_FigA2.m, RUN_ME_Fig3.m
and RUN_ME_FigA1.m to replicate Figures 1, 2, 3, A.1 and A.2.

These four scripts load the already-constructed VIX series (VIX_data.mat,
data_monthlyVIX.mat, VIXdata_monthly.xlsx). The scripts that build these
series from raw option data, get_dailyVIX_ToShare_v2.m and (then)
get_monthlyVIX_ToShare_v2.m, require proprietary OptionMetrics/WRDS option
data that we cannot share; see VIXdata/_Read-me.docx for
instructions on how to obtain them.

--------------------------------------------------------------------------
<VAR>: SVAR analysis (Section 4, Appendices C-E)
--------------------------------------------------------------------------
Please check out and run RUN_ME_Fig4_Fig5_Fig6_FigA5.m to replicate the
baseline SVAR results (Figures 4, 5, 6 and A.5). This script first estimates the
baseline model (BASELINE_nonrobust/sendfile.m) and then plots the figures. 
The data series used are in the folder VAR/_raw data (check out getdata.m).

The <Checks Appendix> folder contains the robustness checks reported in
Appendix E. Each variant lives in its own subfolder (e.g. minnesota_nonrobust,
dec2022_nonrobust, JLNfin_nonrobust, 1996_nonrobust, ...) with its own
sendfile.m; run _RUN_ME_estimations.m once to estimate all variants (slow),
then the following scripts to plot the figures: RUN_ME_FigA4_histograms.m (A.4),
RUN_ME_FigA7_Kilian.m (A.7), RUN_ME_FigA6_FigA8_GKR.m (A.6 and A.8, run once
with use_narratives=true and once with use_narratives=false),
RUN_ME_FigA9_Covid.m (A.9), RUN_ME_FigA10_1996.m (A.10), RUN_ME_FigA11_IPgr.m (A.11),
RUN_ME_FigA12_JLNfin.m (A.12), RUN_ME_FigA13_JLNmacro.m (A.13).

The <Cholesky Appendix> folder allows the replication of Figure A.3; 
run RUN_ME_FigA3_Cholesky.m.

The estimated baseline shocks are the starting point for the LP step below;
LP/raw data/Shocks_quarterly_transf.m saves the monthly shock series in
LP/raw data/Shocks_monthly.xls and its quarterly-sum aggregation in
LP/raw data/Shocks_quarterlySum.xlsx.

--------------------------------------------------------------------------
<LP>: Local Projections (Section 4.2, Appendix F)
--------------------------------------------------------------------------
Please check out and run RUN_ME_Fig7_FigA14.m to replicate Figures 7 and A.14: run
it once with select_IV=1 (short-term shock) and once with select_IV=2
(long-term shock), without clearing figures in between, as instructed at
the top of the script. This requires the MATLAB Econometrics Toolbox (used
for Newey-West/HAC standard errors). The data series used are in LP/raw data
(check out BasuBundick_dataset_transf.m). The script saves results_LP_ST.mat
and results_LP_LT.mat, a copy of which is used in DSGE/Extra_Appendix/Compare2DSGE.

--------------------------------------------------------------------------
<DSGE>: theoretical model (Section 5, Appendices G-H)
--------------------------------------------------------------------------
Computations use Dynare. Each RUN_ME script expects Dynare installed at
C:\dynare\4.4.3\matlab; if yours is installed elsewhere, edit the addpath
line at the top of the script.

Please check out and run:
- Baseline/RUN_ME_Fig8_FigA18.m for Figures 8 (baseline model IRFs) and A18.
- Counterfactuals/RUN_ME_Fig9.m for Figure 9.
- Extra_Appendix/PDA/RUN_ME_FigA15.m and RUN_ME_FigA16.m for Figures A.15
  and A.16 (robustness to the calibration of the uncertainty processes).
- Extra_Appendix/Compare2DSGE/RUN_ME_FigA17.m for Figure A.17, which compares
  the DSGE model's theoretical VIX IRFs against the empirical VAR IRFs from
  VAR/Checks Appendix/VIX3M_nonrobust (run its sendfile.m first).
- Extra_Appendix/Compare2DSGE/RUN_ME_FigA20.m for Figure A.20, which compares
  the DSGE model's theoretical IRFs against the empirical LP IRFs from the
  <LP> folder above (results_LP_ST.mat, results_LP_LT.mat).
- Extra_Appendix/Compare2DSGE/RUN_ME_InvestmentRatios.m (run after
  Counterfactuals/RUN_ME_Fig9.m) for the peak investment responses and the
  long-/short-term ratios quoted in Section 5.
- Extra_Appendix/TTBhorizon/RUN_ME_FigA19.m for Figure A.19, which compares
  the DSGE model's theoretical IRFs for a gestation of 4, 6 (baseline), or 8
  quarters.


All computations were based on Dynare 4.4.3 and MATLAB R2021b.

Mathias Krogh (mkrogh.research@gmail.com) and Giovanni Pellegrino (giovanni.pellegrino@unipd.it)

October 2026
