function [Beta,Sigma,Sxx,Res,Betaint] = LS(Y,X)

warning('off','MATLAB:nearlySingularMatrix');
warning('off','MATLAB:rankDeficientMatrix');

if size(Y,1)~=size(X,1)
    error("Number of obs in Y and X do not match!")
end
if size(X,1)<size(X,2)
    error("Too few obs in regression!")
end

%X(:,3)=[]; %no lag shock if 1 lag. Lorenzo
Beta = X \ Y;
 
global alpha HACse
[b,Betaint] = regress(Y,X,alpha);

% NEED HAC std error. GP
if HACse==1 %GP
    value=norminv(1-alpha/2, 0, 1); % GP

    T = size(Y,1);
    maxLag = floor(4*(T/100)^(2/9));%original Newey-West (1987) proposal (see help hac.m)
    [EstCoeffCov,se,coeff] = hac(X(:,2:end),Y, 'bandwidth',maxLag+1,  Display="off") ;

    %Betaint(:,1)=b-1.28.*se; %1.96= 95% (GP:  norminv(1-alpha/2, 0, 1) if alpha=0.05 ),1.645 =10%, 1.28=20%
    %Betaint(:,2)=b+1.28.*se;

    Betaint(:,1)=b-value.*se;%GP
    Betaint(:,2)=b+value.*se;%GP

    %Betaint
    %Betaint1
end

Res = Y - X * Beta;
Sigma = Res' * Res / size(Y,1);
Sxx = X' * X / size(Y,1);

end

