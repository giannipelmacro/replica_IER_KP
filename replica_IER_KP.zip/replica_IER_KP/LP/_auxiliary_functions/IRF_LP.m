function [irf irf_l irf_p] = IRF_LP(Y,dimR,respV,nlags,nhorizons)

nv = size(Y,2);
nT = size(Y,1);
if (nhorizons + nlags) >= nT
    error("Number of horizons too large! No obs in sample!")
end
irf = zeros(1,nhorizons + 1);

for h = 0:nhorizons
    [Bc,Br,Bx,By,Sigma,Sxx,BetaInt] = LP(Y,dimR,respV,nlags,h,nhorizons);
    irf(1,h + 1) = Bx;
    irf_l(1,h + 1) = BetaInt(1);%Lorenzo
    irf_p(1,h + 1) = BetaInt(2);%Lorenzo

end

end