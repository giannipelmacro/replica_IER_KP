% TO OBTAIN THE FIGURE IN THE PAPER
% - run as it is with "select_IV=1;"
% - re-run with "select_IV=2;" (without closing the figures obtained earlier)

% NOTE: these codes are an adaptation of the codes in Plagborg-Moller and
% Wolf (2020, Econometrica) LOCAL PROJECTIONS AND VARS ESTIMATE THE SAME IMPULSE
% RESPONSES. We thank Lorenzo Mori for providing an initial version of these codes. Any error is
% ours.

% NOTE:  we use Basu and Bundick (2017) updated data

%% HOUSEKEEPING

%%%%%%%%% input %%%%%%%%%%%
select_IV=1; % 1 for ST shock, 2 for LT shock
%%%%%%%%%%%%%%%%%%%%%%%%%%%


if select_IV==1
    close all
end

clc
clearvars -except select_IV
addpath('_auxiliary_functions')

global alpha HACse % used only in the function LS.m (inside LP.m , which is inside IRF_LP.m)

%% SETTINGS

maxhorz = 15; % Horizons to plot (it is added +1 in the codes below, so 15 means 16 quarters).  Horizontal axis starts from 1
nlags = [4]; % List of all lag lengths to consider
alpha = 0.10; % confidence level: if 0.10 (90% conf bands), if 0.32 (68% conf bands)
HACse = 1; %GP: 0 for standard standard errors, 1 for HAC s.e. (which may be fine tuned if needed, see "help hac". We use standard Newey-West s.e.)

normalizeShocks=1  ; %to demean and unit std

% ALTERNATIVE ORDER IN PLOTS FOR THE PAPER FIGURE: GDP, C, INV
idx=[1 2 4 5 3]; 


%% LOAD DATA 

    % Load data.Baseline sample (less 1 year of lags): 2001q1 - 2019q4
     [Y,tempText]=xlsread('BB_Data_quarterly.xlsx','Sheet1'); % only fixed investment, investment excluding durable consumption and inventories.

names = tempText(1,2:end);

% transform variables (already in logs)
Y= Y(:,2:4).*100;


[VIXs,tempText]=xlsread('VIXs_quarterly_2001-2019.xlsx');

VIXs=VIXs(:,[3 4]);%VIX-1Q and VIX-2Y

names=[tempText(1,[3 4]),names]
Y=[log(VIXs(:,1)).*100 , log(VIXs(:,2)).*100 , Y];




%%%%%%%%%%%%%%%%%% 
% IV
[IV,tempTextIV]=xlsread('Shocks_quarterlySum.xlsx','IV');%quarterly sum of monthly shocks in stdev units
IV=IV(:,[2 3]);


     if normalizeShocks==0
         Z=IV(:,select_IV);
     elseif normalizeShocks==1
         Z=normalize(IV(:,select_IV));
     end

%%%%%%%%%%%%%%%

[T,ny] = size(Y);

% --------
Y=Y(:,1:end);
names=names(:,1:end);

names_paper={'VIX-1Q','VIX-2Y','Investment','GDP','Consumption'};


%% ESTIMATION: LP

np = length(nlags);

irfs_lpiv = zeros(size(Y,2),maxhorz+1);


irfs_lp = zeros(size(Y,2),maxhorz+1);

for iy=1:size(Y,2) % one regression for each variable in Y
     
    % LP
   [irfs_lpiv(iy,:), irf_l(iy,:), irf_p(iy,:)] = IRF_LP([Z  Y],0,1+iy,nlags,maxhorz); % % [Z  Y] shock and controls to consider 
 
end
 

%% figures setting

settings.colors.black  = [0 0 0];
settings.colors.grey   = [205/255 205/255 205/255];
settings.colors.orange = [204/255 102/255 0/255];
settings.colors.green  = [37/255 152/255 14/255];
settings.colors.blue   = [51/255 51/255 255/255];
settings.colors.red    = [255/255 0/255 0/255];

settings.colors.list = [settings.colors.black;settings.colors.grey;settings.colors.orange];


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
norm=1;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%% FIGURE 1st: Plot IRFs with (1-alpha)% bands 

if select_IV==1

    figure(1)
    for i = 1:size(Y,2)
        subplot(2,3,i)

        x = 1:1:maxhorz+1;  % Define the x-axis values
        y1 = irf_l(i,1:maxhorz+1) * norm;  % First curve
        y2 = irf_p(i,1:maxhorz+1) * norm;  % Second curve

        plot(1:1:maxhorz+1,irfs_lpiv(i,1:maxhorz+1)*norm,'Color',settings.colors.green,'LineWidth',3)

        hold on
        % Fill the area between the curves
        fill([x fliplr(x)], [y1 fliplr(y2)], 'g', 'FaceAlpha', 0.4, 'EdgeColor', 'none');

        % Add zero line
        plot(0:size(irfs_lpiv,2), zeros(size(irfs_lpiv,2)+1,1), '--', 'Color', 'k', 'LineWidth', 3, 'HandleVisibility', 'off');

        % Add labels and titles
        title(names(i), 'interpreter', 'latex', 'fontsize', 18);

        xlim([1 maxhorz+1]);
        grid on
         hold on 
    end

elseif select_IV==2
 
       figure(1)
    for i = 1:size(Y,2)
        subplot(2,3,i)

        x = 1:1:maxhorz+1;  % Define the x-axis values
        y1 = irf_l(i,1:maxhorz+1) * norm;  % First curve
        y2 = irf_p(i,1:maxhorz+1) * norm;  % Second curve

        plot(1:1:maxhorz+1,irfs_lpiv(i,1:maxhorz+1)*norm,'Color',settings.colors.red,'LineWidth',3)

        hold on
        % Fill the area between the curves
        fill([x fliplr(x)], [y1 fliplr(y2)], 'r', 'FaceAlpha', 0.4, 'EdgeColor', 'none');

        % Add zero line
        plot(0:size(irfs_lpiv,2), zeros(size(irfs_lpiv,2)+1,1), '--', 'Color', 'k', 'LineWidth', 3, 'HandleVisibility', 'off');

        % Add labels and titles
        title(names(i), 'interpreter', 'latex', 'fontsize', 18);
        xlim([1 maxhorz+1]);
        grid on
        hold off
    end
end


%% FIGURE 2nd: Plot IRFs with (1-alpha)% bands 

if select_IV==1

    figure(WindowState="maximized")
    for i = 1:size(Y,2)
        subplot(5,2,2*i-1)

        x = 1:1:maxhorz+1;  % Define the x-axis values
        y1 = irf_l(i,1:maxhorz+1) * norm;  % First curve
        y2 = irf_p(i,1:maxhorz+1) * norm;  % Second curve

        plot(1:1:maxhorz+1,irfs_lpiv(i,1:maxhorz+1)*norm,'Color',settings.colors.green,'LineWidth',3)

        hold on
        % Fill the area between the curves
        fill([x fliplr(x)], [y1 fliplr(y2)], 'g', 'FaceAlpha', 0.4, 'EdgeColor', 'none');

        % Add zero line
        plot(0:size(irfs_lpiv,2), zeros(size(irfs_lpiv,2)+1,1), '--', 'Color', 'k', 'LineWidth', 3, 'HandleVisibility', 'off');

        ylabel(names_paper(i), 'interpreter', 'latex', 'fontsize', 13);
        xlim([1 maxhorz+1]);
        grid on
         hold on 
       if i==1
           ylim([-15 15])
           title('Short-term Shock','interpreter', 'latex','FontSize', 18)
       elseif i==2
           ylim([-10 10])    
       elseif i==3
           ylim([-3.2 3])
       elseif i==4
           ylim([-1 1])    
       elseif i==5
           ylim([-1 0.7])
       elseif i==6
           ylim([-5 5])
       end
       grid on
    end

elseif select_IV==2
 
       figure(2)
    for i = 1:size(Y,2)
        subplot(5,2,2*i)

        x = 1:1:maxhorz+1;  % Define the x-axis values
        y1 = irf_l(i,1:maxhorz+1) * norm;  % First curve
        y2 = irf_p(i,1:maxhorz+1) * norm;  % Second curve

        plot(1:1:maxhorz+1,irfs_lpiv(i,1:maxhorz+1)*norm,'Color',settings.colors.red,'LineWidth',3)

        hold on
        % Fill the area between the curves
        fill([x fliplr(x)], [y1 fliplr(y2)], 'r', 'FaceAlpha', 0.4, 'EdgeColor', 'none');

        % Add zero line
        plot(0:size(irfs_lpiv,2), zeros(size(irfs_lpiv,2)+1,1), '--', 'Color', 'k', 'LineWidth', 3, 'HandleVisibility', 'off');

        xlim([1 maxhorz+1]);
        grid on
        hold off
       if i==1
           ylim([-15 15])
           title('Long-term Shock','interpreter', 'latex','FontSize', 18)
       elseif i==2
           ylim([-10 10])    
       elseif i==3
           ylim([-3.2 3])
       elseif i==4
           ylim([-1 1])    
       elseif i==5
           ylim([-1 0.7])
       elseif i==6
           ylim([-5 5])
       end
    end
    grid on
end

orient tall
print('-depsc','FigA14');
print('-dpdf','FigA14','-fillpage');

%% FIGURE 3rd: Plot IRFs with (1-alpha)% bands 


if select_IV==1

    figure(WindowState="maximized")
    for i = 3:size(Y,2)
        subplot(3,2,2*i-1-4)

        x = 1:1:maxhorz+1;  % Define the x-axis values
        y1 = irf_l(idx(i),1:maxhorz+1) * norm;  % First curve
        y2 = irf_p(idx(i),1:maxhorz+1) * norm;  % Second curve

        plot(1:1:maxhorz+1,irfs_lpiv(idx(i),1:maxhorz+1)*norm,'Color',settings.colors.green,'LineWidth',3,'LineStyle','--')

        hold on
        % Fill the area between the curves
        fill([x fliplr(x)], [y1 fliplr(y2)], 'g', 'FaceAlpha', 0.4, 'EdgeColor', 'none');

        % Add zero line
        plot(0:size(irfs_lpiv,2), zeros(size(irfs_lpiv,2)+1,1), '-', 'Color', 'k', 'LineWidth', 2, 'HandleVisibility', 'off');

        % Add labels and titles
        ylabel(names_paper(idx(i)), 'interpreter', 'latex', 'fontsize', 13+2+1);
       xlim([1 maxhorz+1]);
         grid on
         hold on 
       if idx(i)==1
           ylim([-15 20])
       elseif idx(i)==2
           ylim([-10 10])    
       elseif idx(i)==3
           ylim([-3.2 3])
       elseif idx(i)==4
           ylim([-1 1])    
           title('Short-term Shock','interpreter', 'latex','FontSize', 18+1) 
       elseif idx(i)==5
           ylim([-1 0.65])
       elseif idx(i)==6
           ylim([-5 5])
       end
       xticks(4:4:maxhorz+1)
       grid on
    end

elseif select_IV==2
 
       figure(3)
    for i = 3:size(Y,2)
        subplot(3,2,2*i-4)

        x = 1:1:maxhorz+1;  % Define the x-axis values
        y1 = irf_l(idx(i),1:maxhorz+1) * norm;  % First curve
        y2 = irf_p(idx(i),1:maxhorz+1) * norm;  % Second curve

        plot(1:1:maxhorz+1,irfs_lpiv(idx(i),1:maxhorz+1)*norm,'Color',settings.colors.red,'LineWidth',3,'LineStyle','--')

        hold on
        % Fill the area between the curves
        fill([x fliplr(x)], [y1 fliplr(y2)], 'r', 'FaceAlpha', 0.4, 'EdgeColor', 'none');

        % Add zero line
        plot(0:size(irfs_lpiv,2), zeros(size(irfs_lpiv,2)+1,1), '-', 'Color', 'k', 'LineWidth', 2, 'HandleVisibility', 'off');

        xlim([1 maxhorz+1]);
         grid on
        hold off
       if idx(i)==1
           ylim([-15 20])
       elseif idx(i)==2
           ylim([-10 10])    
       elseif idx(i)==3
           ylim([-3.2 3])
       elseif idx(i)==4
           ylim([-1 1])    
           title('Long-term Shock','interpreter', 'latex','FontSize', 18+1)  
       elseif idx(i)==5
           ylim([-1 0.65])
       elseif idx(i)==6
           ylim([-5 5])
       end
    xticks(4:4:maxhorz+1)
    grid on
    end
end

orient tall
print('-depsc','Fig7');
print('-dpdf','Fig7','-fillpage');

%% save (to use for assessing the fit of the DSGE model)
if select_IV==1
    save results_LP_ST.mat
elseif select_IV==2
    save results_LP_LT.mat
end
