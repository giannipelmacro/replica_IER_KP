
% We update a part of the BB dataset and use transformations similar to them to get
% the quarterly GDP, Cons and Inv we use for the LP estimation
% --> gives BB_Data_quarterly.xlsx

clear 
close all

%% FIRST LOAD THE DATA that update Basu and Bundick (2016, Ekta)

data = xlsread('fredgraph_BasuBundickUpdatedData.xlsx','Quarterly');
% ---- Variables in the file: ---- 
% 1 Real personal consumption expenditures: Nondurable goods (chain-type quantity index), Index 2017=100, Quarterly, Seasonally Adjusted
% 2 Real personal consumption expenditures: Services (chain-type quantity index), Index 2017=100, Quarterly, Seasonally Adjusted
% 3 Population Level, Thousands of Persons, Quarterly, Not Seasonally Adjusted
% 4 Real gross private domestic investment: Fixed investment (chain-type quantity index), Index 2017=100, Quarterly, Seasonally Adjusted
% 5 Real Gross Domestic Product, Billions of Chained 2017 Dollars, Quarterly, Seasonally Adjusted Annual Rate
% ---------------

% Convert to per-capita and take logs (as in Basu and Bundick codes)

population = data(:,3)/1000000;
logoutput = log(data(:,5)./population);
logconsumption = log((data(:,1)+data(:,2))./population); % Consumption = Nondurables & Services 
loginvestment = log((data(:,4))./population); % Investment = fixed investment  (no durable consumption!)


date=1947:0.25:2025.25; %  1947q1 - 2025q2

startdate = find(date == 2001-1/4);% 1/4 does not count: just helps to generate xls file later (it ends one quarter early on purpose; the extra row is dropped below when the header overwrites row 1)
enddate = find(date ==2019+3/4);

%%% DEFINE VARIABLES
vardata = [loginvestment logoutput logconsumption];
vardata = vardata(startdate:enddate,:);

labels={'loginvestment','logoutput', 'logconsumption'};



%%%%%%%%%%%%%%%%%%

 % create .xls to use in main estimation file:
  xlswrite('BB_Data_quarterly.xlsx',[date(startdate:enddate)',vardata])
  xlswrite('BB_Data_quarterly.xlsx',['date',labels]) %overwrite row 1 with labels


