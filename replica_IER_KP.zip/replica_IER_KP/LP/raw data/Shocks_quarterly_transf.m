
% We take the monthly ST and LT uncertainty shocks (posterior means,
% rSinglePriorMean_EPS) estimated in the baseline VAR and sum them to
% quarterly frequency, over the LP estimation sample 2001q1-2019q4
% --> gives Shocks_monthly.xls and Shocks_quarterlySum.xlsx

clear
close all

%% LOAD THE MONTHLY SHOCKS

s   = load(fullfile('..','..','VAR','BASELINE_nonrobust','results baseline_nonrobust.mat'),'rSinglePriorMean_EPS','dt','opt');
EPS = s.rSinglePriorMean_EPS;  % [ST LT]
dt  = s.dt(s.opt.p+1:end);     % shocks start after the first p lags, i.e. in 2001:01
assert(numel(dt)==size(EPS,1))

writetable(table(dt,EPS(:,1),EPS(:,2),'VariableNames',{'Date','ST','LT'}),'Shocks_monthly.xls')

%% SUM TO QUARTERLY FREQUENCY

yq = year(dt) + floor((month(dt)-1)/3)/4; % e.g. 2001.00, 2001.25, 2001.50, 2001.75, ...
uq = unique(yq);
uq = uq(uq >= 2001 & uq <= 2019+3/4); % restrict to the LP sample, 2001q1-2019q4

ST = zeros(numel(uq),1);
LT = zeros(numel(uq),1);
for i = 1:numel(uq)
    idx = (yq == uq(i));
    assert(sum(idx)==3)
    ST(i) = sum(EPS(idx,1));
    LT(i) = sum(EPS(idx,2));
end

%% CREATE .xlsx TO USE IN THE LP ESTIMATION FILE

writetable(table(uq,ST,LT,'VariableNames',{'obs','ST','LT'}),'Shocks_quarterlySum.xlsx','Sheet','IV')
