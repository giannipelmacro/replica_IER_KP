
% We take the monthly VIX-1M, VIX-1Q (3-month) and VIX-2Y series already
% constructed in the VIXdata folder and average them to quarterly
% frequency, over the LP estimation sample 2001q1-2019q4
% --> gives VIXs_quarterly_2001-2019.xlsx

clear
close all

%% LOAD THE MONTHLY VIX SERIES

s = load(fullfile('..','..','VIXdata','data_monthlyVIX.mat')); % has dt, VIX1, VIX3, VIX24 (among others)

%% AVERAGE TO QUARTERLY FREQUENCY

yq = year(s.dt) + floor((month(s.dt)-1)/3)/4; % e.g. 2001.00, 2001.25, 2001.50, 2001.75, ...
uq = unique(yq);
uq = uq(uq >= 2001 & uq <= 2019+3/4); % restrict to the LP sample, 2001q1-2019q4

VIX1M = zeros(numel(uq),1);
VIX1Q = zeros(numel(uq),1);
VIX2Y = zeros(numel(uq),1);
for i = 1:numel(uq)
    idx = (yq == uq(i));
    VIX1M(i) = mean(s.VIX1(idx));  % 1-month VIX
    VIX1Q(i) = mean(s.VIX3(idx));  % 3-month VIX, i.e. "VIX-1Q"
    VIX2Y(i) = mean(s.VIX24(idx)); % 2-year VIX
end

%% CREATE .xls TO USE IN THE LP ESTIMATION FILE

labels = {'obs','VIX-1M','VIX-1Q','VIX-2Y'};
xlswrite('VIXs_quarterly_2001-2019.xlsx',labels,'Sheet1','A1')
xlswrite('VIXs_quarterly_2001-2019.xlsx',[uq,VIX1M,VIX1Q,VIX2Y],'Sheet1','A2')
