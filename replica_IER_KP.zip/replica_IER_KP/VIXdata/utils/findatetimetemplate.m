function [template,flag,varargout] = findatetimetemplate(varargin)
%DATETIMETEMPLATE Determine datetime template to use for property
%preservation
%   DATETIMETEMPLATE takes an arbitrary number of inputs and determines
%   which one should be used as the template for the output datetime in the
%   calling function. The template datetime is used to determine both the
%   format and TimeZone of the new datetime output. The template will be
%   the first datetime object in the input arguments.
%
%   [Template,Flag] = findatetimetemplate(D1,D2,... DM)
%
%   Inputs:
%       D1, D2, ... DM - One or more MATLAB variables. Ideally the 
%       variables should be the same date inputs provided to the calling
%        function, in the same order.
%
%   Outputs:
%       Template - Datetime object representing the template to be used to
%       create the calling function's output datetime. This will be empty
%       if the inputs did not contain any datetime objects.
%
%       Flag - A boolean indicating if a template datetime object was found
%
%   See Also DATEN2DATET

%   Copyright 2017-2022 The MathWorks, Inc.

% Set flag is any datetime's in inputs
datetimeCheck = cellfun(@isdatetime,varargin);
flag = any(datetimeCheck);

% Do not convert date inputs to datetime if no return dates are requested
if nargout < 3
  if flag
    datetimeIdx = find(datetimeCheck);
    template = varargin{datetimeIdx(1)};
  else
    template = [];
  end

else

  % Convert all dates to datetime and save datetime properties of first
  % datetime found in inputs
  numDateInputs = length(varargin);
  varargout = cell(numDateInputs,1);
  template = [];
  for i = 1:numDateInputs
    if datetimeCheck(i) && isempty(template)
      template = varargin{i};
    end
    cellFlag = iscell(varargin{i});
    if cellFlag
      dims = size(varargin{i});
      varargin{i} = varargin{i}(:);
    end
    varargout{i} = convertDatenum(varargin{i}) ; %matlab.datetime.compatibility.convertDatenum(varargin{i});

    if cellFlag
      varargout{i} = reshape(varargout{i},dims);
    end
  end

  % Create datetime template to be used for all dates if no datetime in
  % inputs
  if isempty(template)
    template = varargout{1};
  end

end
