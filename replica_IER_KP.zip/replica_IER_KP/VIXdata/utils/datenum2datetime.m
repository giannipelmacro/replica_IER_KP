function dt = datenum2datetime(dn)

Y  = floor(dn/10000);
M  = floor((dn-Y*10000)/100);
D  = dn-(Y*10000+M*100);

dt = datetime(Y,M,D);

end