function d = days365(d1,d2) 
%DAYS365 Days between dates based on 365 day year. 
%   D = DAYS365(D1,D2) returns the number of days between D1 and D2 based 
%   on a 365 day year. .  Enter dates as serial date numbers date strings
%   or datetime arrays.  If D2 is less than D1, the value returned will be 
%   negative.  
% 
%   For example, d = days365('1-Dec-1993', '12-Jan-1994') 
%   or d = days365(728264,728306) returns d = 42. 
% 
%   See also DAYS360, DAYSACT, DAYSDIF, DATENUM.

%       Copyright 1995-2021 The MathWorks, Inc.
 
if nargin > 0
    d1 = convertStringsToChars(d1);
end

if nargin > 1
    d2 = convertStringsToChars(d2);
end

if nargin < 2 
  error(message('finance:days365:missingInputs')) 
end

% Convert date inputs to datetime
[~,~,d1,d2] = findatetimetemplate(d1,d2);

sz = [size(d1);size(d2)]; 
if length(d1) == 1 
  d1 = d1(ones(max(sz(:,1)),max(sz(:,2)))); 
end 
if length(d2) == 1 
  d2 = d2(ones(max(sz(:,1)),max(sz(:,2)))); 
end 
sizes = [size(d1);size(d2)];
if any(sizes(:,1)~=sizes(1,1)) || any(sizes(:,2)~=sizes(2,2))
  error(message('finance:days365:invalidInputDims'))
end
 
% Need cumulative sum of days at beginning of each month 
% to convert months into days. 
daytotal = [0;31;59;90;120;151;181;212;243;273;304;334]; 
 
yr1 = year(d1);
mt1 = month(d1);
dy1 = day(d1);
yr2 = year(d2);
mt2 = month(d2);
dy2 = day(d2);
c1 = [yr1(:) mt1(:) dy1(:)];
c2 = [yr2(:) mt2(:) dy2(:)];

tempd = 365 * (c2(:, 1) - c1(:, 1)) + daytotal(c2(:, 2)) -... 
            daytotal(c1(:, 2)) + c2(:, 3) - c1(:, 3); 
d = reshape(tempd,size(d1));
