function [dt, waslegacy] = convertDatenum(dt)
%convertDatenum Convert date input to datetime.
%   [DT, WASLEGACY] = convertDatetime(D) converts the date input, D, to datetime
%   DT.  D can be a serial date number, text timestamp that is parsed by
%   datenum, or datetime.  WASLEGACY is a logical scalar indicating if the input
%   was a datenum or datestr (true) or datetime (false).  Because convertDatenum
%   calls datenum to interpret text timestamps, some timestamps are not
%   interpreted the way that the datetime function interprets them.
%
%   See also DATENUM, DATESTR, DATETIME

%   Copyright 2021 The MathWorks, Inc.

if isa(dt,'datetime')
    waslegacy = false;
elseif isnumeric(dt) 
    waslegacy = true;
    dt = datetime(dt,"ConvertFrom","datenum");
elseif iscellstr(dt) || (isstring(dt) && ~isscalar(dt))
    waslegacy = true;
    % Convert to vector for consistent datenum behavior, then preserve the
    % original shape.
    dims = size(dt);
    dt = datetime(datenum(dt(:)),"ConvertFrom","datenum");
    dt = reshape(dt,dims);
elseif ischar(dt) || isstring(dt)
    waslegacy = true;
    dt = datetime(datenum(dt),"ConvertFrom","datenum");
else
    error(message("MATLAB:datetime:convertDatenum:InvalidDate"));
end