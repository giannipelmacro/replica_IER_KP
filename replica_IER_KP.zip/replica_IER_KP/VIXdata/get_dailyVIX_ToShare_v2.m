% Code by Mathias Krogh 
% 
% Prepared for the paper
% “Real Activity and Uncertainty Shocks: The Long and the Short of It,” 
% Mathias Krogh and Giovanni Pellegrino, International Economic Review, forthcoming

%% Get optionmetrics data.
% from get_VIX.m

clear all
close all
clc

spxopt= readtable('OptionMetrics/spx_opt.csv');
spxprice= readtable('OptionMetrics/spx_price.csv');
zerocoupondata = readtable('OptionMetrics/zero_coupon_data.csv');


addpath('utils')

%% Assumptions
% 1: Forward index is estimated using the S&P500 price as in Dew-Becker's
% codes, i.e. not using the method in the CBOE VIX white paper.

% 2: All data is from optionmetrics, including the zero coupon curve and
% the S&P500 price.

% 3: We only consider out-of-money options (see white paper)

% 4: The zero coupon curve is interpolated using a cubic spline.

% 5: We compute VIX for 10,30,60,91,122,152,182,273,365,547, and 730 days
% to expiry. These are NOT observable at each point in time. We therefore
% use linear interpolation between observable expiration lengths. If an
% expiration length (e.g. 730) falls outside of the observable domain, we
% extrapolate by assigning corner observations.

%% VIX calculation
clearvars -except spxopt spxprice zerocoupondata
close all
clc

data.dates          = table2array(spxopt(:,"date"));
if isa(data.dates,'datetime') % if datetime, convert to double
    data.dates = yyyymmdd(data.dates);
elseif ~isnumeric(data.dates) 
    error('data.dates: unsupported date type %s', class(data.dates))        
end
unique_dates        = unique(data.dates,'stable');
N_obs               = length(unique_dates);

data.exdate         = table2array(spxopt(:,"exdate"));
data.cp_flag        = table2array(spxopt(:,"cp_flag"));
data.strike         = table2array(spxopt(:,"strike_price"))/1000;
data.bid            = table2array(spxopt(:,"best_bid"));
data.offer          = table2array(spxopt(:,"best_offer"));
data.volume         = table2array(spxopt(:,"volume"));
data.oi             = table2array(spxopt(:,"open_interest"));

data.spxprice.date  = table2array(spxprice(:,"date"));
if isa(data.spxprice.date,'datetime') % if datetime, convert to double
    data.spxprice.date = yyyymmdd(data.spxprice.date);
elseif ~isnumeric(data.spxprice.date) 
    error('data.spxprice.date: unsupported date type %s', class(data.spxprice.date))        
end
data.spxprice.price = table2array(spxprice(:,"close"));

data.zcoupon.date   = table2array(zerocoupondata(:,"date"));
if isa(data.zcoupon.date,'datetime') % if datetime, convert to double
    data.zcoupon.date = yyyymmdd(data.zcoupon.date);
elseif ~isnumeric(data.zcoupon.date) 
    error('zcoupon.date: unsupported date type %s', class(data.zcoupon.date))    
end
data.zcoupon.days   = table2array(zerocoupondata(:,"days"));
data.zcoupon.rate   = table2array(zerocoupondata(:,"rate"));

VIX_storage         = cell(N_obs,1);
MAT_storage         = cell(N_obs,1);
VOL_storage         = cell(N_obs,1);
obs_per_date        = nan(N_obs,2);        
BAS_per_date        = nan(N_obs,1);    % average bid-ask, volume sum
BAS_per_date_cell   = cell(N_obs,1);
OBS_per_date_cell   = cell(N_obs,1);

for t = 1:N_obs
    
    % Get maturities at date t
    tmp1.index       = (data.dates == unique_dates(t));
    tmp1.nobs        = sum(tmp1.index);
    obs_per_date(t,1)= tmp1.nobs;
    tmp1.exdate      = datenum2datetime(data.exdate(tmp1.index));
    tmp1.date_t      = datenum2datetime(unique_dates(t));
    tmp1.maturity    = days365(repmat(tmp1.date_t,tmp1.nobs,1),tmp1.exdate);
    tmp1.uniquemat   = unique(tmp1.maturity);
    obs_per_date(t,2)= sum(tmp1.maturity==max(tmp1.uniquemat)); 
    MAT_storage{t}   = tmp1.uniquemat;
    VOL_storage{t}   = nan(length(tmp1.uniquemat),6);
    
    % Get option price data
    tmp1.cp_flag     = data.cp_flag(tmp1.index);
    tmp1.strike      = data.strike(tmp1.index);
    tmp1.bid         = data.bid(tmp1.index);
    tmp1.offer       = data.offer(tmp1.index);
    tmp1.volume      = data.volume(tmp1.index);
    tmp1.oi          = data.oi(tmp1.index);
    BAS_per_date(t,1)= median((tmp1.offer-tmp1.bid)./((tmp1.bid+tmp1.offer)/2),'omitnan');

    % Get zero coupon curve using cubic spline
    zcc_idx_new     = (data.zcoupon.date==unique_dates(t));
    if sum(zcc_idx_new)>0
        zcc_idx     = zcc_idx_new;
    end
    zcc_x           = data.zcoupon.days(zcc_idx);
    zcc_y           = data.zcoupon.rate(zcc_idx)/100;
    zcc             = spline(zcc_x,zcc_y,tmp1.uniquemat);
    
    % Get spx price
    spx_idx         = (data.spxprice.date==unique_dates(t));
    spx_price       = data.spxprice.price(spx_idx);
    
    % Prepare storage
    VIX             = [tmp1.uniquemat,nan(length(tmp1.uniquemat),1)];
    
    % loop over maturities
    BAS_tmp = nan(1,length(tmp1.uniquemat));
    OBS_tmp = nan(1,length(tmp1.uniquemat));

    for i = 1:length(tmp1.uniquemat)
        
        % Get T as measured in years
        dT               = (tmp1.uniquemat(i)/365);
        
        % drop if maturity is wrong and if bid is zero
        tmp2.index       = (tmp1.maturity == tmp1.uniquemat(i)) & not(tmp1.bid == 0);
        tmp2.cp_flag     = tmp1.cp_flag(tmp2.index);
        tmp2.strike      = tmp1.strike(tmp2.index);
        tmp2.bid         = tmp1.bid(tmp2.index);
        tmp2.offer       = tmp1.offer(tmp2.index);
        tmp2.midprice    = (tmp2.bid+tmp2.offer)/2;
        BAS_tmp(i)       = median((tmp2.offer-tmp2.bid)./((tmp2.bid+tmp2.offer)/2),'omitnan');
        OBS_tmp(i)       = length(tmp2.offer);

        VOL_storage{t}(i,1:3) = [sum(tmp1.volume(tmp2.index)),mean(tmp1.volume(tmp2.index)),median(tmp1.volume(tmp2.index))];
        VOL_storage{t}(i,4:6) = [sum(tmp1.oi(tmp2.index)),mean(tmp1.oi(tmp2.index)),median(tmp1.oi(tmp2.index))];


        % Get vector of unique strikes
        unique_strike    = unique(tmp2.strike);
        
        % Find forward index level using spot price
        fwd_index = exp(zcc(i)*dT)*spx_price;
        
       
        % Find K0 (first strike below or equal to fwd_index)
        KlessF     = (unique_strike-fwd_index);
        KlessF_neg = KlessF(KlessF<=0);
        [MAX,IDX]  = max(KlessF_neg);
        K0         = unique_strike(IDX);
        
        if not(isempty(K0))
            % Call leg of VIX
            C_idx         = (tmp2.cp_flag == categorical("C") & tmp2.strike>=K0);
            K_vec         = tmp2.strike(C_idx);
            Q_vec         = tmp2.midprice(C_idx);
            [K_vec,S_idx] = sort(K_vec);
            Q_vec         = Q_vec(S_idx);
            if sum(C_idx)<=1
            Call_Leg      = 0;
            elseif sum(C_idx)==2
            dK_vec        = [K_vec(2)-K_vec(1);...
                             K_vec(end)-K_vec(end-1)];
            Call_Leg      = (2/dT)*exp(zcc(i)*dT)*sum((Q_vec.*dK_vec)./(K_vec.^2));
            else
            dK_vec        = [K_vec(2)-K_vec(1);...
                             (K_vec(3:end)-K_vec(1:end-2))/2;...
                             K_vec(end)-K_vec(end-1)];
            Call_Leg      = (2/dT)*exp(zcc(i)*dT)*sum((Q_vec.*dK_vec)./(K_vec.^2));
            end

            % Put leg of VIX
            P_idx         = (tmp2.cp_flag == categorical("P") & tmp2.strike<=K0);
            K_vec         = tmp2.strike(P_idx);
            Q_vec         = tmp2.midprice(P_idx);
            [K_vec,S_idx] = sort(K_vec);
            Q_vec         = Q_vec(S_idx);
            if sum(P_idx)<=1
            Put_Leg       = 0;
            elseif sum(P_idx)==2
            dK_vec        = [K_vec(2)-K_vec(1);...
                             K_vec(end)-K_vec(end-1)];
            Put_Leg       = (2/dT)*exp(zcc(i)*dT)*sum((Q_vec.*dK_vec)./(K_vec.^2));
            else
            dK_vec        = [K_vec(2)-K_vec(1);...
                             (K_vec(3:end)-K_vec(1:end-2))/2;...
                             K_vec(end)-K_vec(end-1)];
            Put_Leg       = (2/dT)*exp(zcc(i)*dT)*sum((Q_vec.*dK_vec)./(K_vec.^2));
            end

            % Calculate and store VIX
            sig2          = Call_Leg+Put_Leg-(1/dT)*(fwd_index/K0-1)^2;
            if sig2>0
                VIX(i,2)  = 100*sqrt(sig2);
            end
        end   
    end

    BAS_per_date_cell{t} = BAS_tmp;
    OBS_per_date_cell{t} = OBS_tmp;
    
    VIX_storage{t}    = VIX;
    
    if mod(t,100)==0
        fprintf("\n" + num2str(t) + " of " + num2str(N_obs) + " periods done...")
    end
end

clear t i j tmp1 tmp2 spx_idx spx_price zcc_idx zcc_x zcc_y zcc ...
      uniquestrike fwddev strike_j idx_call idx_put MIN IDX BAS_tmp...
      KlessF KlessF_neg MAX C_idx P_idx S_idx K_vec Q_vec dK_vec OBS_tmp...
      Call_Leg Put_Leg sig2 VIX K0 fwd_index unique_strike zcc_idx_new

  
%% Make dataset using linear interpolation (flat interpolation at corners)
wanted_maturities = [10,30,60,91,122,152,182,273,365,547,730]';
VIX_data          = nan(N_obs,length(wanted_maturities));

for t = 1:N_obs
    
    VIX_t         = VIX_storage{t};
    x             = VIX_t(:,1);
    y             = VIX_t(:,2);
    idx           = not(isnan(y));
    VIX_data(t,:) = interp1(x(idx),y(idx),wanted_maturities);
    outside       = isnan(VIX_data(t,:));
    tmp1          = 1:length(outside);
    tmp2          = tmp1(outside);
    
    [minV,minI]   = min(x);
    [maxV,maxI]   = max(x);

    for i = tmp2
        if wanted_maturities(i)<minV
            VIX_data(t,i) = y(minI);
        elseif wanted_maturities(i)>maxV
            VIX_data(t,i) = y(maxI);
        end
    end
    
end

clear t VIX_t x y idx outside tmp1 tmp2 minV minI maxV maxI i

dn        = unique_dates;
dt        = datenum2datetime(dn);
datatable = [table(dn,dt),array2table(VIX_data)];
varnames  = ["datenum","date",repmat("",1,length(wanted_maturities))];
for i = 1:length(wanted_maturities)
    varnames(2+i) = "VIX_"+num2str(wanted_maturities(i));
end
datatable.Properties.VariableNames = varnames;

% Various statistics
fprintf("\nAvg. number of observations per date:")
round(size(spxopt,1)/N_obs,0)
fprintf("\nAvg. number of maturities per date:")
tmp=nan(N_obs,3);for t=1:N_obs;tmp(t,:)=[max(VIX_storage{t}(:,1)),min(VIX_storage{t}(:,1)),length(VIX_storage{t}(:,1))];end
round([max(tmp(:,1)),min(tmp(:,1)),sum(tmp(:,3))/N_obs],0)


clear spxopt spxprice zerocoupondata % to save disk space (info already available in the .csv files)

writetable(datatable,'VIX_data_daily.xlsx','Sheet',1)
clear data; save("VIX_data.mat")  %clear proprietary data. Otherwise: save("VIX_data.mat",'-v7.3')


