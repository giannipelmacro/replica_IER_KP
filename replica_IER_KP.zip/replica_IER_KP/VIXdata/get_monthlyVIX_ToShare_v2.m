%% Written by Mathias Krogh, July 2023
% from getdata.m
% 
% Prepared for the paper
% “Real Activity and Uncertainty Shocks: The Long and the Short of It,” 
% Mathias Krogh and Giovanni Pellegrino, International Economic Review, forthcoming


clear variables
close all
clc


%% Load data
data.vix     = load("VIX_data.mat");

%% Prepare monthly dataset for VAR analysis
clearvars -except data 

% settings
startdate     = 1996.00; % full sample, needed for Fig. A2
enddate       = 2025.00+round(6/12,2);
dn            = round(startdate:(1/12):enddate,2)';
T             = length(dn);
dt            = datetime(floor(dn),round(12*(dn-floor(dn))+1,0),repmat(15,T,1));


% VIX data
data.vix.dn       = round(year(data.vix.dt)+(month(data.vix.dt)-1)/12,2);
data.vix.ntd      = nan(length(dn),1);
data.vix.mVIX1    = nan(length(dn),2);
data.vix.mVIX3    = nan(length(dn),2);
data.vix.mVIX12   = nan(length(dn),2);
data.vix.mVIX24   = nan(length(dn),2);
for t=1:length(dn)
    idx                  = (data.vix.dn==dn(t));
    ntd                  = sum(idx);
    vix                  = data.vix.VIX_data(idx,[2,4,7,end-2,end]);
    data.vix.ntd(t)      = ntd;
    data.vix.mVIX1(t,1)  = mean(vix(:,1),'omitnan'); % avg, full month
    data.vix.mVIX3(t,1)  = mean(vix(:,2),'omitnan');
    data.vix.mVIX6(t,1)  = mean(vix(:,3),'omitnan');
    data.vix.mVIX12(t,1) = mean(vix(:,4),'omitnan');
    data.vix.mVIX24(t,1) = mean(vix(:,5),'omitnan');

    data.vix.mVIX1(t,2)  = mean(vix(end-2:end,1),'omitnan'); % avg, last 3 days
    data.vix.mVIX3(t,2)  = mean(vix(end-2:end,2),'omitnan'); 
    data.vix.mVIX6(t,2)  = mean(vix(end-2:end,3),'omitnan'); 
    data.vix.mVIX12(t,2) = mean(vix(end-2:end,4),'omitnan'); 
    data.vix.mVIX24(t,2) = mean(vix(end-2:end,5),'omitnan');
end

clear t idx ntd ret vix

% Data
VIX1  = data.vix.mVIX1(:,1);
VIX3  = data.vix.mVIX3(:,1);
VIX6  = data.vix.mVIX6(:,1);
VIX12 = data.vix.mVIX12(:,1);
VIX24 = data.vix.mVIX24(:,1);



clear data idx 

save("data_monthlyVIX.mat")

%% save monthly VIX indices
% from WriteData2Excel_ToShare.m % Code by Mathias Krogh 

clear
close all
clc

datastruct=load("data_monthlyVIX.mat");


keep        = datastruct.dt >= datetime(2000,1,1); % Excel file starts in 2000:01 (also read by RUN_ME_Fig3.m)
data_vix    = [datastruct.VIX1(keep),datastruct.VIX6(keep),datastruct.VIX12(keep),datastruct.VIX24(keep)];

dates       = datastruct.dt(keep);
dates_str   = num2str(month(dates))+"/"+num2str(year(dates));

vixnames    = {'dates','VIX1M','VIX6M','VIX1Y','VIX2Y'};


% Tables
tab_vix = table(dates_str,data_vix(:,1),data_vix(:,2),data_vix(:,3),data_vix(:,4),'VariableNames',vixnames);

% Write to excel
filename = ['VIXdata_monthly.xlsx'];
writetable(tab_vix,filename,'Sheet',"vix",'Range','A1')

