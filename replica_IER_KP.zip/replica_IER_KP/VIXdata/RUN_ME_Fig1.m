
clear all
clc
load("VIX_data.mat")

%% PLOTS
close all

% Daily VIX for the entire sample
VIX_short = VIX_data(:,2);
VIX_long  = VIX_data(:,end);


%% Plot daily VIX (not reported in the paper)
% sep-dec 2008
idx2008sep = year(dt)==2008 & month(dt)==9;
idx2008oct = year(dt)==2008 & month(dt)==10;
idx2008nov = year(dt)==2008 & month(dt)==11;
idx2008dec = year(dt)==2008 & month(dt)==12;
idx2008mon = [idx2008sep,idx2008oct,idx2008nov,idx2008dec];
idx2008    = any(idx2008mon,2);

figure()
subplot(1,3,2)
plot(dt(idx2008),VIX_short(idx2008),'-k','LineWidth',1.5)
hold on
plot(dt(idx2008),VIX_long(idx2008),'-red','LineWidth',1.5)
hold on
box on
grid on
ylim([10,90])
for m = 1:4
plot(dt(idx2008mon(:,m)),repmat(mean(VIX_short(idx2008mon(:,m))),sum(idx2008mon(:,m))),'--k','LineWidth',2)
hold on
plot(dt(idx2008mon(:,m)),repmat(mean(VIX_long(idx2008mon(:,m))),sum(idx2008mon(:,m))),'--red','LineWidth',2)
hold on
end
legend('VIX 1M','VIX 2Y','interpreter','latex','fontsize',14,'location','se')

tmp = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
b = get(gca,'XTick');  
a = tmp(month(b))'+" '"+extractBetween(""+num2str(year(b')),3,4);
xticks(b)
set(gca,'XTickLabel',a,'fontsize',12,'FontWeight','bold')
xtickangle(45) 
set(gca,'XTickLabel',a,'fontsize',12,'FontWeight','bold')
title("Great Recession",'interpreter','latex','FontSize',18)
set(gca,'TickLabelInterpreter','latex')

% spring 2020
idx2020jan = year(dt)==2020 & month(dt)==1;
idx2020feb = year(dt)==2020 & month(dt)==2;
idx2020mar = year(dt)==2020 & month(dt)==3;
idx2020apr = year(dt)==2020 & month(dt)==4;
idx2020may = year(dt)==2020 & month(dt)==5;
idx2020jun = year(dt)==2020 & month(dt)==6;
idx2020jul = year(dt)==2020 & month(dt)==7;
idx2020aug = year(dt)==2020 & month(dt)==8;
idx2020sep = year(dt)==2020 & month(dt)==9;
idx2020oct = year(dt)==2020 & month(dt)==10;
idx2020nov = year(dt)==2020 & month(dt)==11;
idx2020dec = year(dt)==2020 & month(dt)==12;
idx2020mon = [idx2020jan,idx2020feb,idx2020mar,idx2020apr,idx2020may,idx2020jun,idx2020jul,idx2020aug,idx2020sep,idx2020oct,idx2020nov,idx2020dec];
idx2020mon = [idx2020feb,idx2020mar,idx2020apr,idx2020may];
idx2020    = any(idx2020mon,2);


subplot(1,3,1)
plot(dt(idx2020),VIX_short(idx2020),'-k','LineWidth',1.5)
hold on
plot(dt(idx2020),VIX_long(idx2020),'-red','LineWidth',1.5)
box on
grid on
ylim([10,90])

for m = 1:size(idx2020mon,2)
plot(dt(idx2020mon(:,m)),repmat(mean(VIX_short(idx2020mon(:,m))),sum(idx2020mon(:,m))),'--k','LineWidth',2)
hold on
plot(dt(idx2020mon(:,m)),repmat(mean(VIX_long(idx2020mon(:,m))),sum(idx2020mon(:,m))),'--red','LineWidth',2)
hold on
end

tmp = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
b = get(gca,'XTick');  
a = tmp(month(b))'+" '"+extractBetween(""+num2str(year(b')),3,4);
xticks(b)
set(gca,'XTickLabel',a,'fontsize',12,'FontWeight','bold')
xtickangle(45)
set(gca,'XTickLabel',a,'fontsize',12,'FontWeight','bold')
title("COVID-19",'interpreter','latex','FontSize',18)
set(gca,'TickLabelInterpreter','latex')

% Summer 2002
idx2002apr = year(dt)==2002 & month(dt)==4;
idx2002may = year(dt)==2002 & month(dt)==5;
idx2002jun = year(dt)==2002 & month(dt)==6;
idx2002jul = year(dt)==2002 & month(dt)==7;
idx2002aug = year(dt)==2002 & month(dt)==8;
idx2002sep = year(dt)==2002 & month(dt)==9;
idx2002oct = year(dt)==2002 & month(dt)==10;
idx2002nov = year(dt)==2002 & month(dt)==11;
idx2002dec = year(dt)==2002 & month(dt)==12;

idx2002mon = [idx2002may,idx2002jun,idx2002jul,idx2002aug];%,idx2002sep,idx2002oct,idx2002nov,idx2002dec];
idx2002    = any(idx2002mon,2);

%tiledlayout(2,1)
subplot(1,3,3)
plot(dt(idx2002),VIX_short(idx2002),'-k','LineWidth',1.5)
hold on
plot(dt(idx2002),VIX_long(idx2002),'-red','LineWidth',1.5)

box on
grid on
ylim([10,55])

for m = 1:size(idx2002mon,2)
plot(dt(idx2002mon(:,m)),repmat(mean(VIX_short(idx2002mon(:,m)),'omitnan'),sum(idx2002mon(:,m))),'--k','LineWidth',2)
hold on
plot(dt(idx2002mon(:,m)),repmat(mean(VIX_long(idx2002mon(:,m)),'omitnan'),sum(idx2002mon(:,m))),'--red','LineWidth',2)
hold on
end

tmp = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
b = get(gca,'XTick');  
a = tmp(month(b))'+" '"+extractBetween(""+num2str(year(b')),3,4);
xticks(b)
set(gca,'XTickLabel',a,'fontsize',12,'FontWeight','bold')
xtickangle(45)  
set(gca,'XTickLabel',a,'fontsize',12,'FontWeight','bold')
title("WorldCom",'interpreter','latex','FontSize',18)
set(gca,'TickLabelInterpreter','latex')
set(gcf,'position',[846   762   736   217])



%% Plot weekly VIX
% Average over the available trading days in each Monday-Friday calendar week,
% stored at the first trading day of the week
wk = floor(datenum(dt)) - weekday(dt) + 2;                 % date of the Monday of each trading day's week
[~, firstIdx, g] = unique(wk, 'stable');
weekly.VIX_short = nan(N_obs,1);
weekly.VIX_long  = nan(N_obs,1);
weekly.idx       = false(N_obs,1);
weekly.VIX_short(firstIdx) = accumarray(g, VIX_short, [], @(x) mean(x,'omitnan'));
weekly.VIX_long(firstIdx)  = accumarray(g, VIX_long,  [], @(x) mean(x,'omitnan'));
weekly.idx(firstIdx)       = true;

% sep-dec 2008
idx2008sep = year(dt)==2008 & month(dt)==9;
idx2008oct = year(dt)==2008 & month(dt)==10;
idx2008nov = year(dt)==2008 & month(dt)==11;
idx2008dec = year(dt)==2008 & month(dt)==12;
idx2008mon = [idx2008sep,idx2008oct,idx2008nov,idx2008dec];
idx2008    = any(idx2008mon,2);

figure()
subplot(1,3,2)
plot(dt(idx2008 & weekly.idx),weekly.VIX_short(idx2008 & weekly.idx),'-k','LineWidth',1.5)
hold on
plot(dt(idx2008 & weekly.idx),weekly.VIX_long(idx2008 & weekly.idx),'-red','LineWidth',1.5)
box on
grid on
ylim([10,90])
for m = 1:4
plot(dt(idx2008mon(:,m)),repmat(mean(VIX_short(idx2008mon(:,m))),sum(idx2008mon(:,m))),'--k','LineWidth',2)
hold on
plot(dt(idx2008mon(:,m)),repmat(mean(VIX_long(idx2008mon(:,m))),sum(idx2008mon(:,m))),'--red','LineWidth',2)
hold on
end
legend('VIX 1M','VIX 2Y','interpreter','latex','fontsize',14-2,'location','se')

tmp = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
b = get(gca,'XTick');  
a = tmp(month(b))'+" '"+extractBetween(""+num2str(year(b')),3,4);
xticks(b)
set(gca,'XTickLabel',a,'fontsize',12,'FontWeight','bold')
xtickangle(45)
title("Great Recession",'interpreter','latex','FontSize',18)
set(gca,'TickLabelInterpreter','latex')

% spring 2020
idx2020jan = year(dt)==2020 & month(dt)==1;
idx2020feb = year(dt)==2020 & month(dt)==2;
idx2020mar = year(dt)==2020 & month(dt)==3;
idx2020apr = year(dt)==2020 & month(dt)==4;
idx2020may = year(dt)==2020 & month(dt)==5;
idx2020jun = year(dt)==2020 & month(dt)==6;
idx2020jul = year(dt)==2020 & month(dt)==7;
idx2020aug = year(dt)==2020 & month(dt)==8;
idx2020sep = year(dt)==2020 & month(dt)==9;
idx2020oct = year(dt)==2020 & month(dt)==10;
idx2020nov = year(dt)==2020 & month(dt)==11;
idx2020dec = year(dt)==2020 & month(dt)==12;
idx2020mon = [idx2020jan,idx2020feb,idx2020mar,idx2020apr,idx2020may,idx2020jun,idx2020jul,idx2020aug,idx2020sep,idx2020oct,idx2020nov,idx2020dec];
idx2020mon = [idx2020feb,idx2020mar,idx2020apr,idx2020may];
idx2020    = any(idx2020mon,2);


subplot(1,3,1)
plot(dt(idx2020 & weekly.idx),weekly.VIX_short(idx2020 & weekly.idx),'-k','LineWidth',1.5)
hold on
plot(dt(idx2020 & weekly.idx),weekly.VIX_long(idx2020 & weekly.idx),'-red','LineWidth',1.5)
box on
grid on
ylim([10,90])

for m = 1:size(idx2020mon,2)
plot(dt(idx2020mon(:,m)),repmat(mean(VIX_short(idx2020mon(:,m))),sum(idx2020mon(:,m))),'--k','LineWidth',2)
hold on
plot(dt(idx2020mon(:,m)),repmat(mean(VIX_long(idx2020mon(:,m))),sum(idx2020mon(:,m))),'--red','LineWidth',2)
hold on
end

tmp = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
b = get(gca,'XTick');  
a = tmp(month(b))'+" '"+extractBetween(""+num2str(year(b')),3,4);
xticks(b)
set(gca,'XTickLabel',a,'fontsize',12,'FontWeight','bold')
xtickangle(45)
title("COVID-19",'interpreter','latex','FontSize',18)
set(gca,'TickLabelInterpreter','latex')

% Summer 2002
idx2002apr = year(dt)==2002 & month(dt)==4;
idx2002may = year(dt)==2002 & month(dt)==5;
idx2002jun = year(dt)==2002 & month(dt)==6;
idx2002jul = year(dt)==2002 & month(dt)==7;
idx2002aug = year(dt)==2002 & month(dt)==8;
idx2002sep = year(dt)==2002 & month(dt)==9;
idx2002oct = year(dt)==2002 & month(dt)==10;
idx2002nov = year(dt)==2002 & month(dt)==11;
idx2002dec = year(dt)==2002 & month(dt)==12;

idx2002mon = [idx2002may,idx2002jun,idx2002jul,idx2002aug];%,idx2002sep,idx2002oct,idx2002nov,idx2002dec];
idx2002    = any(idx2002mon,2);

%tiledlayout(2,1)
subplot(1,3,3)
plot(dt(idx2002 & weekly.idx),weekly.VIX_short(idx2002 & weekly.idx),'-k','LineWidth',1.5)
hold on
plot(dt(idx2002 & weekly.idx),weekly.VIX_long(idx2002 & weekly.idx),'-red','LineWidth',1.5)

box on
grid on
ylim([10,55])

for m = 1:size(idx2002mon,2)
plot(dt(idx2002mon(:,m)),repmat(mean(VIX_short(idx2002mon(:,m)),'omitnan'),sum(idx2002mon(:,m))),'--k','LineWidth',2)
hold on
plot(dt(idx2002mon(:,m)),repmat(mean(VIX_long(idx2002mon(:,m)),'omitnan'),sum(idx2002mon(:,m))),'--red','LineWidth',2)
hold on
end

tmp = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
b = get(gca,'XTick');  
a = tmp(month(b))'+" '"+extractBetween(""+num2str(year(b')),3,4);
xticks(b)
set(gca,'XTickLabel',a,'fontsize',12,'FontWeight','bold')
xtickangle(45)
title("WorldCom",'interpreter','latex','FontSize',18)
set(gca,'TickLabelInterpreter','latex')

% set(gcf,'position',[852   457   736   217])
 set(gcf,'position',[711.4000   88.2000  878.4000  270.8000]) 

set(gcf,'PaperUnits','points','PaperPosition',[0 0 736 217],'PaperSize',[736 217]) % same printed size on any OS
print('-dpdf','Fig1') %,'-bestfit');
