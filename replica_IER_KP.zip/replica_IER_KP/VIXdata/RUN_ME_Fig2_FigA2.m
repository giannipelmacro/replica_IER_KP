%% For Data Section
% Mathias Krogh Jan 2023
clear
close all
clc
load("data_monthlyVIX.mat")

set(groot,'defaultAxesTickLabelInterpreter','latex');


%% Correlations among VIX indices and LMN uncertainty measures
X       = [VIX1,VIX6,VIX12,VIX24];


db2     = [2000.00,2022.99];        
idx2    = (dn>=db2(1)) & (dn<=db2(2));    

fprintf("\n Correlations between VIXs (1, 6, 12, 24 months), 2000:01 - 2022:12:")
corr(X(idx2,:))

load("data_Ludvigson/Ludvigson.mat")
fprintf("\n Correlations between Ludvigson Fin. Unc. (1, 3, 12 months), 1960:07 - 2022:12:")
corr(table2array(LudvigsonFinancialUncertainty(:,2:end)))
fprintf("\n Correlations between Ludvigson Fin. Unc. (1, 3, 12 months), 2000:01 - 2022:12:")
corr(table2array(LudvigsonFinancialUncertainty(475:end,2:end)))

clear X db1 idx1 db2 idx2 ans Ludvigson_FinUnc


%% Time Series Plot of various VIX measures from 2000
X       = [VIX1,VIX6,VIX12,VIX24];
names_x = ["VIX{1M}","VIX{6M}","VIX{1Y}","VIX{2Y}"];
db  = [2000.00,2022.99];                  

% Trim data
idx = (dn>=db(1)) & (dn<=db(2));    
X   = X(idx,:);
dnx = dn(idx);
dtx = datetime([floor(dnx),round((dnx-floor(dnx))*12+1,0),15*ones(length(dnx),1)]);

myColors = [
    0.00 0.00 0.00;   % black
    0.33 0.00 0.00;   % dark red
    0.67 0.00 0.00;   % darker red
    1.00 0.00 0.00;   % red
];

styles = { ':', '--','-.','-'}; % choose line styles

% Plot
    figure('WindowState','maximized','Position', [888, 530, 676, 231])%()
for i=1:size(X,2)
    plot(dtx,X(:,i),'linewidth',1.5,'Color', myColors(i,:), ...
         'LineStyle', styles{i})
    hold on
end
recessionplot

legend(names_x,'interpreter','latex','location','nw','fontsize',14)
ylabel("$100\times$Volatility",'interpreter','latex','fontsize',14)

box on
grid on

set(gcf,'Position',[900   681   676   231])
set(gca,'FontSize',16)


orient landscape
print('-dpdf','Fig2.pdf','-bestfit')%,'-fillpage')%


%% Time Series Plot of various VIX measures from 1996
X       = [VIX1,VIX6,VIX12,VIX24];
names_x = ["VIX{1M}","VIX{6M}","VIX{1Y}","VIX{2Y}"];
db  = [1996.00,2022.99];                  

% Trim data
idx = (dn>=db(1)) & (dn<=db(2));    
X   = X(idx,:);
dnx = dn(idx);
dtx = datetime([floor(dnx),round((dnx-floor(dnx))*12+1,0),15*ones(length(dnx),1)]);

myColors = [
    0.00 0.00 0.00;   % black
    0.33 0.00 0.00;   % dark red
    0.67 0.00 0.00;   % darker red
    1.00 0.00 0.00;   % red
];

styles = { ':', '--','-.','-'}; % choose line styles

% Plot
    figure('WindowState','maximized','Position', [888, 530, 676, 231])%()
for i=1:size(X,2)
    plot(dtx,X(:,i),'linewidth',1.5,'Color', myColors(i,:), ...
         'LineStyle', styles{i})
    hold on
end
recessionplot

legend(names_x,'interpreter','latex','location','nw','fontsize',14)
ylabel("$100\times$Volatility",'interpreter','latex','fontsize',14)

box on
grid on

set(gcf,'Position',[900   681   676   231])
set(gca,'FontSize',16)

orient landscape
print('-dpdf','FigA2.pdf','-bestfit')%,'-fillpage')%


%% Time Series Plot of VIX-1m and VIX-2y measures from 2000
X       = [VIX1,VIX24];
names_x = ["VIX{1M}","VIX{2Y}"];
db  = [2000.00,2022.99];                  

% Trim data
idx = (dn>=db(1)) & (dn<=db(2));    
X   = X(idx,:);
dnx = dn(idx);
dtx = datetime([floor(dnx),round((dnx-floor(dnx))*12+1,0),15*ones(length(dnx),1)]);

% Plot
figure('Position', [888, 530, 676, 231])
plot(dtx,X(:,1),'linewidth',1.5,'Color','black')
hold on
plot(dtx,X(:,2),'linewidth',2.5,'Color','red')
recessionplot

legend(names_x,'interpreter','latex','location','nw','fontsize',14)
ylabel("$100\times$Volatility",'interpreter','latex','fontsize',14)

box on
grid on

set(gcf,'Position',[900   681   676   231])
set(gca,'FontSize',16)


corrcoef(X)
