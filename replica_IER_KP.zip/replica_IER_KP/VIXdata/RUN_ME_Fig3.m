%% Scatter plots, w COVID obs, with also NSR 

addpath('utils')

clear
[xlsdata, labels] = xlsread('VIXdata_monthly.xlsx','vix');

LTi=4;
STi=1;

startdate=1;%jan 2000
enddate=276;%dec 2022

datestext=labels(startdate+1:enddate,1);
xlsdata=xlsdata(startdate:enddate,:);

 % select events on scatterplot
 select_sr=[31];
 select_lr=[107];

 disp('Selected dates for sr uncertainty shocks:')
 datestext(select_sr,1)
 disp('Selected dates for lr uncertainty shocks:')
 datestext(select_lr,1)

[B,~,~,~,STATS] = regress(diff(xlsdata(:,LTi)),diff(xlsdata(:,STi)));
disp('The R-squared of the scatterplot regression is:')
STATS(1)

idx=find(abs(diff(xlsdata(:,STi)))>9);
idx2=find(abs(diff(xlsdata(:,LTi)))>3);
idx_=union(idx,idx2);

x1=diff(xlsdata(:,STi));
x2=diff(xlsdata(:,LTi));

 Fig=figure
 scatter(diff(xlsdata(:,STi)),diff(xlsdata(:,LTi)),'bo')   
 text(x1(idx_),x2(idx_),datestext(idx_+1),'VerticalAlignment','bottom','HorizontalAlignment','left','FontSize',12-5,'interpreter','latex')
 lsline %Add least-squares fit line to scatter plot.

 % Extract axes handles of all subplots from the figure
axesHandles = findobj(get(Fig,'Children'), 'flat','Type','axes');
% Set the axis property to square
axis(axesHandles,'square')
 
 hold on

 % Sr shocks dates
 p2=scatter(x1(select_sr-1),x2(select_sr-1),'gx')
 text(x1(select_sr-1),x2(select_sr-1),datestext(select_sr),'VerticalAlignment','bottom','HorizontalAlignment','left','FontSize',12-5,'interpreter','latex','Color','g')
 p3=scatter(x1(select_lr-1),x2(select_lr-1),'r*')
 text(x1(select_lr-1),x2(select_lr-1),datestext(select_lr),'VerticalAlignment','bottom','HorizontalAlignment','left','FontSize',12-5,'interpreter','latex','Color','r')

 legend([p2 p3],{'ST unc. shock restriction','LT unc. shock restriction'},'Location','SouthEast','Fontsize',10-2)

 
 annotation('textbox', [0.205, 0.85, 0.35, 0.08], ...
    'String', ['R-squared: ' num2str(STATS(1), 2)], ...
    'FontSize', 12, ...
    'Interpreter', 'latex', ...
    'EdgeColor', 'none', ...
    'BackgroundColor', 'none');
 vline(0,':k')
 hline(0,':k')
 xlabel('Monthly change in VIX1M','FontSize',16-3,'interpreter','latex')
 ylabel('Monthly change in VIX2Y','FontSize',16-3,'interpreter','latex') 
 
 print('-depsc','Fig3');
 print('-dpdf','Fig3');

%% VIX1M is a sufficient statistics for the VIX2Y?

%%%%%%%%%%%%%%%%%
% EXTRA EVIDENCE
%%%%%%%%%%%%%%%%%%

% INPUTS
p = 12; % number of lags
testLagsVIX2y = 1; % 1 to test joint significance of the lags of the vix-2y (to check whether vix1m is sufficient statistic for vix2y)
                   % 0 to test joint significance of the lags of the vix-1m

vix1m=xlsdata(:,STi);
vix2y=xlsdata(:,LTi);
% -----------------
% P-VALUE OF ST VIX AS SUFFICIENT STATISTICS OF LT VIX 
%%%%%%%%%%%%%%% 1st way %%%%%%%%%%%%%%%%%%%%%% 

% Create lagged matrices
Y = vix2y(p+1:end);  % dependent variable
X = [];

if testLagsVIX2y==1
    for j = 1:p
        X = [X, vix1m(p+1-j:end-j)];  % lags of 1m VIX
    end
    for i = 1:p
        X = [X, vix2y(p+1-i:end-i)];  % own lags
    end
elseif testLagsVIX2y==0
    for i = 1:p
        X = [X, vix2y(p+1-i:end-i)];  % own lags
    end
    for j = 1:p
        X = [X, vix1m(p+1-j:end-j)];  % lags of 1m VIX
    end
end

% Add constant
X = [ones(size(X,1),1), X];

[b, bint, r, rint, stats] = regress(Y, X);

X_restricted = [ones(size(X,1),1), X(:,2:(p+1))];  % constant + only own lags
[b_r,~,~,~,stats_r] = regress(Y, X_restricted);

SSR_u = sum(r.^2);
SSR_r = sum((Y - X_restricted*b_r).^2);
q = p;                      % number of excluded variables (lags of 1m VIX)
k_u = size(X,2);            % number of coefficients in unrestricted model
T_eff = size(X,1);          % effective sample size

F = ((SSR_r - SSR_u)/q) / (SSR_u/(T_eff - k_u));
p_value = 1 - fcdf(F, q, T_eff - k_u);

disp(['F-statistic = ', num2str(F)]);
disp(['p-value = ', num2str(p_value)]);

%%%%%%%%%%%%% 2nd way, same results %%%%%%%%%%%%%%%%%%%

% Build lagged matrices
Y = vix2y(p+1:end);
X_2y = [];
X_1m = [];
for i = 1:p
    X_2y = [X_2y, vix2y(p+1-i:end-i)];
    X_1m = [X_1m, vix1m(p+1-i:end-i)];
end

% Unrestricted model: includes both 1m and 2y lags
X_unrestricted = [ones(size(X_1m,1),1), X_2y, X_1m];
[b_u, ~, r_u] = regress(Y, X_unrestricted);

if testLagsVIX2y==1
    % Restricted model: only 1m lags (drop 2y lags)
    X_restricted = [ones(size(X_1m,1),1), X_1m];
elseif testLagsVIX2y==0
    % Restricted model: only 1m lags (drop 2y lags)
    X_restricted = [ones(size(X_1m,1),1), X_2y];
end
[b_r, ~, r_r] = regress(Y, X_restricted);

% Compute F-test
SSR_u = sum(r_u.^2);
SSR_r = sum(r_r.^2);
q = p;                      % number of restrictions (lags of 2y VIX)
k_u = size(X_unrestricted,2);
T_eff = size(X_unrestricted,1);

F = ((SSR_r - SSR_u)/q) / (SSR_u/(T_eff - k_u));
p_value = 1 - fcdf(F, q, T_eff - k_u);

disp(['F-statistic = ', num2str(F)]);
disp(['p-value = ', num2str(p_value)]);
