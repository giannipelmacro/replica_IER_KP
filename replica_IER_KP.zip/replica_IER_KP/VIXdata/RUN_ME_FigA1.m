clear
close all
clc

load("VIX_data.mat")

%% Plot statistics

set(groot,'defaultAxesTickLabelInterpreter','latex'); 
figure('Position', [888, 530, 676, 231])
yyaxis left
plot(dt,tmp(:,3),'linewidth',1.5)
ylabel("\# of maturities",'interpreter','latex','fontsize',14)
hold on
ylim([0,55])
yyaxis right
plot(dt,tmp(:,1),'linewidth',1.5)
hold on
plot(dt,tmp(:,2),'-k','linewidth',1.5)
ylabel("Time-to-maturity (days)",'interpreter','latex','fontsize',14)
ylim([0,2100])
xlim([dt(1) datetime(2022,12,31)]) % paper sample ends in 2022:12


ax = gca;
ax.YAxis(1).Color = 'k';
ax.YAxis(2).Color = 'k';
legend("\# of maturities (left axis)","Maximum TTM (right axis)","Minimum TTM (right axis)",...
       'interpreter','latex','location','nw','fontsize',14)
box on
grid on

set(gcf,'PaperUnits','points','PaperPosition',[0 0 676 231],'PaperSize',[676 231]); % same printed size on any OS
print('-dpdf','FigA1');