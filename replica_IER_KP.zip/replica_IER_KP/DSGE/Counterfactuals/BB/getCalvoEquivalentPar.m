function [Calvo,PriceDuration]=getCalvoEquivalentPar(phip,betta,thetamu)

% Computes the Calvo parameter from the Rotemberg parameter, based on the
% equivalence results in a first-order approximations
%
% INPUTS:
% phip : Rotemberg adjustment cost
% betta : discount factor
% thetamu: price elasticity of demand
%
% OUTPUTS:
% Calvo: Calvo parameter, probability of not being able to change the price
% PriceDuration: average price duration
% 
% G. Pellegrino
% - see paper by Keen and Wang, "What is a Realistic Value for Price Adjustment Costs in New Keynesian Models?"


% calculation of the probability of being able to change prices (1-probNotAble):
syms probNotAble
eqt= phip==( (thetamu - 1)*probNotAble ) / ( (1-probNotAble)*(1-betta*probNotAble) ) ;
res=solve(eqt, probNotAble);

% calvo probability (of not being able to adjust prices):
if res(1)>0 && res(1)<1
   Calvo=double(round(res(1)*10000)/10000)
end 

if res(2)>0 && res(2)<1    
    Calvo=res(2)
end
    
% calculation average price duration
PriceDuration= 1/(1-Calvo)
