% Part 1: here the reference is the BB model with habits


                         
%%
% This runs counterfactuals and plots the corresponding IRFs performing comparisons

addpath('C:\dynare\4.4.3\matlab');
addpath('../')

cd('BB')

close all
clearvars -except Fig_paper Fig_App_noPersistentST

%%% OPTIONS %%%
Fig_paper=1 % 1 for paper figure; 0 for EXTRA more complete fig showing also hours worked (not reported in appendix)

if Fig_paper==1
    % select which variables to show IRFs among
    %     1        2       3        4           5              6               7            8
    % {'VIX-1Q','VIX-8Q','GDP','Consumption','Investment','Hours worked', 'Policy rate','Inflation (YoY)'};
    select= [0 0 1 1 1 0 0 0] %either 1 or 0
    N_cf = 5  % number counterfactuals done below
    Fontsize = 13
    names={'VIX-1Q','VIX-8Q','GDP (%)','Consumption (%)','Investment (%)','Hours worked (%)','Policy rate (p.p.)','YoY Inflation (p.p.)'}; 
elseif Fig_paper==0
    select= [0 0 1 1 1 1 0 0] %either 1 or 0
    N_cf = 6  % number counterfactuals done below
    Fontsize = 11
    names={'VIX-1Q','VIX-8Q','GDP (%)','Cons. (%)','Inv. (%)','Hours (%)','Pol. rate','Infl.'}; 
end    
ylabs = {'Model w/o TTB', 'Time to build',  'Steady state volatility','Risk aversion', 'Price stickiness',  'Inv. adj. costs', 'No habits', 'xxx'};
%%%%%%%%%%%%%%%

% Find which variables are selected
idx = find(select == 1);
numPlots = length(idx);

%% PLOT figure with IRFs: baseline calibration WITHOUT TTB

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

volass_          = 0.0225;
rhovola_         = 0.40;
rhovola_lr_      = 0.75;
volvola_         = log(1+0.1)  ;
volvola_lr_      = log(1+0.065);
phip_            = 240;
sigma_           = 100;
phik_           = 3.9208; 
delta2_          = 0.00031;
b_ = 0.65;

% Save BASELINE parameters to a .mat file
save('params_Baseline.mat', 'rhovola_', 'rhovola_lr_','volvola_','volvola_lr_','volass_','phip_','sigma_','phik_','delta2_','b_');

% Save parameters to a .mat file
         save('params.mat', 'rhovola_', 'rhovola_lr_','volvola_','volvola_lr_','volass_','phip_','sigma_','phik_','delta2_','b_');

%     Create a function (a Dynare command file to load parameters)
fid = fopen('load_params_dynare.m', 'w');
fprintf(fid, 'load params.mat;\n');
fclose(fid);

dynare BB_HABITS_v3_noPars.mod noclearall nolog nograph nowarn

IRF_DSGE_basel_ST= [100*logvxo_evola, 100*logvxo_evola_8, 100*y_evola./y_sss, 100*c_evola./c_sss, 100*inv_evola./inv_sss, 100*n_evola./n_sss, 400*r_evola, 100*yoyPie_evola]; 
IRF_DSGE_basel_LT= [100*logvxo_evola_lr, 100*logvxo_evola_lr_8, 100*y_evola_lr./y_sss, 100*c_evola_lr./c_sss, 100*inv_evola_lr./inv_sss, 100*n_evola_lr./n_sss, 400*r_evola_lr, 100*yoyPie_evola_lr]; 



%%%%%%%%%%%%%%%%%% 
    ylims = [ 0 10;   % var 1
        0  10;   % var 2
        -0.45  0.05;   % var 3
        -0.35 0.05;% var 4
        -1.00  0.05;   % var 5
        -0.35 0.1 % var 6
        -1 1  % var 7
        -0.2 0.1];% var 8



%% PLOT figure with IRFs: WITH TTB

load params_Baseline.mat

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 % here using another .mod file with TTB *** COUNTERFACTUAL ***


% NOTE: here there is no need to change parameters. The counterfactual consist in
% using a model with time to build (TTB). 
% see the file BB_TTB_KP_HABITS_noPars.mod in the BB_v2 folder, where
% the baseline parameters are used.
% NOTE: all the TTB weights are equal

%%%%%%%%%%%

% Save parameters to a .mat file
save('params.mat', 'rhovola_', 'rhovola_lr_','volvola_','volvola_lr_','volass_','phip_','sigma_','phik_','delta2_','b_');


dynare BB_TTB_KP_HABITS_noPars.mod noclearall nolog nograph nowarn

IRF_DSGE_ST= [100*logvxo_evola, 100*logvxo_evola_8, 100*y_evola./y_sss, 100*c_evola./c_sss, 100*inv_tilde_evola./inv_tilde_sss, 100*n_evola./n_sss, 400*r_evola, 100*yoyPie_evola]; 
IRF_DSGE_LT= [100*logvxo_evola_lr, 100*logvxo_evola_lr_8, 100*y_evola_lr./y_sss, 100*c_evola_lr./c_sss, 100*inv_tilde_evola_lr./inv_tilde_sss, 100*n_evola_lr./n_sss, 400*r_evola_lr, 100*yoyPie_evola_lr]; 

%%%%%%%%%%%%%%%%%% 

Fig=figure("WindowState","maximized");
for i=1:numPlots
    subplot(N_cf,numPlots,i)
    hold on
    plot(zeros(irflength,1),'k--','HandleVisibility','off'); xlim([0 irflength]);set(gca,'XTick',[4:4:irflength],'FontSize',12);
    plot(t,IRF_DSGE_basel_ST(:,idx(i)),':','Color',rgb('dark green'),'LineWidth',2+2,'Marker','o','MarkerSize', 4, 'MarkerIndices', 1:2:irflength, 'MarkerFaceColor', 'none')
    plot(t,IRF_DSGE_basel_LT(:,idx(i)),':','Color',rgb('dark red'),'LineWidth',2+1,'Marker','square','MarkerSize', 3, 'MarkerIndices', 1:2:irflength, 'MarkerFaceColor', 'none')
    p1=plot(t,IRF_DSGE_ST(:,idx(i)),'-','Color','g','LineWidth',3+1)
    p2=plot(t,IRF_DSGE_LT(:,idx(i)),'-.','Color','r','LineWidth',3+1)
    xlim([t(1) t(end)]);set(gca,'XTick',t(4:4:end),'FontSize',Fontsize);
        title(names(idx(i)),'FontSize',Fontsize+3);
    if i==1
        ylabel(ylabs{2},'FontSize',Fontsize,'FontWeight','bold');
    end
    ylim(ylims(idx(i), :));
end

clear IRF_DSGE_ST IRF_DSGE_LT

%% PLOT figure with IRFs: ss volatility 

load params_Baseline.mat

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 volass_  = volass_ * 1.25; % <--- *** COUNTERFACTUAL ***

%%%%%%%%%%%

% Save parameters to a .mat file
save('params.mat', 'rhovola_', 'rhovola_lr_','volvola_','volvola_lr_','volass_','phip_','sigma_','phik_','delta2_','b_');


dynare BB_HABITS_v3_noPars.mod noclearall nolog nograph nowarn

IRF_DSGE_ST= [100*logvxo_evola, 100*logvxo_evola_8, 100*y_evola./y_sss, 100*c_evola./c_sss, 100*inv_evola./inv_sss, 100*n_evola./n_sss, 400*r_evola, 100*yoyPie_evola]; 
IRF_DSGE_LT= [100*logvxo_evola_lr, 100*logvxo_evola_lr_8, 100*y_evola_lr./y_sss, 100*c_evola_lr./c_sss, 100*inv_evola_lr./inv_sss, 100*n_evola_lr./n_sss, 400*r_evola_lr, 100*yoyPie_evola_lr];

%%%%%%%%%%%%%%%%%% 

Fig=figure(1)
for i=1:numPlots
    subplot(N_cf,numPlots,i+numPlots)
    hold on
    plot(zeros(irflength,1),'k--','HandleVisibility','off'); xlim([0 irflength]);set(gca,'XTick',[4:4:irflength],'FontSize',12);
    plot(t,IRF_DSGE_basel_ST(:,idx(i)),':','Color',rgb('dark green'),'LineWidth',2+2,'Marker','o','MarkerSize', 4, 'MarkerIndices', 1:2:irflength, 'MarkerFaceColor', 'none')
    plot(t,IRF_DSGE_basel_LT(:,idx(i)),':','Color',rgb('dark red'),'LineWidth',2+1,'Marker','square','MarkerSize', 3, 'MarkerIndices', 1:2:irflength, 'MarkerFaceColor', 'none')
    plot(t,IRF_DSGE_ST(:,idx(i)),'-','Color','c','LineWidth',3+1,'Marker','d','MarkerSize', 3, 'MarkerIndices', 1:2:irflength, 'MarkerFaceColor', 'none')
    plot(t,IRF_DSGE_LT(:,idx(i)),'-.','Color','m','LineWidth',3+1,'Marker','p','MarkerSize', 3-1, 'MarkerIndices', 1:2:irflength, 'MarkerFaceColor', 'none')
    xlim([t(1) t(end)]);set(gca,'XTick',t(4:4:end),'FontSize',Fontsize);
    if i==1
    ylabel(ylabs(3),'FontSize',Fontsize,'FontWeight','bold');
    end
    ylim(ylims(idx(i), :));
end


clear IRF_DSGE_ST IRF_DSGE_LT

%%%%%%%%%%%%%%%%%

% NOTE: here everything is at parity of irf for the VIXs, i.e., at parity
% of percent increase 


%% PLOT figure with IRFs: risk aversion 

load params_Baseline.mat

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
sigma_           = 150; % <--- *** COUNTERFACTUAL *** 

%%%%%%%%%%%

% Save parameters to a .mat file
save('params.mat', 'rhovola_', 'rhovola_lr_','volvola_','volvola_lr_','volass_','phip_','sigma_','phik_','delta2_','b_');


dynare BB_HABITS_v3_noPars.mod noclearall nolog nograph nowarn

IRF_DSGE_ST= [100*logvxo_evola, 100*logvxo_evola_8, 100*y_evola./y_sss, 100*c_evola./c_sss, 100*inv_evola./inv_sss, 100*n_evola./n_sss, 400*r_evola, 100*yoyPie_evola];
IRF_DSGE_LT= [100*logvxo_evola_lr, 100*logvxo_evola_lr_8, 100*y_evola_lr./y_sss, 100*c_evola_lr./c_sss, 100*inv_evola_lr./inv_sss, 100*n_evola_lr./n_sss, 400*r_evola_lr, 100*yoyPie_evola_lr];

%%%%%%%%%%%%%%%%%% 


Fig=figure(1);
for i=1:numPlots
    subplot(N_cf,numPlots,i+numPlots*2)
    hold on
    plot(zeros(irflength,1),'k--','HandleVisibility','off'); xlim([0 irflength]);set(gca,'XTick',[4:4:irflength],'FontSize',12);
    plot(t,IRF_DSGE_basel_ST(:,idx(i)),':','Color',rgb('dark green'),'LineWidth',2+2,'Marker','o','MarkerSize', 4, 'MarkerIndices', 1:2:irflength, 'MarkerFaceColor', 'none')
    plot(t,IRF_DSGE_basel_LT(:,idx(i)),':','Color',rgb('dark red'),'LineWidth',2+1,'Marker','square','MarkerSize', 3, 'MarkerIndices', 1:2:irflength, 'MarkerFaceColor', 'none')
    plot(t,IRF_DSGE_ST(:,idx(i)),'-','Color','c','LineWidth',3+1,'Marker','d','MarkerSize', 3, 'MarkerIndices', 1:2:irflength, 'MarkerFaceColor', 'none')
    plot(t,IRF_DSGE_LT(:,idx(i)),'-.','Color','m','LineWidth',3+1,'Marker','p','MarkerSize', 3-1, 'MarkerIndices', 1:2:irflength, 'MarkerFaceColor', 'none')    
    xlim([t(1) t(end)]);set(gca,'XTick',t(4:4:end),'FontSize',Fontsize);
    if i==1
    ylabel(ylabs(4),'FontSize',Fontsize,'FontWeight','bold');
    end
    ylim(ylims(idx(i), :));
end


clear IRF_DSGE_ST IRF_DSGE_LT



%% PLOT figure with IRFs: price stickiness 

load params_Baseline.mat
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

phip_            = 340; % <--- *** COUNTERFACTUAL *** 

% Baseline calibration: 
[Calvo,PriceDuration]=getCalvoEquivalentPar(240,0.994,6); % phip, beta, thetamu

% Alternative calibration: 
[Calvo,PriceDuration]=getCalvoEquivalentPar(340,0.994,6); % phip, beta, thetamu
%%%%%%%%%%%

% Save parameters to a .mat file
save('params.mat', 'rhovola_', 'rhovola_lr_','volvola_','volvola_lr_','volass_','phip_','sigma_','phik_','delta2_','b_');


dynare BB_HABITS_v3_noPars.mod noclearall nolog nograph nowarn

IRF_DSGE_ST= [100*logvxo_evola, 100*logvxo_evola_8, 100*y_evola./y_sss, 100*c_evola./c_sss, 100*inv_evola./inv_sss, 100*n_evola./n_sss, 400*r_evola, 100*yoyPie_evola]; 
IRF_DSGE_LT= [100*logvxo_evola_lr, 100*logvxo_evola_lr_8, 100*y_evola_lr./y_sss, 100*c_evola_lr./c_sss, 100*inv_evola_lr./inv_sss, 100*n_evola_lr./n_sss, 400*r_evola_lr, 100*yoyPie_evola_lr]; 

%%%%%%%%%%%%%%%%%% 


Fig=figure(1);
for i=1:numPlots
    subplot(N_cf,numPlots,i+numPlots*3)
    hold on
    plot(zeros(irflength,1),'k--','HandleVisibility','off'); xlim([0 irflength]);set(gca,'XTick',[4:4:irflength],'FontSize',12);
    plot(t,IRF_DSGE_basel_ST(:,idx(i)),':','Color',rgb('dark green'),'LineWidth',2+2,'Marker','o','MarkerSize', 4, 'MarkerIndices', 1:2:irflength, 'MarkerFaceColor', 'none')
    plot(t,IRF_DSGE_basel_LT(:,idx(i)),':','Color',rgb('dark red'),'LineWidth',2+1,'Marker','square','MarkerSize', 3, 'MarkerIndices', 1:2:irflength, 'MarkerFaceColor', 'none')
    plot(t,IRF_DSGE_ST(:,idx(i)),'-','Color','c','LineWidth',3+1,'Marker','d','MarkerSize', 3, 'MarkerIndices', 1:2:irflength, 'MarkerFaceColor', 'none')
    plot(t,IRF_DSGE_LT(:,idx(i)),'-.','Color','m','LineWidth',3+1,'Marker','p','MarkerSize', 3-1, 'MarkerIndices', 1:2:irflength, 'MarkerFaceColor', 'none')    
    xlim([t(1) t(end)]);set(gca,'XTick',t(4:4:end),'FontSize',Fontsize);
    if i==1
    ylabel(ylabs(5),'FontSize',Fontsize,'FontWeight','bold');
    end
    ylim(ylims(idx(i), :));
end

clear IRF_DSGE_ST IRF_DSGE_LT


%% PLOT figure with IRFs: inv adj costs 

load params_Baseline.mat

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 phik_           = 10; % <--- *** COUNTERFACTUAL *** 
%%%%%%%%%%%

% Save parameters to a .mat file
save('params.mat', 'rhovola_', 'rhovola_lr_','volvola_','volvola_lr_','volass_','phip_','sigma_','phik_','delta2_','b_');


dynare BB_HABITS_v3_noPars.mod noclearall nolog nograph nowarn

IRF_DSGE_ST= [100*logvxo_evola, 100*logvxo_evola_8, 100*y_evola./y_sss, 100*c_evola./c_sss, 100*inv_evola./inv_sss, 100*n_evola./n_sss, 400*r_evola, 100*yoyPie_evola];
IRF_DSGE_LT= [100*logvxo_evola_lr, 100*logvxo_evola_lr_8, 100*y_evola_lr./y_sss, 100*c_evola_lr./c_sss, 100*inv_evola_lr./inv_sss, 100*n_evola_lr./n_sss, 400*r_evola_lr, 100*yoyPie_evola_lr]; 

%%%%%%%%%%%%%%%%%% 


Fig=figure(1);
for i=1:numPlots
    subplot(N_cf,numPlots,i+numPlots*4)
    hold on
    plot(zeros(irflength,1),'k--','HandleVisibility','off'); xlim([0 irflength]);set(gca,'XTick',[4:4:irflength],'FontSize',12);
   p3= plot(t,IRF_DSGE_basel_ST(:,idx(i)),':','Color',rgb('dark green'),'LineWidth',2+2,'Marker','o','MarkerSize', 4, 'MarkerIndices', 1:2:irflength, 'MarkerFaceColor', 'none')
   p4= plot(t,IRF_DSGE_basel_LT(:,idx(i)),':','Color',rgb('dark red'),'LineWidth',2+1,'Marker','square','MarkerSize', 3, 'MarkerIndices', 1:2:irflength, 'MarkerFaceColor', 'none')
   p5= plot(t,IRF_DSGE_ST(:,idx(i)),'-','Color','c','LineWidth',3+1,'Marker','d','MarkerSize', 3, 'MarkerIndices', 1:2:irflength, 'MarkerFaceColor', 'none')
   p6= plot(t,IRF_DSGE_LT(:,idx(i)),'-.','Color','m','LineWidth',3+1,'Marker','p','MarkerSize', 3-1, 'MarkerIndices', 1:2:irflength, 'MarkerFaceColor', 'none')  
    xlim([t(1) t(end)]);set(gca,'XTick',t(4:4:end),'FontSize',Fontsize);
    if i==1
    ylabel(ylabs(6),'FontSize',Fontsize,'FontWeight','bold');
    end
    ylim(ylims(idx(i), :));
end

    legend([p3 p4 p1 p2 p5 p6],{'ST shock: Model w/o TTB (BB model with habits)','LT shock: Model w/o TTB (BB model with habits)','ST shock: Model w TTB (Baseline model)','LT shock: Model w TTB (Baseline model)','ST shock: Counterfactual','LT shock: Counterfactual'}, ...
         'NumColumns', 2,'FontSize',8+1,'Orientation','Horizontal','Position',[0.305555548378163 0.0435252087534876 0.433854173844059 0.0235042739372986])


clear IRF_DSGE_ST IRF_DSGE_LT

%%%%%%%%%%%%%%%%%

%% PLOT figure with IRFs: No Habits

if Fig_paper==0

    load params_Baseline.mat

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    b_           = 0; % <--- *** COUNTERFACTUAL ***

    %%%%%%%%%%%

    % Save parameters to a .mat file
    save('params.mat', 'rhovola_', 'rhovola_lr_','volvola_','volvola_lr_','volass_','phip_','sigma_','phik_','delta2_','b_');


    dynare BB_HABITS_v3_noPars.mod noclearall nolog nograph nowarn

    IRF_DSGE_ST= [100*logvxo_evola, 100*logvxo_evola_8, 100*y_evola./y_sss, 100*c_evola./c_sss, 100*inv_evola./inv_sss, 100*n_evola./n_sss, 400*r_evola, 100*yoyPie_evola]; 
    IRF_DSGE_LT= [100*logvxo_evola_lr, 100*logvxo_evola_lr_8, 100*y_evola_lr./y_sss, 100*c_evola_lr./c_sss, 100*inv_evola_lr./inv_sss, 100*n_evola_lr./n_sss, 400*r_evola_lr, 100*yoyPie_evola_lr];

    %%%%%%%%%%%%%%%%%%

    Fig=figure(1);
    for i=1:numPlots
        subplot(N_cf,numPlots,i+numPlots*5)
        hold on
        plot(zeros(irflength,1),'k--','HandleVisibility','off'); xlim([0 irflength]);set(gca,'XTick',[4:4:irflength],'FontSize',12);
    p3=    plot(t,IRF_DSGE_basel_ST(:,idx(i)),':','Color',rgb('dark green'),'LineWidth',2+2,'Marker','o','MarkerSize', 4, 'MarkerIndices', 1:2:irflength, 'MarkerFaceColor', 'none')
    p4=    plot(t,IRF_DSGE_basel_LT(:,idx(i)),':','Color',rgb('dark red'),'LineWidth',2+1,'Marker','square','MarkerSize', 3, 'MarkerIndices', 1:2:irflength, 'MarkerFaceColor', 'none')
    p5=    plot(t,IRF_DSGE_ST(:,idx(i)),'-','Color','c','LineWidth',3+1,'Marker','d','MarkerSize', 3, 'MarkerIndices', 1:2:irflength, 'MarkerFaceColor', 'none')
    p6=  plot(t,IRF_DSGE_LT(:,idx(i)),'-.','Color','m','LineWidth',3+1,'Marker','p','MarkerSize', 3, 'MarkerIndices', 1:2:irflength, 'MarkerFaceColor', 'none')
        xlim([t(1) t(end)]);set(gca,'XTick',t(4:4:end),'FontSize',Fontsize);
        if i==1
            ylabel(ylabs(7),'FontSize',Fontsize,'FontWeight','bold');
        end
        ylim(ylims(idx(i), :));
    end
    legend([p3 p4 p1 p2 p5 p6],{'ST shock: Model w/o TTB (BB model with habits)','LT shock: Model w/o TTB (BB model with habits)','ST shock: Model w TTB (Baseline model)','LT shock: Model w TTB (Baseline model)','ST shock: Counterfactual','LT shock: Counterfactual'}, ...
         'NumColumns', 2,'FontSize',8+1,'Orientation','Horizontal','Position',[0.305555548378163 0.0435252087534876 0.433854173844059 0.0235042739372986])


    clear IRF_DSGE_ST IRF_DSGE_LT

    %%%%%%%%%%%%%%%%%



end


%% Save figure

cd('../')

    if Fig_paper==1
        orient tall
        print('-depsc','Fig9');
        print('-dpdf','Fig9','-fillpage');
    end

