
clear, clc
close all


%% run mod file

addpath 'C:\dynare\4.4.3\matlab'

addpath('../../')

dynare BB_TTB_KP_HABITS.mod noclearall

%% plot quarterly aggregated VAR IRFs

% model              = load("results VIX3M_nonrobust.mat"); % this needs first to be produced in VAR/Checks Appendix/VIX3M_nonrobust (by running sendfile.m), and then pasted here
model = load(fullfile('..','..','..','VAR','Checks Appendix','VIX3M_nonrobust','results VIX3M_nonrobust.mat')); % produced by running sendfile.m in VAR/Checks Appendix/VIX3M_nonrobust


%%% ------------- get quarterly aggregated IRFs -----------------------
% take quarterly averages of irfs
IRFs_quarterly=NaN(20,2,2);
IRFs_lb_quarterly=NaN(20,2,2);
IRFs_ub_quarterly=NaN(20,2,2);

cc=1;
bb=1;
while bb<size(model.rSinglePriorMean_IRF,1)
    temp=zeros(1,2,2);
    temp_lb=zeros(1,2,2);
    temp_ub=zeros(1,2,2);
    for uu=0:2
       temp = temp + model.rSinglePriorMean_IRF(bb+uu,[1,2],[1,2]); % horizon, variables, shocks
       temp_lb=temp_lb + model.hpdlb_IRF(bb+uu,[1,2],[1,2]); 
       temp_ub=temp_ub + model.hpdub_IRF(bb+uu,[1,2],[1,2]);        
    end
    IRFs_quarterly(cc,:,:)= temp./3;
    IRFs_lb_quarterly(cc,:,:)= temp_lb./3;%approx, averages of the monthly 68% bounds rather than exact quarterly HPD intervals.
    IRFs_ub_quarterly(cc,:,:)= temp_ub./3;%approx, averages of the monthly 68% bounds rather than exact quarterly HPD intervals.
    cc=cc+1;
    bb=bb+3;
    clear temp
end


%%% -------------------------------------------------------------------


colorcodes             = [[0.4660 0.6740 0.1880];... % green
                          [0.6350 0.0780 0.1840]];

ExPostAnalysis         = true;

set(groot,'defaultAxesTickLabelInterpreter','latex');

ni         = model.ni;
nj         = model.nj;
opt        = model.opt;
irfUnits   = model.irfUnits;
varnames   = model.varnames;varnames{5}='Policy Rate';
shocknames = model.shocknames;
dates      = model.dates;

% ----------
opt.H=20; 
%NOTE: here the index goes from 1 to 20 (rather from 0 to 19) to be
%consistent with DSGE
% --------------

% Two plots: One for vix response, one for macro response
varnames_short = ["VIX 1Q","VIX 2Y","Unempl","Inflation","Policy Rate"];
shocknames_new = ["Short-term Shock","Long-term Shock","S3","S4","S5"];
ylimss         = [-02.50,10.00;...
                  -02.00,06.00;...
                  -00.20,00.35;...
                  -00.25,00.25;...
                  -37.50,15.00];

for xx = 1 

    figure;

    if xx == 1
        tvars = [1,2];
    elseif xx == 2
        tvars = [3,4,5];
    elseif xx == 3
        tvars = [1,2,3,4,5];
    end

    for iix = 1:length(tvars)

        ii  = tvars(iix); 

        for jj = 1:nj

            subplot(length(tvars),2,(iix-1)*2+jj) 

            h0 = plot(1:opt.H,zeros(1,1+opt.H-1),'-k','linewidth',1); 

            axis tight 

            grid on
            hold on
            ylim(ylimss(ii,:))
    
            
if jj==1
    h1 = plot(1:opt.H,IRFs_quarterly(:,ii,jj),'--','color',colorcodes(jj,:),'linewidth',2);
elseif jj==2
    h3 = plot(1:opt.H,IRFs_quarterly(:,ii,jj),'--','color',colorcodes(jj,:),'linewidth',2); 
end

            if opt.PlotAlpha
    
                h2 = fill([1:opt.H,fliplr(1:opt.H)], [IRFs_lb_quarterly(:,ii,jj)', fliplr(IRFs_ub_quarterly(:,ii,jj)')], colorcodes(jj,:),'facealpha',0.40,'edgealpha',0); 
  
            end

            
            
            if iix == 1
                title(sprintf('%s',"\textbf{"+shocknames_new{jj}+"}"),'interpreter','latex','Fontsize',16);
            end

             xticks(4:4:opt.H); 

            if jj == 1
                if irfUnits(opt.ivar(ii)) == 0
                    ylabel(varnames_short(ii)+" (\%)",'interpreter','latex','FontSize',14);
                elseif irfUnits(opt.ivar(ii)) == 1
                    ylabel(varnames_short(ii)+" (ppt)",'interpreter','latex','FontSize',14);
                elseif irfUnits(opt.ivar(ii)) == 2
                    ylabel(varnames_short(ii)+" (bps)",'interpreter','latex','FontSize',14);
                elseif irfUnits(opt.ivar(ii)) == 3
                    ylabel(varnames_short(ii)+" (lvl)",'interpreter','latex','FontSize',14)
                elseif irfUnits(opt.ivar(ii)) == 4
                    ylabel(varnames_short(ii)+" (stdd)",'interpreter','latex','FontSize',14)
                end
            end

        end

    end

end

%% Add DSGE IRFs to previous graph

subplot(2,2,1)
p1=plot(100*logvxo_evola,'-','Color','g','LineWidth',3+1);
lg=legend([h1 p1],{'VAR (\& $68\%$ bands)','DSGE'},'Interpreter','latex');
lg.AutoUpdate = 'off';
subplot(2,2,3)
plot(100*logvxo_evola_8,'-','Color','g','LineWidth',3+1)
subplot(2,2,2)
p3=plot(100*logvxo_evola_lr,'-','Color','r','LineWidth',3+1);
lg=legend([h3 p3], {'VAR (\& $68\%$ bands)', 'DSGE'},'Interpreter','latex');
lg.AutoUpdate = 'off';
subplot(2,2,4)
plot(100*logvxo_evola_lr_8,'-','Color','r','LineWidth',3+1)



%% save fig

print('-depsc','FigA17');
print('-dpdf','FigA17','-bestfit');

