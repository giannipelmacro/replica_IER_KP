% Run after RUN_ME_Fig9.m in Counterfatctuals folder (to load data)

% Computes and displays, for Section 5 of the paper:
%  - the peak (trough) investment response to short-term (ST) and
%    long-term (LT) uncertainty shocks, with and without time-to-build
%    (baseline DSGE model, N=6 gestation, equal weights);
%  - the resulting LT/ST peak-response ratio, with and without
%    time-to-build;
%  - the same LT/ST peak-response ratio implied by the empirical LP
%    responses of investment (Figure 7), for comparison.
%
% "Peak" is defined as the most negative (trough) value over the 20-quarter
% horizon for the DSGE IRFs, and over the 16-quarter horizon for the LP
% IRFs -- i.e., the peak of the CONTRACTION, not the largest absolute value.

clear; close all; clc

addpath('C:\dynare\4.4.3\matlab');
addpath('../..');   % DSGE root, for sss.m / irfsss.m

startDir = pwd;

%% DSGE model: without time-to-build

cd('../../Counterfactuals/BB')

load params_Baseline.mat % need to run RUN_ME_Fig9.m first
save('params.mat', 'rhovola_', 'rhovola_lr_','volvola_','volvola_lr_','volass_','phip_','sigma_','phik_','delta2_','b_');
fid = fopen('load_params_dynare.m', 'w');
fprintf(fid, 'load params.mat;\n');
fclose(fid);

dynare BB_HABITS_v3_noPars.mod noclearall nolog nograph nowarn

inv_noTTB_ST = 100*inv_evola./inv_sss;
inv_noTTB_LT = 100*inv_evola_lr./inv_sss;

%% DSGE model: with time-to-build (N=6, equal weights)

load params_Baseline.mat
save('params.mat', 'rhovola_', 'rhovola_lr_','volvola_','volvola_lr_','volass_','phip_','sigma_','phik_','delta2_','b_');

dynare BB_TTB_KP_HABITS_noPars.mod noclearall nolog nograph nowarn

inv_TTB_ST = 100*inv_tilde_evola./inv_tilde_sss;
inv_TTB_LT = 100*inv_tilde_evola_lr./inv_tilde_sss;

%% Peak (trough) DSGE responses and LT/ST ratios

[peak_noTTB_ST, h_noTTB_ST] = min(inv_noTTB_ST);
[peak_noTTB_LT, h_noTTB_LT] = min(inv_noTTB_LT);
[peak_TTB_ST,   h_TTB_ST]   = min(inv_TTB_ST);
[peak_TTB_LT,   h_TTB_LT]   = min(inv_TTB_LT);

ratio_noTTB = abs(peak_noTTB_LT)/abs(peak_noTTB_ST);
ratio_TTB   = abs(peak_TTB_LT)/abs(peak_TTB_ST);

%% Empirical LP comparison (Figure 7): peak investment response and LT/ST ratio

cd(startDir)

ST_LP = load('results_LP_ST.mat','irfs_lpiv');
LT_LP = load('results_LP_LT.mat','irfs_lpiv');
inv_LP_ST = ST_LP.irfs_lpiv(3,:); % row 3 = investment, see RUN_ME_Fig7_FigA14.m
inv_LP_LT = LT_LP.irfs_lpiv(3,:);

[peak_LP_ST, h_LP_ST] = min(inv_LP_ST);
[peak_LP_LT, h_LP_LT] = min(inv_LP_LT);
ratio_LP = abs(peak_LP_LT)/abs(peak_LP_ST);

%% Display

fprintf('\n==================================================================\n');
fprintf(' Peak (trough) investment response and LT/ST ratio\n');
fprintf('==================================================================\n');
fprintf('%-32s %10s %10s %8s %12s\n','','ST peak','(h)','LT peak','(h)  ratio');
fprintf('%-32s %10.4f %10d %10.4f %6d %8.3f\n','DSGE, without time-to-build', ...
    peak_noTTB_ST, h_noTTB_ST-1, peak_noTTB_LT, h_noTTB_LT-1, ratio_noTTB);
fprintf('%-32s %10.4f %10d %10.4f %6d %8.3f\n','DSGE, with time-to-build (N=6)', ...
    peak_TTB_ST, h_TTB_ST-1, peak_TTB_LT, h_TTB_LT-1, ratio_TTB);
fprintf('%-32s %10.4f %10d %10.4f %6d %8.3f\n','Empirical LP (Figure 7)', ...
    peak_LP_ST, h_LP_ST-1, peak_LP_LT, h_LP_LT-1, ratio_LP);
fprintf('==================================================================\n');
fprintf('LT/ST peak investment ratio: %.2f (without TTB) -> %.2f (with TTB, N=6); empirical LP: %.2f\n', ...
    ratio_noTTB, ratio_TTB, ratio_LP);
