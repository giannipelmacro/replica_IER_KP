
clear, clc
close all


%% run mod file

addpath 'C:\dynare\4.4.3\matlab'

addpath('../../')

    dynare BB_TTB_KP_HABITS.mod noclearall nograph
    close all


%% PLOT RESULTS FROM QUARTERLY LP

%%%%%% figure on ST shocks

load results_LP_ST.mat

%%%%%%%%
maxhorz=11;%corresponds to 12 quarters
%%%%%%%%%

% names_paper={'VIX-1Q','VIX-2Y','Investment','GDP','Consumption'};

    figure(WindowState="maximized")
    for i = 3:size(Y,2)
        subplot(3,2,2*i-1-4)

        x = 1:1:maxhorz+1;  % Define the x-axis values
        y1 = irf_l(idx(i),1:maxhorz+1) * norm;  % First curve
        y2 = irf_p(idx(i),1:maxhorz+1) * norm;  % Second curve

        h1=plot(1:1:maxhorz+1,irfs_lpiv(idx(i),1:maxhorz+1)*norm,'Color',settings.colors.green,'LineWidth',3,'LineStyle','--');

        hold on
        % Fill the area between the curves
        fill([x fliplr(x)], [y1 fliplr(y2)], 'g', 'FaceAlpha', 0.4, 'EdgeColor', 'none');

        % Add zero line
        plot(0:size(irfs_lpiv,2), zeros(size(irfs_lpiv,2)+1,1), '-', 'Color', 'k', 'LineWidth', 2, 'HandleVisibility', 'off');

        % Add labels and titles
        ylabel(names_paper(idx(i)), 'interpreter', 'latex', 'fontsize', 13+2+1);
        xlim([1 maxhorz+1]);
        grid on
         hold on 
       if idx(i)==1
           ylim([-15 20])
       elseif idx(i)==2
           ylim([-10 10])    
       elseif idx(i)==3
           ylim([-3.2 3])
       elseif idx(i)==4
           ylim([-1 1])    
           title('Short-term Shock','interpreter', 'latex','FontSize', 18+1) 
       elseif idx(i)==5
           ylim([-1 0.65])
       elseif idx(i)==6
           ylim([-5 5])
       end
       xticks(4:4:maxhorz+1)
       grid on
    end


    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%% figure on ST shocks   %%%%%%%%%%

    load results_LP_LT.mat
 
%%%%%%%%%
maxhorz=11;%corresponds to 12 quarters
%%%%%%%%%

  
       figure(1)
    for i = 3:size(Y,2)
        subplot(3,2,2*i-4)

        x = 1:1:maxhorz+1;  % Define the x-axis values
        y1 = irf_l(idx(i),1:maxhorz+1) * norm;  % First curve
        y2 = irf_p(idx(i),1:maxhorz+1) * norm;  % Second curve

        h3=plot(1:1:maxhorz+1,irfs_lpiv(idx(i),1:maxhorz+1)*norm,'Color',settings.colors.red,'LineWidth',3,'LineStyle','--');

        hold on
        % Fill the area between the curves
        fill([x fliplr(x)], [y1 fliplr(y2)], 'r', 'FaceAlpha', 0.4, 'EdgeColor', 'none');

        % Add zero line
        plot(0:size(irfs_lpiv,2), zeros(size(irfs_lpiv,2)+1,1), '-', 'Color', 'k', 'LineWidth', 2, 'HandleVisibility', 'off');

        xlim([1 maxhorz+1]);
        grid on
       if idx(i)==1
           ylim([-15 20])
       elseif idx(i)==2
           ylim([-10 10])    
       elseif idx(i)==3
           ylim([-3.2 3])
       elseif idx(i)==4
           ylim([-1 1])    
           title('Long-term Shock','interpreter', 'latex','FontSize', 18+1)  
       elseif idx(i)==5
           ylim([-1 0.65])
       elseif idx(i)==6
           ylim([-5 5])
       end
    xticks(4:4:maxhorz+1)
    grid on
    end


    %% Add DSGE IRFs to previous graph


subplot(3,2,1)
plot(0:size(irfs_lpiv,2), zeros(size(irfs_lpiv,2)+1,1), '-', 'Color', 'k', 'LineWidth', 2, 'HandleVisibility', 'off');
p1=plot(100*y_evola./y_sss,':','marker','square','Markersize',3,'Color',rgb('very dark green'),'LineWidth',3+1);
lg=legend([h1 p1],{'Data: LP','DSGE: Baseline'},'Interpreter','latex');
lg.AutoUpdate = 'off';

subplot(3,2,3)
plot(0:size(irfs_lpiv,2), zeros(size(irfs_lpiv,2)+1,1), '-', 'Color', 'k', 'LineWidth', 2, 'HandleVisibility', 'off');
plot(100*c_evola./c_sss,':','marker','square','Markersize',3,'Color',rgb('very dark green'),'LineWidth',3+1)

subplot(3,2,5)
plot(0:size(irfs_lpiv,2), zeros(size(irfs_lpiv,2)+1,1), '-', 'Color', 'k', 'LineWidth', 2, 'HandleVisibility', 'off');
plot(100*inv_tilde_evola./inv_tilde_sss,':','marker','square','Markersize',3,'Color',rgb('very dark green'),'LineWidth',3+1)


subplot(3,2,2)
plot(0:size(irfs_lpiv,2), zeros(size(irfs_lpiv,2)+1,1), '-', 'Color', 'k', 'LineWidth', 2, 'HandleVisibility', 'off');
p3=plot(100*y_evola_lr./y_sss,':','Marker','square','MarkerSize',3,'Color',rgb('dark red'),'LineWidth',3+1);
lg=legend([h3 p3], {'Data: LP', 'DSGE: Baseline'},'Interpreter','latex');
lg.AutoUpdate = 'off';

subplot(3,2,4)
plot(0:size(irfs_lpiv,2), zeros(size(irfs_lpiv,2)+1,1), '-', 'Color', 'k', 'LineWidth', 2, 'HandleVisibility', 'off');
plot(100*c_evola_lr./c_sss,':','Marker','square','MarkerSize',3,'Color',rgb('dark red'),'LineWidth',3+1)

subplot(3,2,6)
plot(0:size(irfs_lpiv,2), zeros(size(irfs_lpiv,2)+1,1), '-', 'Color', 'k', 'LineWidth', 2, 'HandleVisibility', 'off');
plot(100*inv_tilde_evola_lr./inv_tilde_sss,':','Marker','square','MarkerSize',3,'Color',rgb(' dark red'),'LineWidth',3+1)

%% save fig

    orient tall
    print('-depsc','FigA20');
    print('-dpdf','FigA20','-fillpage');
