% Robustness check: theoretical IRFs (as in Fig. 8) for three alternative
% time-to-build horizons, J = 4, 6 (baseline), 8, plotted together.
%
% Runs BB_TTB_KP_HABITS_J4.mod, BB_TTB_KP_HABITS.mod (J=6, baseline), and
% BB_TTB_KP_HABITS_J8.mod (all in the BB subfolder), extracts the same set
% of IRFs plotted in Fig. 8, and overlays all three calibrations on one
% figure. 

clear
close all

addpath('C:\dynare\4.4.3\matlab')

startDir = pwd;
cd('BB')
addpath('../../../')   % DSGE root, for sss.m / irfsss.m (in case the .mod files' own addpath does not resolve)

modFiles = {'BB_TTB_KP_HABITS_J4.mod', 'BB_TTB_KP_HABITS.mod', 'BB_TTB_KP_HABITS_J8.mod'};
Jlabels  = {'J4', 'J6', 'J8'};
Jtitles  = {'J = 4', 'J = 6 (baseline)', 'J = 8'};

IRF = struct();

for jj = 1:numel(modFiles)

    clearvars -except startDir modFiles Jlabels Jtitles IRF jj

    dynare(modFiles{jj}, 'noclearall', 'nolog', 'nograph', 'nowarn')

    lab = Jlabels{jj};

    IRF.(lab).VIX1Q_ST   = 100*logvxo_evola;
    IRF.(lab).VIX8Q_ST   = 100*logvxo_evola_8;
    IRF.(lab).Output_ST  = 100*y_evola./y_sss;
    IRF.(lab).Cons_ST    = 100*c_evola./c_sss;
    IRF.(lab).Inv_ST     = 100*inv_tilde_evola./inv_tilde_sss;
    IRF.(lab).Hours_ST   = 100*n_evola./n_sss;
    IRF.(lab).Rate_ST    = 400*r_evola;
    IRF.(lab).Infl_ST    = 100*yoyPie_evola;

    IRF.(lab).VIX1Q_LT   = 100*logvxo_evola_lr;
    IRF.(lab).VIX8Q_LT   = 100*logvxo_evola_lr_8;
    IRF.(lab).Output_LT  = 100*y_evola_lr./y_sss;
    IRF.(lab).Cons_LT    = 100*c_evola_lr./c_sss;
    IRF.(lab).Inv_LT     = 100*inv_tilde_evola_lr./inv_tilde_sss;
    IRF.(lab).Hours_LT   = 100*n_evola_lr./n_sss;
    IRF.(lab).Rate_LT    = 400*r_evola_lr;
    IRF.(lab).Infl_LT    = 100*yoyPie_evola_lr;

    IRF.(lab).t = t;

end

cd(startDir)
save('IRF_TTBhorizon.mat', 'IRF', 'Jlabels', 'Jtitles')

%% Report: peak and cumulative ST/LT magnitudes and ratios across J
% Prints, for each Fig. 8 real/nominal variable, the peak and 20-quarter
% cumulative absolute response to ST and LT shocks under J=4,6,8, and the
% corresponding LT/ST ratios -- the numbers quoted in the "Role of the
% time-to-build horizon" appendix subsection.

vars_report     ={'Inv'};% {'Output','Cons','Inv','Hours','Rate','Infl'};
ST_LP = load(fullfile('..','Compare2DSGE','results_LP_ST.mat'),'irfs_lpiv'); % LP results from RUN_ME_Fig7_FigA14.m
LT_LP = load(fullfile('..','Compare2DSGE','results_LP_LT.mat'),'irfs_lpiv');
empLP_ratio_Inv = min(LT_LP.irfs_lpiv(3,:))/min(ST_LP.irfs_lpiv(3,:)); % empirical peak (trough) LT/ST investment ratio, Figure fig:LP in the paper (row 3 = investment)

fprintf('\n=================================================================\n');
fprintf('Peak and cumulative short-term (ST) vs long-term (LT) responses,\n');
fprintf('by time-to-build horizon J. All entries are absolute values.\n');
fprintf('=================================================================\n');
fprintf('%-8s %-4s %10s %10s %10s | %10s %10s %10s\n', ...
    'var','J','peakST','peakLT','ratio','cumST','cumLT','ratio(cum)');
for iv = 1:numel(vars_report)
    vn = vars_report{iv};
    for jj = 1:numel(Jlabels)
        lab    = Jlabels{jj};
        st     = IRF.(lab).([vn '_ST']);
        lt     = IRF.(lab).([vn '_LT']);
        peakST = max(abs(st)); peakLT = max(abs(lt));
        cumST  = abs(sum(st)); cumLT  = abs(sum(lt));
        fprintf('%-8s %-4s %10.4f %10.4f %10.3f | %10.4f %10.4f %10.3f\n', ...
            vn, lab, peakST, peakLT, peakLT/peakST, cumST, cumLT, cumLT/cumST);
    end
end

fprintf('\n--- Investment peak ratio (LT/ST) vs. empirical LP target (%.1f, Figure fig:LP) ---\n', empLP_ratio_Inv);
ratios = zeros(1,numel(Jlabels));
for jj = 1:numel(Jlabels)
    lab        = Jlabels{jj};
    peakST     = max(abs(IRF.(lab).Inv_ST));
    peakLT     = max(abs(IRF.(lab).Inv_LT));
    ratios(jj) = peakLT/peakST;
    fprintf('  %s: peak ratio = %.2f (|diff from empirical| = %.2f)\n', lab, ratios(jj), abs(ratios(jj)-empLP_ratio_Inv));
end
[~, ibest] = min(abs(ratios-empLP_ratio_Inv));
fprintf('  --> %s is closest to the empirical target.\n', Jlabels{ibest});
fprintf('=================================================================\n\n');

%% Plot, same layout/panels as Fig. 8, one line pair (ST, LT) per J

irflength = 20;


lineStyleByJ = {':', '-.', '--'};
lineWidthByJ = [3, 4, 3];
colorST_ByJ  = {rgb('olive'), 'g', rgb('dark green')};
colorLT_ByJ  = {rgb('light red'),   'r', rgb('dark red')};
markerByJ    = {'o', 'none', 'p'};
markerEveryN = 3; 

panels = {'VIX1Q','VIX-1Q','Percent';
          'VIX8Q','VIX-8Q','Percent';
          'Output','Output','Percent';
          'Cons','Consumption','Percent';
          'Inv','Investment','Percent';
          'Hours','Hours Worked','Percent';
          'Rate','Policy rate','Perc. points';
          'Infl','Inflation (YoY)','Perc. points'};

% Reproduce the exact subplot positions used in RUN_ME_Fig8_FigA18.m:
% subplot(4,2,1)=VIX1Q, (4,2,2)=VIX8Q, (4,2,3)=Output, (4,2,4)=Consumption,
% (4,2,5)=Investment, (4,2,6)=Hours, (4,2,7)=Policy rate, (4,2,8)=Inflation
posByPanel = [1 2 3 4 5 6 7 8];

Fig = figure('WindowState','maximized');

for p = 1:size(panels,1)

    varName = panels{p,1};
    subplot(4,2,posByPanel(p))
    hold on
    plot(zeros(irflength,1),'k--','HandleVisibility','off'); xlim([0 irflength]);set(gca,'XTick',[4:4:irflength],'FontSize',12);

    hST = gobjects(1,numel(Jlabels));
    hLT = gobjects(1,numel(Jlabels));

    for jj = 1:numel(Jlabels)
        lab = Jlabels{jj};
        t   = IRF.(lab).t;
        hST(jj) = plot(t, IRF.(lab).([varName '_ST']), lineStyleByJ{jj}, 'Color', colorST_ByJ{jj}, 'LineWidth', lineWidthByJ(jj), ...
                       'Marker', markerByJ{jj}, 'MarkerSize', 5, 'MarkerIndices', 1:markerEveryN:irflength, 'MarkerFaceColor', 'none');
        hLT(jj) = plot(t, IRF.(lab).([varName '_LT']), lineStyleByJ{jj}, 'Color', colorLT_ByJ{jj}, 'LineWidth', lineWidthByJ(jj), ...
                       'Marker', markerByJ{jj}, 'MarkerSize', 5, 'MarkerIndices', 1:markerEveryN:irflength, 'MarkerFaceColor', 'none');
    end

    ylabel(panels{p,3},'FontSize',12+2)
    title(panels{p,2},'FontSize',16+8);
    xlim([IRF.J6.t(1) IRF.J6.t(end)]);set(gca,'XTick',IRF.J6.t(4:4:end),'FontSize',12+5);

    if strcmp(varName,'VIX1Q') || strcmp(varName,'VIX8Q')
        ylim([0 10])
    end

    if p==1
        legend([hST hLT], ...
            {'ST, J=4','ST, J=6 (baseline)','ST, J=8', ...
             'LT, J=4','LT, J=6 (baseline)','LT, J=8'}, ...
            'FontSize',8,'NumColumns',2-1,'Location','northeast')
    end

end

orient tall
print('-depsc','FigA19');
print('-dpdf','FigA19','-fillpage');
