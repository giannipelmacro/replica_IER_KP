// This file loads external parameters for the stochastic process of unc shocks

// load parameters that change: 
@#include "load_params_dynare.m"

// ------------------

///////////////////////////////////////////////////////////////////////////////////////////////////
// G. Pellegrino

// The following code is based on the model and calibration of:
// Basu & Bundick (2018), "Uncertainty Shocks in a Model of Effective Demand: Reply", Econometrica
///////////////////////////////////////////////////////////////////////////////////////////////////

var a, c, de, deltau, deltauprime, expre, expre2, expvf1sigma, inv, k, mu, n,
	pe, pie, profit, q, r, rr, rrk, sdf, u, varexpre, vf, vola, w, y, z ,
    expre_8, expre2_8, varexpre_8, srUnc, lrUnc, expre_4, expre2_4, varexpre_4, yoyPie, inv_tilde;

varexo ea, evola, ez, evola_lr;

parameters 	alpha, beta, delta0, delta1, delta2, eta, phip, phik, 
			sigma, ies, frischlse, thetavf, thetamu, leverageratio, fixedcost,
			rhor, rhopie, rhoy,	rhoa, rhovola, volvola, rhoz, productionconstant, utilityconstant, 
            ass, css, dess, deltauss, deltauprimess, express, expre2ss, expvf1sigmass, invss, kss, nss, muss, 
            pess, piess, profitss, qss, rss, rrss, rrkss, sdfss, uss, varexpress, vfss, volass, volzss, wss, yss, zss ,
            express_8, expre2ss_8 , rhovola_lr, volvola_lr , b, phi0, phi1, phi2, phi3, phi4, phi5;

alpha           = 0.333;
beta            = 0.994;
delta0          = 0.025;
delta1          = (1/beta - 1 + delta0);
delta2          = 0.00031;
phip            = 240; 
phik            = 3.9208;
sigma           = 100; 
ies             = 0.5; 
frischlse       = 2;
thetavf         = (1 - sigma)/(1 - 1/ies);
thetamu         = 6.0;
leverageratio   = 0.90;

piess           = 1.005;
rss             = piess/beta;
rhor            = 0;
rhopie          = 1.5;
rhoy            = 0.2;

ass             = 1;
rhoa            = 0.9809586;

zss             = 1;
rhoz           = 0.35025728; 
volzss          = 0.018791531 ; 

// PARAMETERIZATION UNCERTAINTY PROCESS:
volass          = 0.0225; %(-->then enters in logs)
// baseline values (overridden below by the externally loaded parameters):
// rhovola         = 0.40;
// rhovola_lr      = 0.7500;
// volvola         = log(1+0.1); 
// volvola_lr      = log(1+0.065);

// --------- externally loaded parameters
rhovola = rhovola_; 
rhovola_lr=rhovola_lr_;
volvola=volvola_;
volvola_lr=volvola_lr_;
// ---------

// habits parameter:
b=0.65;

// TTB weights (N=6 gestation):
phi0=1/6; % --> these weights need to sum perfectly to 1
phi1=1/6;
phi2=1/6;
phi3=1/6;
phi4=1/6;
phi5=1/6;


// Steady State Calibration

yss         = 1.0;
qss         = phi0*beta^(-5) + phi1*beta^(-4) + phi2*beta^(-3) + phi3*beta^(-2) + phi4*beta^(-1) + phi5; // with TTB it is greater than 1
rrkss       = qss*(1/beta - 1 + delta0);
muss        = thetamu/(thetamu - 1);
uss			= 1;
fixedcost   = (muss - 1)*yss;
kss         = alpha*(yss + fixedcost)/(rrkss*muss);
invss       = delta0*kss;
css         = yss - invss;

nsssolution = fsolve(@(nssguess) 1+(-1+1/ies)/(1+((-1+alpha)*(-1+nssguess)*(fixedcost+yss))/(css*(1-b)*nssguess*muss)) -(frischlse/ies)*nssguess*(1-nssguess)^(-1),0.5,optimoptions('fsolve','Display','off'));
nss         = nsssolution;

wss                 = (1 - alpha)*(yss + fixedcost)/(nss*muss);
eta                 = (wss*(1 - nss)/(css*(1-b)) + 1)^(-1);
productionconstant 	= (yss + fixedcost)/(kss^(alpha)*(nss)^(1 - alpha));
vfss                = 1;
utilityconstant     = vfss^((1 - sigma)/thetavf)*(1 - beta)/((css*(1-b))^(eta)*(1 - nss)^(1 - eta))^((1 - sigma)/thetavf);
dess                = css - wss*nss + leverageratio*kss*(beta - 1);
pess                = beta*(1-beta)^(-1)*dess;
profitss            = (muss - 1)*yss - fixedcost;
express             = 1/beta;
expre2ss            = 1/beta^(2);
varexpress          = 0;
expvf1sigmass       = vfss^(1-sigma);
rrss                = 1/beta;
sdfss				= beta;
deltauss			= delta0;
deltauprimess		= delta1;
express_8           = 1/beta^(8);
expre2ss_8          = 1/beta^(8*2);
express_4           = 1/beta^(4);
expre2ss_4          = 1/beta^(4*2);
model;

y + fixedcost 			= productionconstant*(z*n)^(1 - alpha)*(u*k(-1))^(alpha);
c + leverageratio*k/rr 	= w*n  + de + leverageratio*k(-1);
w 					= ((1 - eta)/eta)*(c-b*c(-1))/(1 - n);
vf 					= (utilityconstant*(a*(c-b*c(-1))^(eta)*(1 - n)^(1 - eta))^((1 - sigma)/thetavf)  + beta*expvf1sigma^(1/thetavf))^(thetavf/(1 - sigma));
expvf1sigma 			= vf(+1)^(1 - sigma);
w*n 				= (1 - alpha)*(y + fixedcost)/mu;
rrk*u*k(-1) 		= alpha*(y + fixedcost)/mu;
q*deltauprime*u*k(-1) = alpha*(y + fixedcost)/mu;

/////////////////////////////////////////////////////////////
// ORIGINAL LAW OF MOTION IN BB (already implicit 1 period time to build)
// k 			= ((1 - deltau) - (phik/2)*(inv/k(-1) - delta0)^(2))*k(-1) + inv;
// LAW OF MOTION WITH TIME TO BUILD OF 6 PERIODS
k 			= ((1 - deltau) - (phik/2)*(inv/k(-1) - delta0)^(2))*k(-1) + inv(-5);
inv_tilde = phi0*inv + phi1*inv(-1) + phi2*inv(-2) + phi3*inv(-3) + phi4*inv(-4) + phi5*inv(-5);
////////////////////////////////////////////////////////////

deltau		= delta0 + delta1*(u-1) + (delta2/2)*(u-1)^(2);
deltauprime	= delta1 + delta2*(u-1);
sdf = beta*((a/a(-1))*((c-b*c(-1))^(eta)*(1 - n)^(1 - eta))/((c(-1)-b*c(-2))^(eta)*(1 - n(-1))^(1 - eta)))^((1 - sigma)/thetavf)
			*((c(-1)-b*c(-2))/(c-b*c(-1)))*(vf^(1 - sigma)/expvf1sigma(-1))^(1 - 1/thetavf);
1 = rr*sdf(+1);
1 = r*sdf(+1)*(pie(+1))^(-1);
1 = sdf(+1)*(de(+1) + pe(+1))/pe;
log(r) = (1 - rhor)*(log(rss) + rhopie*log(pie/piess) + rhoy*log(y/y(-1))) + rhor*log(r(-1));

///////////////////////////////////////////////////////////
// ORIGINAL EXPRESSION FOR DIVIDENDS
// de = y - w*n - inv - (phip/2)*(pie/piess - 1)^(2)*y - leverageratio*(k(-1) - k/rr);
// EXPRESSION FOR DIVIDENDS WITH TTB
de = y - w*n - inv_tilde - (phip/2)*(pie/piess - 1)^(2)*y - leverageratio*(k(-1) - k/rr);
///////////////////////////////////////////////////////////

1 = sdf(+1)*(u(+1)*rrk(+1) + 
     q(+1)*((1 - deltau(+1)) - (phik/2)*(inv(+1)/k - delta0)^(2) + phik*(inv(+1)/k - delta0)*(inv(+1)/k)))/q;

///////////////////////////////////////////////////////////
// ORIGINAL FOC WRT INVESTMENT
// 1/q = 1 - phik*(inv/k(-1) - delta0); // or: 1 = q - q*(phik*(inv/k(-1) - delta0));
// FOC WRT INVESTMENT WITH TIME TO BUILD
phi0 + phi1*sdf(+1) + phi2*sdf(+1)*sdf(+2) + phi3*sdf(+1)*sdf(+2)*sdf(+3) + phi4*sdf(+1)*sdf(+2)*sdf(+3)*sdf(+4) + phi5*sdf(+1)*sdf(+2)*sdf(+3)*sdf(+4)*sdf(+5)
= q(+5)*sdf(+1)*sdf(+2)*sdf(+3)*sdf(+4)*sdf(+5) - q*(phik*(inv/k(-1) - delta0));
///////////////////////////////////////////////////////////

phip*(pie/piess - 1)*(pie/piess) = (1 - thetamu) + thetamu/mu + 
  sdf(+1)*phip*(pie(+1)/piess - 1)*(y(+1)/y)*(pie(+1)/piess);
profit = (mu - 1)*y - fixedcost;

expre = ( pe(+1))/pe;
expre2 = ( pe(+1))^(2)/pe^(2);
varexpre = expre2 - (expre)^(2);

expre_8 = ( pe(+8))/pe;  
expre2_8 = ( pe(+8))^(2)/pe^(2);
varexpre_8 = expre2_8 - (expre_8)^(2);

expre_4 = ( pe(+4))/pe;
expre2_4 = ( pe(+4))^(2)/pe^(2);
varexpre_4 = expre2_4 - (expre_4)^(2);

a = (1 - rhoa)*ass + rhoa*a(-1) + exp(vola(-1))*ea;
vola = rhovola*vola(-1) + (1 - rhovola)*log(volass) + srUnc + lrUnc ;
srUnc=volvola*evola;
lrUnc=rhovola_lr*lrUnc(-1)+volvola_lr*evola_lr;
z = (1 - rhoz)*zss + rhoz*z(-1) + volzss*ez;

yoyPie=pie*pie(-1)*pie(-2)*pie(-3); //gross inflation
end;

initval;
a 	 		= 	ass;
c 	 		= 	css;
de 	 		= 	dess;
deltau 		= 	delta0;
deltauprime = 	delta1;
expre 	 	= 	express;
expre2 	 	= 	expre2ss;
expvf1sigma = 	expvf1sigmass;
inv 	 	= 	invss;
k 	 		= 	kss;
n 	 		= 	nss;
mu 	 		= 	muss;
pe 	 		= 	pess;
pie 		= 	piess;
profit 		= 	profitss;
q 	 		= 	qss;
r 	 		= 	rss;
rr 	 		= 	rrss;
rrk 	 	= 	rrkss;
sdf			= 	sdfss;
u			= 	uss;
varexpre 	= 	varexpress;
vf 	 		= 	vfss;
vola 	 	= 	volass;
w 	 		= 	wss;
y	 		= 	yss;
z			= 	zss;
expre_8     = 	express_8;
expre2_8 	= 	expre2ss_8;
varexpre_8 	= 	varexpress;
srUnc       =   0;
lrUnc       =   0;
yoyPie      =   piess^4;
inv_tilde   =   invss;
end;

steady;

check;

shocks;
var ea 		= 1;
var evola 	= 1;
var ez	 	= 1;
var evola_lr 	= 1;
end;

stoch_simul(order=3,periods=10000,drop=500,irf=0,noprint,nograph,nomoments,nofunctions,nocorr,pruning);



//------------------

irflength           = 20;
irfburninlength     = 1000;

addpath('../')

oo_.stochastic_steady_state = sss(oo_.dr, irfburninlength, options_.order);

for ivariable = 1:M_.endo_nbr
    assignin('base',[deblank(M_.endo_names(ivariable,:)) '_sss'],...
                     oo_.stochastic_steady_state(ivariable,:)');                     
end

for ishock = 1:M_.exo_nbr    

    variables_irfsss  =  irfsss(oo_.dr,M_.Sigma_e(:,ishock),irflength,irfburninlength,options_.order)';

    for ivariable = 1:M_.endo_nbr
        assignin('base',[deblank(M_.endo_names(ivariable,:)) '_' deblank(M_.exo_names(ishock,:))],...
                          variables_irfsss(:,ivariable));                         
    end

end


%%%%%%%%%%%%%%%%  IRF
t         		= 1:irflength;

vxo_evola 		= 100*sqrt(4*(max(varexpre_evola+varexpre_sss,1e-16)));
vxo_sss         = 100*sqrt(4*(varexpre_sss));
logvxo_evola	= log(vxo_evola./ vxo_sss);

vxo_evola_8     = 100*sqrt(0.5*(max(varexpre_8_evola+varexpre_8_sss,1e-16)));
vxo_sss_8       = 100*sqrt(0.5*(varexpre_8_sss));
logvxo_evola_8	= log(vxo_evola_8./ vxo_sss_8);

pl_evola        = log( cumprod(pie_evola+pie_sss) ./ cumprod(pie_sss*ones(irflength,1)));

vxo_evola_lr 		= 100*sqrt(4*(max(varexpre_evola_lr+varexpre_sss,1e-16)));
logvxo_evola_lr	= log(vxo_evola_lr./ vxo_sss);

vxo_evola_lr_8 		= 100*sqrt(0.5*(max(varexpre_8_evola_lr+varexpre_8_sss,1e-16)));
logvxo_evola_lr_8	= log(vxo_evola_lr_8./ vxo_sss_8);

pl_evola_lr        = log( cumprod(pie_evola_lr+pie_sss) ./ cumprod(pie_sss*ones(irflength,1)));
