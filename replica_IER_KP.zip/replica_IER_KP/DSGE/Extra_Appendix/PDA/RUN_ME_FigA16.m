
addpath('C:\dynare\4.4.3\matlab');
addpath('../../')
cd('BB')

close all
clear

%% Run dynare
rng(1);

% Loop over different sets of random parameters
n_runs = 100*2.5 ; % Number of iterations

rhovola_draw         = 0 + (0.40 - 0) * rand(n_runs,1); 
rhovola_lr_draw      = 0.55 + (0.80 - 0.55) * rand(n_runs,1); 

STvix_ST=NaN(20,1,n_runs);
STvix_LT=NaN(20,1,n_runs);
LTvix_ST=NaN(20,1,n_runs);
LTvix_LT=NaN(20,1,n_runs);

for i = 1:n_runs
    % Draw random values for parameters from uniform distribution
    rhovola_         = rhovola_draw(i); 
    rhovola_lr_      = rhovola_lr_draw(i);
    volvola_         = log(1+0.085) ;
    volvola_lr_      = log(1+0.085) ; 

    % Save parameters to a .mat file
    save('params.mat', 'rhovola_', 'rhovola_lr_','volvola_','volvola_lr_');

    % Create a Dynare command file to load parameters
    fid = fopen('load_params_dynare.m', 'w');
    fprintf(fid, 'load params.mat;\n');
    fclose(fid);


    dynare BB_TTB_KP_HABITS.mod noclearall nolog nograph nowarn

%% Figure with all variables

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%% short run unc. shocks
Fig = figure(1);
set(Fig, 'WindowState', 'maximized');
subplot(4,2,3)
hold on
plot(t,100*y_evola./y_sss,':','Color','g','LineWidth',3+1-3)
plot(zeros(irflength,1),'k--','HandleVisibility','off'); xlim([0 irflength]);set(gca,'XTick',[4:4:irflength],'FontSize',12);
ylabel('Percent','FontSize',12+2)
title('Output','FontSize',16+8);xlim([t(1) t(end)]);set(gca,'XTick',t(4:4:end),'FontSize',12+5);

subplot(4,2,4)
hold on
plot(t,100*c_evola./c_sss,':','Color','g','LineWidth',3+1-3)
plot(zeros(irflength,1),'k--','HandleVisibility','off'); xlim([0 irflength]);set(gca,'XTick',[4:4:irflength],'FontSize',12);
ylabel('Percent','FontSize',12+2)
title('Consumption','FontSize',16+8);xlim([t(1) t(end)]);set(gca,'XTick',t(4:4:end),'FontSize',12+5);

subplot(4,2,5)
hold on
plot(t,100*inv_tilde_evola./inv_tilde_sss,':','Color','g','LineWidth',3+1-3)
plot(zeros(irflength,1),'k--','HandleVisibility','off'); xlim([0 irflength]);set(gca,'XTick',[4:4:irflength],'FontSize',12);
ylabel('Percent','FontSize',12+2)
title('Investment','FontSize',16+8);xlim([t(1) t(end)]);set(gca,'XTick',t(4:4:end),'FontSize',12+5);

subplot(4,2,6)
hold on
plot(t,100*n_evola./n_sss,':','Color','g','LineWidth',3+1-3)
plot(zeros(irflength,1),'k--','HandleVisibility','off'); xlim([0 irflength]);set(gca,'XTick',[4:4:irflength],'FontSize',12);
ylabel('Percent','FontSize',12+2)
title('Hours Worked','FontSize',16+8);xlim([t(1) t(end)]);set(gca,'XTick',t(4:4:end),'FontSize',12+5);

subplot(4,2,1)
hold on
plot(100*logvxo_evola,':','Color','g','LineWidth',3+1-3)
plot(zeros(irflength,1),'k--','HandleVisibility','off'); xlim([0 irflength]);set(gca,'XTick',[4:4:irflength],'FontSize',12);
ylabel('Percent','FontSize',12+2)
title('VIX-1Q','FontSize',16+8);xlim([t(1) t(end)]);set(gca,'XTick',t(4:4:end),'FontSize',12+5);
ylim([0 15])

subplot(4,2,2)
hold on
plot(100*logvxo_evola_8,':','Color','g','LineWidth',3+1-3)
plot(zeros(irflength,1),'k--','HandleVisibility','off'); xlim([0 irflength]);set(gca,'XTick',[4:4:irflength],'FontSize',12);
ylabel('Percent','FontSize',12+2)
title('VIX-8Q','FontSize',16+8);xlim([t(1) t(end)]);set(gca,'XTick',t(4:4:end),'FontSize',12+5);
ylim([0 15])

subplot(4,2,7)
hold on
plot(400*r_evola,':','Color','g','LineWidth',3+1-3)
plot(zeros(irflength,1),'k--','HandleVisibility','off'); xlim([0 irflength]);set(gca,'XTick',[4:4:irflength],'FontSize',12);
ylabel('Percentage points','FontSize',12+2)
title('Policy rate','FontSize',16+8);xlim([t(1) t(end)]);set(gca,'XTick',t(4:4:end),'FontSize',12+5);

subplot(4,2,8)
hold on
plot(100*yoyPie_evola,':','Color','g','LineWidth',3+1-3)
plot(zeros(irflength,1),'k--','HandleVisibility','off'); xlim([0 irflength]);set(gca,'XTick',[4:4:irflength],'FontSize',12);
ylabel('Percentage points','FontSize',12+2)
title('Inflation (YoY)','FontSize',16+8);xlim([t(1) t(end)]);set(gca,'XTick',t(4:4:end),'FontSize',12+5)

%%%%%%%%%%%%% long run unc. shocks

subplot(4,2,3)
hold on
plot(t,100*y_evola_lr./y_sss,'--','Color','r','LineWidth',3+1-3)
plot(zeros(irflength,1),'k--','HandleVisibility','off'); xlim([0 irflength]);set(gca,'XTick',[4:4:irflength],'FontSize',12);
ylabel('Percent','FontSize',12+2)
title('Output','FontSize',16+8);xlim([t(1) t(end)]);set(gca,'XTick',t(4:4:end),'FontSize',12+5);

subplot(4,2,4)
hold on
plot(t,100*c_evola_lr./c_sss,'--','Color','r','LineWidth',3+1-3)
plot(zeros(irflength,1),'k--','HandleVisibility','off'); xlim([0 irflength]);set(gca,'XTick',[4:4:irflength],'FontSize',12);
ylabel('Percent','FontSize',12+2)
title('Consumption','FontSize',16+8);xlim([t(1) t(end)]);set(gca,'XTick',t(4:4:end),'FontSize',12+5);

subplot(4,2,5)
hold on
plot(t,100*inv_tilde_evola_lr./inv_tilde_sss,'--','Color','r','LineWidth',3+1-3)
plot(zeros(irflength,1),'k--','HandleVisibility','off'); xlim([0 irflength]);set(gca,'XTick',[4:4:irflength],'FontSize',12);
ylabel('Percent','FontSize',12+2)
title('Investment','FontSize',16+8);xlim([t(1) t(end)]);set(gca,'XTick',t(4:4:end),'FontSize',12+5);

subplot(4,2,6)
hold on
plot(t,100*n_evola_lr./n_sss,'--','Color','r','LineWidth',3+1-3)
plot(zeros(irflength,1),'k--','HandleVisibility','off'); xlim([0 irflength]);set(gca,'XTick',[4:4:irflength],'FontSize',12);
ylabel('Percent','FontSize',12+2)
title('Hours Worked','FontSize',16+8);xlim([t(1) t(end)]);set(gca,'XTick',t(4:4:end),'FontSize',12+5);

subplot(4,2,1)
hold on
plot(100*logvxo_evola_lr,'--','Color','r','LineWidth',3+1-3)
plot(zeros(irflength,1),'k--','HandleVisibility','off'); xlim([0 irflength]);set(gca,'XTick',[4:4:irflength],'FontSize',12);
ylabel('Percent','FontSize',12+2)
title('VIX-1Q','FontSize',16+8);xlim([t(1) t(end)]);set(gca,'XTick',t(4:4:end),'FontSize',12+5);
ylim([0 15])

legend('Short-term unc. shock','Long-term unc. shock','Fontsize',14+2-6)

subplot(4,2,2)
hold on
plot(100*logvxo_evola_lr_8,'--','Color','r','LineWidth',3+1-3)
plot(zeros(irflength,1),'k--','HandleVisibility','off'); xlim([0 irflength]);set(gca,'XTick',[4:4:irflength],'FontSize',12);
ylabel('Percent','FontSize',12+2)
title('VIX-8Q','FontSize',16+8);xlim([t(1) t(end)]);set(gca,'XTick',t(4:4:end),'FontSize',12+5);
ylim([0 15])

subplot(4,2,7)
hold on
plot(400*r_evola_lr,'--','Color','r','LineWidth',3+1-3)
plot(zeros(irflength,1),'k--','HandleVisibility','off'); xlim([0 irflength]);set(gca,'XTick',[4:4:irflength],'FontSize',12);
ylabel('Perc. points','FontSize',12+2)
title('Policy rate','FontSize',16+8);xlim([t(1) t(end)]);set(gca,'XTick',t(4:4:end),'FontSize',12+5)

subplot(4,2,8)
hold on
plot(100*yoyPie_evola_lr,'--','Color','r','LineWidth',3+1-3)
plot(zeros(irflength,1),'k--','HandleVisibility','off'); xlim([0 irflength]);set(gca,'XTick',[4:4:irflength],'FontSize',12);
ylabel('Perc. points','FontSize',12+2)
title('Inflation (YoY)','FontSize',16+8);xlim([t(1) t(end)]);set(gca,'XTick',t(4:4:end),'FontSize',12+5);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%% FIGURE WITH ONLY VIXs IRFs

%%%%%%%%%%%%% short run unc. shocks
Fig = figure(2);
set(Fig, 'WindowState', 'maximized');
subplot(1,2,1)
hold on
plot(100*logvxo_evola,':','Color','g','LineWidth',3+1-3)
plot(zeros(irflength,1),'k--','HandleVisibility','off'); xlim([0 irflength]);
ylabel('Percent','FontSize',12+2+8)
title('VIX-1Q','FontSize',16+8+8);xlim([t(1) t(end)]);
set(gca,'XTick',t(4:4:end),'FontSize',12+5+11);
ylim([0 13])

subplot(1,2,2)
hold on
plot(100*logvxo_evola_8,':','Color','g','LineWidth',3+1-3)
plot(zeros(irflength,1),'k--','HandleVisibility','off'); xlim([0 irflength]);
ylabel('Percent','FontSize',12+2+8)
title('VIX-8Q','FontSize',16+8+8);xlim([t(1) t(end)]);
set(gca,'XTick',t(4:4:end),'FontSize',12+5+11);
ylim([0 13])

%%%%%%%%%%%%% long run unc. shocks

subplot(1,2,1)
hold on
plot(100*logvxo_evola_lr,'--','Color','r','LineWidth',3+1-3)
plot(zeros(irflength,1),'k--','HandleVisibility','off'); xlim([0 irflength]);
ylabel('Percent','FontSize',12+2+8)
title('VIX-1Q','FontSize',16+8+8);xlim([t(1) t(end)]);
set(gca,'XTick',t(4:4:end),'FontSize',12+5+11);
ylim([0 13])

legend('Short-term unc. shock','Long-term unc. shock','Fontsize',14+2-6+4+8)

subplot(1,2,2)
hold on
plot(100*logvxo_evola_lr_8,'--','Color','r','LineWidth',3+1-3)
plot(zeros(irflength,1),'k--','HandleVisibility','off'); xlim([0 irflength]);
ylabel('Percent','FontSize',12+2+8)
title('VIX-8Q','FontSize',16+8+8);xlim([t(1) t(end)]);
set(gca,'XTick',t(4:4:end),'FontSize',12+5+11);
ylim([0 13])

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%% save VIXs irfs 

STvix_ST(:,:,i)=logvxo_evola;
STvix_LT(:,:,i)=logvxo_evola_8;
LTvix_ST(:,:,i)=logvxo_evola_lr;
LTvix_LT(:,:,i)=logvxo_evola_lr_8;

    clear rhovola_ rhovola_lr_ volvola_ volvola_lr_
    delete('params.mat')
end



%% save figs

cd('../')

orient landscape
print('-depsc','FigA16');
print('-dpdf','FigA16','-fillpage');

close(2) 



