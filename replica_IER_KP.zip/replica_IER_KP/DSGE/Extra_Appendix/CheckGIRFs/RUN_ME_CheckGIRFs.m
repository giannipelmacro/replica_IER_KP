clear, clc
close all

% Compares the GIRFs used in the paper (sss.m/irfsss.m) with the closed-form
% GIRFs of the third-order pruned state-space system, for the variables of
% Figure 8 and both uncertainty shocks (see README_CheckGIRFs.txt).
% Saves the comparison figure GIRF_comparison_v2.png.

%% run mod file

addpath 'C:\dynare\4.4.3\matlab'

addpath('../../')

    dynare BB_TTB_KP_HABITS_CheckGIRFs_v2.mod noclearall nograph
