CheckGIRFs
==========

Cross-check of the method used to compute all DSGE impulse responses in the
paper. For the variables of Figure 8 and both uncertainty shocks, the GIRFs
computed with sss.m/irfsss.m are compared with the closed-form GIRFs of the
third-order pruned state-space system (Andreasen, Fernandez-Villaverde and
Rubio-Ramirez, 2018). The two methods agree closely.

Files
- BB_TTB_KP_HABITS_CheckGIRFs_v2.mod: baseline model (as in
  Baseline/BB_TTB_KP_HABITS.mod) plus the comparison.
- Dynare44Pruning/simAndMoments3order/: pruning toolbox used for the
  closed-form GIRFs.

- RUN_ME_CheckGIRFs.m: runs the check and saves the comparison figure
  GIRF_comparison_v2.png.
