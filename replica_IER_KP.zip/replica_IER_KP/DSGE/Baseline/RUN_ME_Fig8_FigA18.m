

clear
% close all

addpath('C:\dynare\4.4.3\matlab')
addpath('../')   % DSGE folder, for sss.m / irfsss.m

%% Run dynare mod files for the figures below

dynare BB_TTB_KP_HABITS.mod noclearall nograph
% close all

save BBmodel_2uncShocks_v5.mat


%% IRFs: short-term and long-term

clear
load BBmodel_2uncShocks_v5


%%%%%%%%%%%%% short run unc. shocks
Fig=figure("WindowState","maximized");
subplot(4,2,3)
hold on
plot(t,100*y_evola./y_sss,'-','Color','g','LineWidth',3+1)
plot(zeros(irflength,1),'k--','HandleVisibility','off'); xlim([0 irflength]);set(gca,'XTick',[4:4:irflength],'FontSize',12);
ylabel('Percent','FontSize',12+2)
title('Output','FontSize',16+8);xlim([t(1) t(end)]);set(gca,'XTick',t(4:4:end),'FontSize',12+5);

subplot(4,2,4)
hold on
plot(t,100*c_evola./c_sss,'-','Color','g','LineWidth',3+1)
plot(zeros(irflength,1),'k--','HandleVisibility','off'); xlim([0 irflength]);set(gca,'XTick',[4:4:irflength],'FontSize',12);
ylabel('Percent','FontSize',12+2)
title('Consumption','FontSize',16+8);xlim([t(1) t(end)]);set(gca,'XTick',t(4:4:end),'FontSize',12+5);

subplot(4,2,5)
hold on
plot(t,100*inv_tilde_evola./inv_tilde_sss,'-','Color','g','LineWidth',3+1)
plot(zeros(irflength,1),'k--','HandleVisibility','off'); xlim([0 irflength]);set(gca,'XTick',[4:4:irflength],'FontSize',12);
ylabel('Percent','FontSize',12+2)
title('Investment','FontSize',16+8);xlim([t(1) t(end)]);set(gca,'XTick',t(4:4:end),'FontSize',12+5);

subplot(4,2,6)
hold on
plot(t,100*n_evola./n_sss,'-','Color','g','LineWidth',3+1)
plot(zeros(irflength,1),'k--','HandleVisibility','off'); xlim([0 irflength]);set(gca,'XTick',[4:4:irflength],'FontSize',12);
ylabel('Percent','FontSize',12+2)
title('Hours Worked','FontSize',16+8);xlim([t(1) t(end)]);set(gca,'XTick',t(4:4:end),'FontSize',12+5);

subplot(4,2,1)
hold on
plot(100*logvxo_evola,'-','Color','g','LineWidth',3+1)
plot(zeros(irflength,1),'k--','HandleVisibility','off'); xlim([0 irflength]);set(gca,'XTick',[4:4:irflength],'FontSize',12);
ylabel('Percent','FontSize',12+2)
title('VIX-1Q','FontSize',16+8);xlim([t(1) t(end)]);set(gca,'XTick',t(4:4:end),'FontSize',12+5);
ylim([0 10])

subplot(4,2,2)
hold on
plot(100*logvxo_evola_8,'-','Color','g','LineWidth',3+1)
plot(zeros(irflength,1),'k--','HandleVisibility','off'); xlim([0 irflength]);set(gca,'XTick',[4:4:irflength],'FontSize',12);
ylabel('Percent','FontSize',12+2)
title('VIX-8Q','FontSize',16+8);xlim([t(1) t(end)]);set(gca,'XTick',t(4:4:end),'FontSize',12+5);
ylim([0 10])

subplot(4,2,7)
hold on
plot(400*r_evola,'-','Color','g','LineWidth',3+1)
plot(zeros(irflength,1),'k--','HandleVisibility','off'); xlim([0 irflength]);set(gca,'XTick',[4:4:irflength],'FontSize',12);
ylabel('Percentage points','FontSize',12+2)
title('Policy rate','FontSize',16+8);xlim([t(1) t(end)]);set(gca,'XTick',t(4:4:end),'FontSize',12+5);

subplot(4,2,8)
hold on
plot(100*yoyPie_evola,'-','Color','g','LineWidth',3+1)
plot(zeros(irflength,1),'k--','HandleVisibility','off'); xlim([0 irflength]);set(gca,'XTick',[4:4:irflength],'FontSize',12);
ylabel('Percentage points','FontSize',12+2)
title('Inflation (YoY)','FontSize',16+8);xlim([t(1) t(end)]);set(gca,'XTick',t(4:4:end),'FontSize',12+5)


%%%%%%%%%%%%% long run unc. shocks

subplot(4,2,3)
hold on
plot(t,100*y_evola_lr./y_sss,'-.','Color','r','LineWidth',3+1)
plot(zeros(irflength,1),'k--','HandleVisibility','off'); xlim([0 irflength]);set(gca,'XTick',[4:4:irflength],'FontSize',12);
ylabel('Percent','FontSize',12+2)
title('Output','FontSize',16+8);xlim([t(1) t(end)]);set(gca,'XTick',t(4:4:end),'FontSize',12+5);

subplot(4,2,4)
hold on
plot(t,100*c_evola_lr./c_sss,'-.','Color','r','LineWidth',3+1)
plot(zeros(irflength,1),'k--','HandleVisibility','off'); xlim([0 irflength]);set(gca,'XTick',[4:4:irflength],'FontSize',12);
ylabel('Percent','FontSize',12+2)
title('Consumption','FontSize',16+8);xlim([t(1) t(end)]);set(gca,'XTick',t(4:4:end),'FontSize',12+5);

subplot(4,2,5)
hold on
plot(t,100*inv_tilde_evola_lr./inv_tilde_sss,'-.','Color','r','LineWidth',3+1)
plot(zeros(irflength,1),'k--','HandleVisibility','off'); xlim([0 irflength]);set(gca,'XTick',[4:4:irflength],'FontSize',12);
ylabel('Percent','FontSize',12+2)
title('Investment','FontSize',16+8);xlim([t(1) t(end)]);set(gca,'XTick',t(4:4:end),'FontSize',12+5);

subplot(4,2,6)
hold on
plot(t,100*n_evola_lr./n_sss,'-.','Color','r','LineWidth',3+1)
plot(zeros(irflength,1),'k--','HandleVisibility','off'); xlim([0 irflength]);set(gca,'XTick',[4:4:irflength],'FontSize',12);
ylabel('Percent','FontSize',12+2)
title('Hours Worked','FontSize',16+8);xlim([t(1) t(end)]);set(gca,'XTick',t(4:4:end),'FontSize',12+5);

subplot(4,2,1)
hold on
plot(100*logvxo_evola_lr,'-.','Color','r','LineWidth',3+1)
plot(zeros(irflength,1),'k--','HandleVisibility','off'); xlim([0 irflength]);set(gca,'XTick',[4:4:irflength],'FontSize',12);
ylabel('Percent','FontSize',12+2)
title('VIX-1Q','FontSize',16+8);xlim([t(1) t(end)]);set(gca,'XTick',t(4:4:end),'FontSize',12+5);
ylim([0 10])

legend('Short-term unc. shock','Long-term unc. shock','Fontsize',14+2-6)

subplot(4,2,2)
hold on
plot(100*logvxo_evola_lr_8,'-.','Color','r','LineWidth',3+1)
plot(zeros(irflength,1),'k--','HandleVisibility','off'); xlim([0 irflength]);set(gca,'XTick',[4:4:irflength],'FontSize',12);
ylabel('Percent','FontSize',12+2)
title('VIX-8Q','FontSize',16+8);xlim([t(1) t(end)]);set(gca,'XTick',t(4:4:end),'FontSize',12+5);
ylim([0 10])

subplot(4,2,7)
hold on
plot(400*r_evola_lr,'-.','Color','r','LineWidth',3+1)
plot(zeros(irflength,1),'k--','HandleVisibility','off'); xlim([0 irflength]);set(gca,'XTick',[4:4:irflength],'FontSize',12);
ylabel('Perc. points','FontSize',12+2)
title('Policy rate','FontSize',16+8);xlim([t(1) t(end)]);set(gca,'XTick',t(4:4:end),'FontSize',12+5)

subplot(4,2,8)
hold on
plot(100*yoyPie_evola_lr,'-.','Color','r','LineWidth',3+1)
plot(zeros(irflength,1),'k--','HandleVisibility','off'); xlim([0 irflength]);set(gca,'XTick',[4:4:irflength],'FontSize',12);
ylabel('Perc. points','FontSize',12+2)
title('Inflation (YoY)','FontSize',16+8);xlim([t(1) t(end)]);set(gca,'XTick',t(4:4:end),'FontSize',12+5);

orient tall
print('-depsc','Fig8');
print('-dpdf','Fig8','-fillpage');%'-bestfit'


%% scatter plot -- justification for "narrative dates" (Appendix)

plot_scatter=0+1;

if plot_scatter==1

clear
load BBmodel_2uncShocks_v5.mat

% ---------
vxolevel  =  100*sqrt((4*varexpre+abs(min([min(4*varexpre),min(0.5*varexpre_8),min(varexpre_4)]))));%// original BB code: vxolevel  = 100*sqrt(4*(max(varexpre,1e-16)));
vxolevel_8  =  100*sqrt((0.5*varexpre_8+abs(min([min(4*varexpre),min(0.5*varexpre_8),min(varexpre_4)])))); 
diff_vxolevel_8=diff(vxolevel_8);
diff_vxolevel=diff(vxolevel);
[B,~,~,~,STATS] = regress(diff(vxolevel_8),diff(vxolevel));
% ---------

disp(['R-squared: ' num2str(STATS(1),2)])

% ----------------------------------------------------------------
% Find long-run shocks close to vertical axis
[a]=find(abs(diff_vxolevel)<prctile(abs(diff_vxolevel),10));
[b]=find(diff_vxolevel_8(a)>prctile(diff_vxolevel_8(a),99));
diff_vxolevel_8_a=diff_vxolevel_8(a);
[~,c]=intersect(diff_vxolevel_8,diff_vxolevel_8_a(b));
[diff_vxolevel(c),diff_vxolevel_8(c)]

% Find short-run shocks close to horizontal axis
[a2]=find(abs(diff_vxolevel_8)<prctile(abs(diff_vxolevel_8),10));
[b2]=find(diff_vxolevel(a2)>prctile(diff_vxolevel(a2),99));
diff_vxolevel_a2=diff_vxolevel(a2);
[~,c2]=intersect(diff_vxolevel,diff_vxolevel_a2(b2));
[diff_vxolevel(c2),diff_vxolevel_8(c2)]

% Find biggest short & long-run shocks close to diagonal
[a4]=find(diff_vxolevel_8>prctile(diff_vxolevel_8,99.9));
[b4]=find(diff_vxolevel>prctile(diff_vxolevel,99.9));
[c4,~]=intersect(a4,b4)
% ----------------------------------------------------------------

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


figure
scatter(diff_vxolevel,diff_vxolevel_8)
lsline
hline(0,'k:')
vline(0,'k:')
xlabel(['\Delta VIX 1Q'])
ylabel(['\Delta VIX 2Y'])
hold on
for k=1:length(c)
    p1=scatter(diff_vxolevel(c(k)),diff_vxolevel_8(c(k)),'r*');
end
for k=1:length(c2)
    p2=scatter(diff_vxolevel(c2(k)),diff_vxolevel_8(c2(k)),'gx');
end
legend([p2 p1],{'S.T. unc. shocks date','L.T. unc. shocks date'},'Location','SouthEast','Fontsize',9)


print('-depsc','FigA18');


end


